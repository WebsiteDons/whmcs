<?php
/*
* Copyright (c) 2019 Emuzement Net Inc. All Rights Reserved
* License: EULA
* Author: Alex/Kumar/Manti/Lisa
*/

if( !defined("WHMCS") ) die("This file cannot be accessed directly");

use \WHMCS\Session;
use \WHMCS\Database\Capsule;
use \WHMCS\Module\Addon\Cmseframework\Admin\AdminDispatcher;
use \WHMCS\Module\Addon\Cmseframework\Client\ClientDispatcher;

// load functions
if( !function_exists('posts') )
	include_once __DIR__.'/functions.php';


if( requestKey('saved') && getRequest('saved') == 'true' )
{
	// set cmse framework global configurations if auto configure is true
	if( (is_null(modConfigs()->globalize) || !is_null(modConfigs()->globalize) && modConfigs()->globalize != 1) && modvars()['autoconfigure'] == 'on' )
	{
		try{
		globalconfig()
		->where([['module', MODNAME], ['setting', 'configs']])
		->update(['value' => '{"admin_restrict":["'.Session::get('adminid').'"],"permissions":["configs","languageManager","templateManager","installer"],"imagesfolder":"images","maxupload":"800","listslimit":"50","adminlogo":"","local_timezone":"America\\/New_York","prod_wysiwyg":"1","targetattrib":"1","product_detail":"1","sitename_title":"1","sitename_title_pos":null,"sitename_title_sep":"|","meta_keywords":"","meta_description":"","headtags":"","favicon":"assets\\/favicon.png","ogmeta":{"og":"1"},"socialapi":["fb","twit","ig","gplus","pin"],"fbpage":"","fbappid":"","sharebtn":["fb","twit","gplus","ig","pin","tum","red","eml"],"default_social_img":"hostserver.jpg","head_scripts":"","foot_scripts":"","allowedfiles":null,"editable":null,"allcatpreset":"allcat-grid","catcolumns":"4","catimgmask":"160","cattextlimit":"120","allcat_layout":"[image][title][text]","catpreset":"cat-items-grid","postcolumns":"4","postimgmask":"160","posttextlimit":"150","itemsperpage":"10","catlayout":"[title][text][posts]","catpostlayout":"[image][title][text]","postpreset":"post-standard","layout":"[title][image][text]","grouppreset":"group-grid","prodcolumns":"3","prodimgmask":"160","prodtextlimit":"150","group_detailslayout":"[title][text][products]","group_layout":"[title][text][pricetotal][addcart]","productpreset":"product-allprice","product_layout":"[title]\\r\\n[div class=&#34;inlineblock alignmiddle width-200&#34;]\\r\\n[price]\\r\\n[\\/div]\\r\\n[div class=&#34;inlineblock alignmiddle width-160&#34;]\\r\\n[addcart]\\r\\n[\\/div]\\r\\n[div class=&#34;margintop-20&#34;]Category: [group][\\/div]\\r\\n\\r\\n[div class=&#34;margintop-20&#34;]\\r\\n[text]\\r\\n[\\/div]\\r\\n\\r\\n[clearall]\\r\\n[socialshare]","cart_layout":"[div class=&#34;col-md-8&#34;]\r\n [alert]\r\n [title]\r\n [text]\r\n[\/div]\r\n\r\n[summarywrap]\r\n [billcycle]\r\n [config]\r\n [fields]\r\n [addon]\r\n [ordersummary]\r\n[\/summarywrap]","cmse_texts":"order_icon = &#34;fa-cart-plus&#34;\\r\\norder_now = &#34;Order Now&#34;\\r\\nview_details = &#34;View Details&#34;\\r\\nview_group = &#34;View Items&#34;\\r\\nno_products = &#34;No items in this category&#34;\\r\\nfree=&#34;Free&#34;\\r\\nno_service_fee=&#34;No Service Fee&#34;\\r\\nservice_fee=&#34;Single Service Fee&#34;\\r\\ntotal=&#34;Total Today&#34;"}']);
		} catch(\Exception $e) {
			cmseNotice($e->getMessage());
		}

		// create image directory
		//if( !file_exists(IMGPATH) ) {
			copyAll(MODPATH.'/_copyfiles/contentfiller_assets/images', ROOTDIR.'/images');
		//}

		// store default template data in file for restoration
		$src = MODPATH.'/_copyfiles';
		$restore = '
<?php

$data = ["template" => "'.getSetting('Template').'", "ordertpl" => "'.getSetting('OrderFormTemplate').'"];
';
		file_put_contents($src.'/restore/data.php', $restore);

		// set sixflix as default
		try{
			getDbo('tblconfiguration')->where('setting', 'Template')->update(['value' => 'sixflix']);
		} catch(\Exception $e) {
			cmseNotice($e->getMessage());
		}
		try{
			getDbo('tblconfiguration')->where('setting', 'OrderFormTemplate')->update(['value' => 'sixflix']);
		} catch(\Exception $e) {
			cmseNotice($e->getMessage());
		}

		/**
		* Insert existing product values to CMSE product table
		***/
		// make aliases of any existing product group names
		$groups = groups()->select('id', 'name')->get();

		foreach($groups as $group)
		{
			if( !in_array($group->id, cmseproducts()->pluck('group_id')) )
			{
				$fields = [
				'type' => 'group',
				'group_id' => $group->id,
				'group_alias' => cleanChars($group->name),
				];
				try{
					cmseproducts()->insertGetId($fields);
				} catch(\Exception $e) {
					cmseNotice($e->getMessage());
				}
			}
		}


		// make aliases of any existing product names
		$products = products()->select('id', 'name', 'gid')->get();

		foreach($products as $product)
		{
			if( !in_array($product->id, cmseproducts()->pluck('prod_id')) )
			{
				$fields = [
				'type' => 'product',
				'prod_id' => $product->id,
				'prod_alias' => cleanChars($product->name),
				'prod_gid' => $product->gid,
				'group_alias' => cleanChars(groups()->where('id', $product->gid)->value('name')),
				'group_id' => $product->gid
				];
				try{
					cmseproducts()->insertGetId($fields);
				} catch(\Exception $e) {
					cmseNotice($e->getMessage());
				}
			}
		}


		// insert content filler
		if( modvars()['contentfiller'] == 'on' ) 
		{
			include $src.'/contentfiller_assets/_contentFiller.php';
		}

	}
}

function cmseframework_config()
{
	$configs = [
		'name' => 'CMSE Framework',
		'description' => 'Create categories, articles, menus, templates',
		'version' => getCmseVersion(),
		'author' => 'WebsiteDons.com',
		'fields' => [
			'autoconfigure' => [
			'FriendlyName' => 'Auto Configure CMSE Framework <small>(recommended)</small>',
			'Type' => 'yesno',
			'Default' => 'yes',
			'Description' => '<small>Check this option to setup the default configurations and be immediately functional. The settings can be change in the addon\'s global configuration at <strong><a href="addonmodules.php?module=cmseframework&action=configs">CMSE Framework Configuration</a></strong></small>'
			],
			'contentfiller' => [
			'FriendlyName' => 'Insert Filler Content',
			'Type' => 'yesno',
			'Description' => '<small>Insert content relative to web hosting, website services, marketing services, software download, affiliate. The texts can be altered to your suit. Only English is available.</small>'
			],
			'configs' => [
			'Default' => '{
				"allcatpreset":"allcat-grid",
				"catcolumns":"4","catimgmask":"160",
				"cattextlimit":"120",
				"allcat_layout":"[image][title][text]",
				"catpreset":"cat-items-grid",
				"postcolumns":"4",
				"postimgmask":"160",
				"posttextlimit":"150",
				"itemsperpage":"10",
				"catlayout":"[title][text][posts]",
				"catpostlayout":"[image][title][text]",
				"postpreset":"post-standard",
				"layout":"[title][image][text]",
				"grouppreset":"group-grid",
				"prodcolumns":"3",
				"prodimgmask":"160",
				"prodtextlimit":"150",
				"group_detailslayout":"[title][text][products]",
				"group_layout":"[title][text][pricetotal][addcart]",
				"productpreset":"product-allprice",
				"product_layout":"[title]\r\n[div class=&#34;inlineblock alignmiddle width-200&#34;]\r\n[price]\r\n[\/div]\r\n[div class=&#34;inlineblock alignmiddle width-160&#34;]\r\n[addcart]\r\n[\/div]\r\n[div class=&#34;margintop-20&#34;]Category: [group][\/div]\r\n\r\n[div class=&#34;margintop-20&#34;]\r\n[text]\r\n[\/div]\r\n\r\n[clearall]\r\n[socialshare]",
				"cart_layout":"[div class=&#34;col-md-8&#34;]\r\n [alert]\r\n [title]\r\n [text]\r\n[\/div]\r\n\r\n[summarywrap]\r\n [billcycle]\r\n [config]\r\n [fields]\r\n [addon]\r\n [ordersummary]\r\n[\/summarywrap]"
				}'
			]
		],
	];

	return $configs;
}

function cmseframework_activate()
{
	try {
	Capsule::schema()
	->create(
			DB_BANNERS,
			function ($table)
			{
				$table->increments('id');
				$table->string('title');
				$table->string('type');
				$table->text('adcontent');
				$table->integer('catid')->unsigned();
				$table->longText('attribs');
				$table->tinyInteger('state')->unsigned();
				$table->tinyInteger('author')->unsigned();
				$table->tinyInteger('update_author')->unsigned();
				$table->dateTime('created_at');
				$table->dateTime('updated_at');
				$table->integer('impressions')->unsigned();
				$table->integer('clicks')->unsigned();
				$table->string('access');
				$table->engine = 'InnoDB';
			}
	);

	Capsule::schema()
	->create(
		DB_CATS,
		function ($table)
		{
			$table->increments('id');
			$table->string('title');
			$table->string('alias')->unique();
			$table->longText('description');
			$table->text('configs');
			$table->string('type');
			$table->tinyInteger('state')->unsigned();
			$table->tinyInteger('sortorder');
			$table->string('access');
			$table->dateTime('created_at');
			$table->dateTime('updated_at');
			$table->tinyInteger('author')->unsigned();
			$table->tinyInteger('update_author')->unsigned();
			$table->engine = 'InnoDB';
		}
	);

	// default category insert
	categories()->insertGetId([
	'title' => 'Uncategorized',
	'alias' => 'uncategorized',
	'description' => 'Category for miscellaneos pages',
	'configs' => '{"customcss":"","customjs":"","allcat_layout":null,"cat_layout":"","cat_items_layout":"","textlimit":"","item_layout":"","catimage":"","itemscolumns":"","itemsformat":"list","imgmask":"","showinlist":"","itemcount":""}',
	'type' => 'post',
	'state' => '1',
	'access' => '{"access":"0","cg":null,"no_access_msg":"You do not have the right to view this resource. Please login"}',
	'created_at' => '2019-06-30 04:11:48',
	'updated_at' => '2019-06-30 04:11:48',
	'author' => '1'
	]);

	Capsule::schema()
	->create(
		DB_MENUGROUPS,
		function ($table)
		{
			$table->increments('id');
			$table->string('groupname')->unique();
			$table->tinyInteger('state')->unsigned();
			$table->dateTime('created_at');
			$table->tinyInteger('author')->unsigned();
			$table->engine = 'InnoDB';
		}
	);
	// set default menu group
	menugroups()->insertGetId([
	'groupname' => 'primary',
	'state' => 1,
	'created_at' => '2019-06-30 04:11:48',
	'author' => '1'
	]);

	Capsule::schema()
	->create(
		DB_MENUS,
		function ($table)
		{
			$table->increments('id');
			$table->string('title');
			$table->string('alias')->unique();
			$table->tinyInteger('published')->unsigned();
			$table->tinyInteger('menugroup')->unsigned();
			$table->tinyInteger('menuparent')->unsigned();
			$table->string('url');
			$table->tinyInteger('type')->unsigned();
			$table->tinyInteger('menuorder');
			$table->text('attribs');
			$table->tinyInteger('homepage');
			$table->string('access');
			$table->dateTime('created_at');
			$table->dateTime('updated_at');
			$table->tinyInteger('author')->unsigned();
			$table->tinyInteger('update_author')->unsigned();
			$table->tinyInteger('src_id')->unsigned();
			$table->engine = 'InnoDB';
		}
	);
	// set default menu home
	menus()->insertGetId([
	'title' => 'Home',
	'alias' => 'home',
	'published' => '1',
	'menugroup' => '1',
	'menuparent' => '0',
	'url' => 'index.php',
	'type' => '4',
	'menuorder' => '0',
	'attribs' => '{"browser_title":"Services","menuclass":"","menuicon":""}',
	'homepage' => '1',
	'access' => '{"access":"0","cg":null}',
	'created_at' => '2019-06-30 04:11:48',
	'updated_at' => '2019-06-30 04:11:48',
	'author' => '1',
	'src_id' => '0'
	]);

	Capsule::schema()
	->create(
		DB_POSTS,
		function ($table)
		{
			$table->increments('id');
			$table->string('title');
			$table->string('alias')->unique();
			$table->longText('post_content');
			$table->string('post_image');
			$table->longText('attribs');
			$table->dateTime('created_at');
			$table->dateTime('updated_at');
			$table->integer('catid')->unsigned();
			$table->string('category');
			$table->tinyInteger('published')->unsigned();
			$table->tinyInteger('sortorder');
			$table->string('metadesc');
			$table->string('metakeys');
			$table->string('access');
			$table->tinyInteger('author')->unsigned();
			$table->tinyInteger('update_author')->unsigned();
			$table->integer('hits')->unsigned();
			$table->engine = 'InnoDB';
		}
	);

	Capsule::schema()
	->create(
		'mod_cmse_products',
		function ($table)
		{
			$table->increments('id');
			$table->string('type');
			$table->string('prod_image');
			$table->string('prod_alias');
			$table->tinyInteger('prod_id')->nullable()->unsigned();
			$table->tinyInteger('prod_gid')->nullable()->unsigned();
			$table->text('attribs');
			$table->string('group_alias');
			$table->integer('group_id')->nullable()->unsigned();
			$table->text('group_configs');
			$table->string('group_image');
			$table->engine = 'InnoDB';
		}
	);

	Capsule::schema()
	->create(
		'mod_cmse_sys',
		function ($table)
		{
			$table->increments('id');
			$table->string('type');
			$table->dateTime('updated_at');
			$table->tinyInteger('admin')->unsigned();
			$table->engine = 'InnoDB';
		}
	);

	Capsule::schema()
	->create(
		DB_TPLASSIGN,
		function($table)
		{
			$table->increments('id');
			$table->tinyInteger('tmpl_id')->unsigned();
			$table->tinyInteger('resource')->unsigned();
			$table->string('type');
			$table->dateTime('created_at');
			$table->tinyInteger('author')->unsigned();
			$table->engine = 'InnoDB';
		}
	);

	Capsule::schema()
	->create(
		DB_TPLMANAGER,
		function ($table)
		{
			$table->increments('id');
			$table->string('name')->unique();
			$table->string('slug')->unique();
			$table->longText('configs');
			$table->string('parent_tpl');
			$table->dateTime('created_at');
			$table->dateTime('updated_at');
			$table->tinyInteger('author')->unsigned();
			$table->tinyInteger('update_author')->unsigned();
			$table->engine = 'InnoDB';
		}
	);
	// set default values
	templates()->insertGetId([
	'name' => 'sixflix',
	'slug' => 'sixflix',
	'configs' => '{"themes":"reform.css","favicon":"","layoutwidth":"1180","columnorder":"2|1|3","widetitle":"0","leftcolwidth":"20","leftcolpad":"0,20","rightcolwidth":"30","rightcolpad":"20,0","fontfamily":"Alfa+Slab+One|Raleway","setfont":"h1, h2 {font-family: &quot;Raleway&quot;;}","pgbgcolor":"","pgbgcolor2":"","pgbgimg":"","pgbgimgrepeat":"","pgbgimgsize":"","headbg1":"","headbg2":"","headfontcolor":"","headlink":"","navbg1":"","navbg2":"","navlinkbghov1":"","navlinkbghov2":"","navlinkborder":"","navtext":"","navsubbg":"","navsubtext":"","topsectbg1":"","topsectbg2":"","topsecttext":"","mainsectbg":"","mainsecttext":"","bottomsectbg1":"","bottomsectbg2":"","bottomsecttext":"","footbg1":"","footbg2":"","foottext":"","customcss":"","customjs":""}',
	'parent_tpl' => '',
	'author' => '1'
	]);

	Capsule::schema()
	->create(
		DB_WIDGETS,
		function ($table)
		{
			$table->increments('id');
			$table->string('type');
			$table->tinyInteger('state')->unsigned();
			$table->longText('params');
			$table->longText('attribs');
			$table->tinyInteger('sortorder');
			$table->string('position');
			$table->string('menuassign');
			$table->string('access');
			$table->dateTime('created_at');
			$table->dateTime('updated_at');
			$table->tinyInteger('author')->unsigned();
			$table->tinyInteger('update_author')->unsigned();
			$table->engine = 'InnoDB';
		}
	);
	// set default
	widgets()->insert([
		[
		'type' => 'widget_custom',
		'state' => '1',
		'params' => '{"custom_html":"&lt;p&gt;[div class=&quot;floatleft break&quot;]&lt;\\/p&gt;\\r\\n&lt;p&gt;&lt;a href=&quot;index.php&quot;&gt;\\u00a0&lt;img src=&quot;images\\/assets\\/sitelogo.png&quot; alt=&quot;sitelogo&quot; \\/&gt; &lt;\\/a&gt;&lt;\\/p&gt;\\r\\n&lt;p&gt;[\\/div]&lt;\\/p&gt;\\r\\n&lt;p&gt;[div class=&quot;floatleft break marginleft-20 padtop-5&quot;]&lt;\\/p&gt;\\r\\n&lt;p&gt;[widget=&quot;26&quot;]&lt;\\/p&gt;\\r\\n&lt;p&gt;[\\/div]&lt;\\/p&gt;\\r\\n&lt;p&gt;[div class=&quot;floatleft break marginleft-20 padtop-5 headcart&quot;]&lt;\\/p&gt;\\r\\n&lt;p&gt;[widget=&quot;23&quot;]&lt;\\/p&gt;\\r\\n&lt;p&gt;[\\/div]&lt;\\/p&gt;\\r\\n&lt;p&gt;[div class=&quot;floatright break phone&quot;]&lt;\\/p&gt;\\r\\n&lt;div class=&quot;w3&quot;&gt;\\r\\n&lt;div class=&quot;inner&quot;&gt;\\r\\n&lt;ul class=&quot;nobullet&quot;&gt;\\r\\n&lt;li&gt;24\\/7\\/365 Fanatical Support&lt;\\/li&gt;\\r\\n&lt;li&gt;(866) 555-6666&lt;\\/li&gt;\\r\\n&lt;li&gt;&lt;a class=&quot;login&quot; href=&quot;clientarea.php&quot;&gt; Client Login&lt;\\/a&gt; &lt;a class=&quot;logout&quot; href=&quot;logout.php&quot;&gt;Logout&lt;\\/a&gt; &lt;a href=&quot;submitticket.php&quot;&gt;Support&lt;\\/a&gt; &lt;a href=&quot;affiliates.php&quot;&gt;Affiliates&lt;\\/a&gt;&lt;\\/li&gt;\\r\\n&lt;\\/ul&gt;\\r\\n&lt;\\/div&gt;\\r\\n&lt;\\/div&gt;\\r\\n&lt;p&gt;[\\/div]&lt;\\/p&gt;","bgimg":"","customcss":""}',
		'attribs' => '{"title":"sitelogo and phone","show_widget_title":"","widgetclass":"logobar fullwidth","note":""}',
		'sortorder' => '0',
		'position' => 'headitem',
		'menuassign' => '{"assigned":{"menu0":"All"},"exclude":null,"catview":"","group":null}',
		'access' => '{"access":"0","cg":null}',
		'created_at' => '2019-06-30 04:11:48',
		'updated_at' => '2019-07-02 04:41:00',
		'author' => '1',
		'update_author' => '1'
		],
		[
		'type' => 'widget_menu',
		'state' => '1',
		'params' => '{"menugroup":"1","navtemplate":"hover","displayformat":"horizontal","showcaret":"1","mobilenav":"1","togtext":"Menu","togposition":"pull-right"}',
		'attribs' => '{"title":"top menu bar","show_widget_title":"","widgetclass":"stickhead","note":"admin bar using whmcs nav method"}',
		'sortorder' => '2',
		'position' => 'toprow',
		'menuassign' => '{"assigned":{"menu0":"All"},"exclude":null,"catview":"","group":null}',
		'access' => '{"access":"0","cg":null}',
		'created_at' => '2019-06-30 04:11:48',
		'updated_at' => '2019-07-02 04:13:58',
		'author' => '1',
		'update_author' => '1'
		]
	]);




	// copy folders and files
	$src = MODPATH.'/_copyfiles';
	// install TinyMCE image manager and cmse shortcode plugins
	copyAll($src.'/assets/js/tinymce/plugins', ROOTDIR.'/assets/js/tinymce/plugins');
	// install sixflix template
	copyAll($src.'/templates/_copy/templates', ROOTDIR.'/templates');
	// copy rewrite process file to override whmcs http response 404 when viewing cmse framework pages
	copy($src.'/cmseContentFramework.php', ROOTDIR.'/cmseContentFramework.php');

	// backup htaccess
	copy(ROOTDIR.'/.htaccess', $src.'/restore/htaccess.bak');
	// write rule to htaccess
	$rule = '
RewriteEngine On
RewriteCond %{SCRIPT_FILENAME} !-f
RewriteCond %{SCRIPT_FILENAME} !-d
RewriteRule .* cmseContentFramework.php [L]

';
	fileWritePrepend(ROOTDIR.'/.htaccess', $rule, 'cmseContentFramework');


	return [
		'status' => 'success',
		'description' => 'The module is installed and ready for use.',
	];
    } catch (\Exception $e) {
        return [
            'status' => "error",
            'description' => 'Unable to create '.MODNAME.': ' . $e->getMessage(),
        ];
    }
}


function cmseframework_deactivate()
{
	$src = MODPATH.'/_copyfiles';
    try {
        Capsule::schema()->dropIfExists(DB_POSTS);
		Capsule::schema()->dropIfExists(DB_CATS);
		Capsule::schema()->dropIfExists(DB_MENUS);
		Capsule::schema()->dropIfExists(DB_MENUGROUPS);
		Capsule::schema()->dropIfExists(DB_WIDGETS);
		Capsule::schema()->dropIfExists(DB_TPLASSIGN);
		Capsule::schema()->dropIfExists(DB_TPLMANAGER);
		Capsule::schema()->dropIfExists(DB_BANNERS);
		Capsule::schema()->dropIfExists('mod_cmse_sys');
		Capsule::schema()->dropIfExists('mod_cmse_products');


		// remove installed folders and files
		deleteFolders(ROOTDIR.'/assets/js/tinymce/plugins/cmseshortcode');
		deleteFolders(ROOTDIR.'/assets/js/tinymce/plugins/responsivefilemanager');
		deleteFolders(ROOTDIR.'/templates/sixflix');
		deleteFolders(ROOTDIR.'/templates/orderforms/sixflix');
		unlink(ROOTDIR.'/cmseContentFramework.php');

		// restore htaccess to original
		copy($src.'/restore/htaccess.bak', ROOTDIR.'/.htaccess');

		// restore default template before installation with data stored in file during installtion
		include $src.'/restore/data.php';

		if( file_exists(ROOTDIR.'/templates/'.$data['template']) ) {
			$tpl = $data['template'];
		}else{
			$tpl = 'six';
		}
		if( file_exists(ROOTDIR.'/templates/orderforms/'.$data['ordertpl']) ) {
			$ordertpl = $data['ordertpl'];
		}else{
			$ordertpl = 'standard_cart';
		}
		getDbo('tblconfiguration')->where('setting', 'Template')->update(['value' => $tpl]);
		getDbo('tblconfiguration')->where('setting', 'OrderFormTemplate')->update(['value' => $ordertpl]);


		/*
		The images folder will not be deleted due to the possibility that such a
		folder may have previously existed. The site owner will need to manually
		delete.
		*/

        return [
            'status' => 'success',
            'description' => MODNAME.' has been uninstalled',
        ];
    } catch (\Exception $e) {
        return [
            'status' => 'error',
            'description' => 'Unable to drop '.MODNAME.': {$e->getMessage()}',
        ];
    }
}


function cmseframework_output($vars)
{
    $modulelink = $vars['modulelink'];
    $version = $vars['version'];
    $_lang = $vars['_lang'];

    $action = getRequest('action', 'ifset') ? getRequest('action') : '';

    $dispatcher = new AdminDispatcher();
    $response = $dispatcher->dispatch($action, $vars);
    echo $response;
}


function cmseframework_clientarea($vars)
{
    $modulelink = $vars['modulelink'];
    $version = $vars['version'];
    $_lang = $vars['_lang'];

    $action = getRequest('action', 'ifset') ? getRequest('action') : '';

    $dispatcher = new ClientDispatcher();
    return $dispatcher->dispatch($action, $vars);
}

function cmseframework_sidebar($vars)
{
    $modlink = $vars['modulelink'];
    $_lang = $vars['_lang'];

	ob_start();
	include LIB_PATH.'/Admin/sidebar.php';
    return ob_get_clean();
}
