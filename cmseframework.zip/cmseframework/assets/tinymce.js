/*
* Copyright (c) 2019 CMSEnergizer.com. All Rights Reserved
* License: GNU General Public License version 2 or later; see http://www.gnu.org/licenses/
* Author: Alex
* Reponsive File Manager https://www.responsivefilemanager.com/demo.php . Donate to keep the project active
*/


var tinymceSettings = {
	selector: txtfield,
	height: 250,
	theme: "modern",
	entity_encoding: "raw",
	plugins: "autoresize searchreplace autolink directionality visualblocks visualchars fullscreen image responsivefilemanager link media template code codesample table charmap hr pagebreak nonbreaking anchor insertdatetime advlist lists textcolor wordcount imagetools contextmenu colorpicker textpattern help cmseshortcode importcss stickytoolbar",
	toolbar: [
		"fullscreen,formatselect,fontselect,fontsizeselect,|,bold,italic,strikethrough,underline,forecolor,backcolor,|,link,unlink,|,justifyleft,justifycenter,justifyright,justifyfull,|,search,replace,|,bullist,numlist,",
		"outdent,indent,blockquote,|,undo,redo,|,cut,copy,paste,pastetext,pasteword,|,table,|,hr,|,sub,sup,|,charmap,media,|,print,|,ltr,rtl,|,image,responsivefilemanager,removeformat,cmseshortcode,importcss,code"
	],
	
	link_list: liburl+'/Admin/editor/tinymce_linklist.php',
	/*link_class_list: [
	{'title': 'None', 'value': ''},
	{'title' : 'Button', 'value' : 'btn'},
	{'title' : 'Button Small', 'value' : 'btn-sm'},
	{'title' : 'Large Button', 'value' : 'btn-lg'},
	{'title' : 'Block Button', 'value' : 'btn-block'},
	{'title' : 'Button Success', 'value' : 'btn-success'},
	{'title' : 'Button Info', 'value' : 'btn-info'},
	{'title' : 'Button Default', 'value' : 'btn-default'},
	],*/
	link_context_toolbar: true,
	rel_list: [
	{title: 'None', value: ''},
	{title: 'Lightbox', value: 'lightbox'},
	{title: 'Table of contents', value: 'toc'}
	],
	target_list: [
	{title: 'None', value: ''},
	{title: 'Parent', value: '_self'},
	{title: 'New Window', value: '_blank'},
	{title: 'LIghtbox', value: '_lightbox'}
	],
	
	sticky_offset: 40,
	
	image_advtab: true,
	body_class: "cmse-editor",
	content_css: liburl+'/Admin/editor/classlist.css',
	importcss_file_filter: liburl+'/Admin/editor/classlist.css',
	importcss_merge_classes: true,
	importcss_append: true,
	autoresize_bottom_margin: 10,
	autoresize_max_height: 800,
	autoresize_min_height: 250,
	
	extended_valid_elements: "i[class],span[class]",
	
	external_filemanager_path: liburl+"/vendor/filemanager/",
	filemanager_title: "Filemanager",
	external_plugins: {
			"filemanager" : "plugins/responsivefilemanager/plugin.min.js"
			},
	filemanager_access_key: "whmcsfilemanager",
	file_picker_types: "file image media",
	file_picker_callback: function(cb, value, meta) {
	    var width = window.innerWidth-30;
		var height = window.innerHeight-60;
		if(width > 1800) width=1800;
		if(height > 1200) height=1200;
		if(width>600){
			var width_reduce = (width - 20) % 138;
			width = width - width_reduce + 10;
		}
	    var urltype=2;
		if (meta.filetype=='image') { urltype=1; }
		if (meta.filetype=='media') { urltype=3; }
		var title="RESPONSIVE FileManager";
		if (typeof this.settings.filemanager_title !== "undefined" && this.settings.filemanager_title) {
			title=this.settings.filemanager_title;
		}
		var akey="key";
		if (typeof this.settings.filemanager_access_key !== "undefined" && this.settings.filemanager_access_key) {
			akey=this.settings.filemanager_access_key;
		}
		var sort_by="";
		if (typeof this.settings.filemanager_sort_by !== "undefined" && this.settings.filemanager_sort_by) {
			sort_by="&sort_by="+this.settings.filemanager_sort_by;
		}
		var descending="false";
		if (typeof this.settings.filemanager_descending !== "undefined" && this.settings.filemanager_descending) {
			descending=this.settings.filemanager_descending;
		}
		var fldr="";
		if (typeof this.settings.filemanager_subfolder !== "undefined" && this.settings.filemanager_subfolder) {
			fldr="&fldr="+this.settings.filemanager_subfolder;
		}
		var crossdomain="";
		if (typeof this.settings.filemanager_crossdomain !== "undefined" && this.settings.filemanager_crossdomain) {
			crossdomain="&crossdomain=1";

			// Add handler for a message from ResponsiveFilemanager
			if(window.addEventListener){
				window.addEventListener('message', filemanager_onMessage, false);
			} else {
				window.attachEvent('onmessage', filemanager_onMessage);
			}
		}
	    tinymce.activeEditor.windowManager.open({
			title: title,
			file: this.settings.external_filemanager_path+'dialog.php?type='+urltype+'&descending='+descending+sort_by+fldr+crossdomain+'&lang='+this.settings.language+'&akey='+akey,
			width: width,
			height: height,
			resizable: true,
			maximizable: true,
			inline: 1
			}, {
			setUrl: function (url) {
				cb(url);
			}
		});
	},
	
	browser_spellcheck: true,
	convert_urls: false,
	relative_urls: false,
	//forced_root_block: "p",
	media_poster: false,
	mobile: {
		theme: "mobile",
		plugins: ["lists", "autolink"],
		toolbar: ["undo", "bold", "italic", "styleselect"]
	},
	menu: {
		file: {
			title: "File",
			items: "preview | print"
		},
		edit: {
			title: "Edit",
			items: "undo redo | cut copy paste pastetext | selectall | searchreplace"
		},
		view: {
			title: "View",
			items: "visualaid visualchars visualblocks | preview fullscreen"
		},
		insert: {
			title: "Insert",
			items: "image responsivefilemanager link media codesample | charmap hr"
		},
		format: {
			title: "Format",
			items: "bold italic strikethrough underline superscript subscript codeformat | blockformats align | removeformat"
		},
		table: {
			title: "Table",
			items: "inserttable tableprops deletetable | cell row column"
		},
		help: {
			title: "Help",
			items: "help | code"
		}
	}
};

$(document).ready(function() {
	tinymce.init(tinymceSettings).then(function(editors) {
		editorLoaded = true;
	});

});

var editorEnabled = true,
	editorLoaded = false;

function toggleEditor() {
	if (editorEnabled === true) {
		tinymce.activeEditor.remove();
		editorEnabled = false;
	} else {
		tinymce.init(tinymceSettings);
		editorEnabled = true;
	}
}



