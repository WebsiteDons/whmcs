<?php
/*
* Copyright (c) 2019 CMSEnergizer.com. All Rights Reserved
* License: GNU General Public License version 2 or later; see http://www.gnu.org/licenses/
* Author: Alex
*/

// Include WHMCS 
include dirname(__DIR__,4).'/init.php';

if( !defined("WHMCS") ) die("This file cannot be accessed directly");

$dir = urldecode(getPost('dir', false));
$tpld = getInnerString($dir, 'templates/','/');

$link = 'addonmodules.php?module='.MODNAME.'&view=templateManager&task=templateEdit&template='.$tpld.'&templatefile=';


if( file_exists($dir) )
{
	$files = preg_grep('#^([^.])#', scandir($dir));
	natcasesort($files);

	if( count($files) > 2 )
	{
		echo '<ul class="jqueryFileTree" style="display: none;">';
		// All dirs
		foreach( $files as $file ) {
			if( file_exists($dir.$file) && $file != '.' && $file != '..' && is_dir($dir.$file) ) {
				echo '<li class="directory collapsed"><a href="#" rel="'.htmlentities($dir.$file).'/">'.htmlentities($file).'</a></li>';
			}
		}
		// All files
		foreach( $files as $file ) {
			if( file_exists($dir.$file) && $file != '.' && $file != '..' && !is_dir($dir.$file) ) {
				$ext = preg_replace('/^.*\./', '', $file);
				if( in_array($ext, ['tpl', 'php', 'html', 'htm', 'txt', 'js', 'css', 'less', 'scss', 'yaml', 'xml', 'ini']) )
					echo '<li class="file ext_'.$ext.'"><a href="'.$link.htmlentities($dir.$file).'" rel="'.htmlentities($dir.$file).'">'.htmlentities($file).'</a></li>';
			}
		}
		echo '</ul>';
	}
}
