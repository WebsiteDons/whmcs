/*
* Copyright (c) 2019 CMSEnergizer.com. All Rights Reserved
* License: GNU General Public License version 2 or later; see http://www.gnu.org/licenses/
* Author: Alex
*/



jQuery(function($) 
{
	// Chosen Init
	var config = {
	'.cmseform select[size="1"]' : {width: 200, placeholder_text_single: 'Select'},
	'.chosen-select-deselect'  : { allow_single_deselect: true },
	'.chosen-select-no-single' : { disable_search_threshold: 10 },
	'.chosen-select-no-results': { no_results_text: 'Oops, nothing found!' },
	'.chosen-select-rtl'       : { rtl: true },
	'.cmseform select.wide-select'     : { width: 400 }
	}
	for (var selector in config) {
		$(selector).chosen(config[selector]);
	}

	//clear field
	$(".clearfield").click(function() {
		$("input#getimgname").val("");
	});
	
	// admin logo
	if( $("input[name=adminlogo]").val() != '' ) {
		$(".header .logo").addClass("logoimg");
	}
	
	// toggler functions
	$.fn.toggler = function(opener, content) {
		$(opener).click(function(){
			$(content).toggle("slow");
		});
	};
	
	$.fn.slideopen = function(hiddencontainer, optionvalue) {
		$(this).change(function(){
			$(hiddencontainer).hide("fast");
			
			if( $(this).val() == optionvalue )
				$(hiddencontainer).slideToggle("fast");
		});
		
		if( $(this).val() == optionvalue )
			$(hiddencontainer).show("fast");
	};
	
	
	
	// Viewer access toggle
	$("select[name=access]").change(function() {
		$("#clientgroups, #noAccessMsg").hide("fast");
		
		if( $.inArray($(this).val(), ["2","3","4","5","6"]) !== -1 ) {
			$("#noAccessMsg").show("fast");
		}
		
		if( $(this).val() == 6 )
			$("#clientgroups").show("fast");
	});
	// set to show if set in db
	if( $("select[name=access]").val() == 6 )
		$("#clientgroups").show();
	if( $.inArray($("select[name=access]").val(), ["2","3","4","5","6"]) !== -1 ) {
		$("#noAccessMsg").show();
	}
	
	
	// highlight checked radio button
	$(".cmseform input[type=checkbox]").change(function() {
		$(this).parent().parent().addClass('set-1');
	});
	
	if( $('.cmseform input:checked') ) {
		$('.cmseform input:checked').parent().parent().addClass('set-1');
	}
	

	
	// highlight cmse framework side bar link
	$('a[href="addonmodules.php?module=cmseframework"]').parent().addClass("sidebar-nav");

	// image upload
	$('input[name="post_image_upl"],input[name="catimage_upl"],input[name=get_filename]').change(function(e) 
	{
		e.preventDefault();
		
		// get file upload field value image name to pass to hidden field
		var imgname = $('input[name="post_image_upl"]').val();
		var catimgname = $('input[name="catimage_upl"]').val();
		var zipname = $('input[name="get_filename"]').val();
		
		if( typeof imgname != 'undefined' ) {
			/*strip C:\fakepath*/
			var imgname = imgname.substring(imgname.lastIndexOf('\\') + 1, imgname.length);
			$('#getimgname').val(imgname);
		}
		if( typeof catimgname != 'undefined' ) {
			var catimgname = catimgname.substring(catimgname.lastIndexOf('\\') + 1, catimgname.length);
			$('#catimage').val(catimgname);
		}
		if( typeof zipname != 'undefined' ) {
			var zipname = zipname.substring(zipname.lastIndexOf('\\') + 1, zipname.length);
			$('input[name=install_ext]').val(zipname);
		}
	});
	
	// pass item published state select field value to hidden field to get delete instruction
	$('select[name="state"]').change(function(e) 
	{
		e.preventDefault();
		var stateval = $('select[name="state"]').val();
		
		$('#stateval').val(stateval);
	});
	
	
	/* Menus Handler
	--------------------------------*/
	var menutype = 'select#menutype';
	var urlfield = '#menu_url';
	
	$(menutype).change(function(e) 
	{
		e.preventDefault();
		var menuval = $(this).val();
		var allcaturl = $('#allcaturl').val();
		var allgroupurl = $('#allgroupurl').val();
		
		// categories
		if( menuval == 1 ) 
			$(urlfield).val(allcaturl);
		// category
		if( menuval == 2 ) {
			$('#catlist').show('fast');
			$('#categories').change(function() {
				$(urlfield).val($(this).val());
			});
		}else{
			$('#catlist').hide('fast');
		}
		// single post
		if( menuval == 3 ) {
			$('#postlist').show('fast');
			$('#posts').change(function() {
				$(urlfield).val($(this).val());
			});
		}else{
			$('#postlist').hide('fast');
		}
		// whmcs core
		if( menuval == 4 ) {
			$('#whmcslist').show('fast');
			$('#whmcs').change(function() {
				$(urlfield).val($(this).val());
			});
		}else{
			$('#whmcslist').hide('fast');
		}
		// all product groups
		if( menuval == 5 ) 
			$(urlfield).val(allgroupurl);
		// product group
		if( menuval == 6 ) {
			$('#product_group').show('fast');
			$('#prodgroup').change(function() {
				$(urlfield).val($(this).val());
			});
		}else{
			$('#product_group').hide('fast');
		}
		// product detail
		if( menuval == 7 ) {
			$('#product_detail').show('fast');
			$('#prodetail').change(function() {
				$(urlfield).val($(this).val());
			});
		}else{
			$('#product_detail').hide('fast');
		}
		
		if( menuval == 8 || menuval == 9 || menuval == 10 )
			$(urlfield).removeAttr('readonly');
		
	});
	
	// item edit state
	if( $(menutype).val() == 2 ) {
		$('#catlist').show();
		$('#categories').change(function() {
			$(urlfield).val($(this).val());
		});
	}
	// single post
	if( $(menutype).val() == 3 ) {
		$('#postlist').show();
		$('#posts').change(function() {
			$(urlfield).val($(this).val());
		});
	}
	
	if( $(menutype).val() == 4 ) {
		$('#whmcslist').show();
		$('#whmcs').change(function() {
			$(urlfield).val($(this).val());
		});
	}
	
	if( $(menutype).val() == 6 ) {
		$('#product_group').show();
		$('#prodgroup').change(function() {
			$(urlfield).val($(this).val());
		});
	}
	
	if( $(menutype).val() == 7 ) {
		$('#product_detail').show();
		$('#prodetail').change(function() {
			$(urlfield).val($(this).val());
		});
	}
	
	if( $(menutype).val() == 8 || $(menutype).val() == 9 || $(menutype).val() == 10 )
		$(urlfield).removeAttr('readonly');
	
	
	// create comma separated entry for menu group
	$("input[name=menugroup]").change(function(){
		var mgid = [];
		$.each($("input[name=menugroup]:checked"), function(){            
			mgid.push($(this).val());
		});
		$("input[name=menu_group]").val(mgid.join(","));
	});
	
	// language edit
	$("select[name=language_value_select]").change(function(){
		$("input[name=language_constant]").val($(this).val());

		var txt = $('select[name=language_value_select] option:selected').text();
		$("textarea[name=language_value]").val(txt);
	});
	
	
	
	/* Banner Manager
	---------------------------------------*/
	var types = "select[name=bannertype]";
	
	$(types).change(function(e) 
	{
		e.preventDefault();
		var typeval = $(this).val();
		
		// image
		if( typeval == 'image' ) {
			$('#imagetype').show('fast');
		}else{
			$('#imagetype').hide('fast');
		}
		// video
		if( typeval == 'video' ) {
			$('#videotype').show('fast');
		}else{
			$('#videotype').hide('fast');
		}
		// html
		if( typeval == 'html' ) {
			$('#htmltype').show('fast');
		}else{
			$('#htmltype').hide('fast');
		}
	});
	
	// show if saved to db
	if( $(types).val() == 'image' ) {
		$('#imagetype').show();
	}
	if( $(types).val() == 'video' ) {
		$('#videotype').show();
	}
	if( $(types).val() == 'html' ) {
		$('#htmltype').show();
	}
	
	
	
	/* not used
	TODO: make this a function for future use
	// add post to menu
	$("select[name=cats]").change(function() {
		var catid = $(this).val();
		var catalias = $("select[name=cats] option:selected").html();
		var catalias = catalias.replace(/ /g, "-", catalias).toLowerCase();
		
		$("input[name=urlpart_2]").val(catid+"-"+catalias+"&post=");
	});
	
	$("input[name=post_title]").keyup(function(e) {
		var alias = $(this).val();
		var alias = alias.replace(/ /g, "-", alias);
		var postid = $("input[name=urlpart_4]").val();
		var menuid = $("input[name=urlpart_5]").val();
		$("input[name=urlpart_3]").val(postid+"-"+alias.toLowerCase()+"&menuid="+menuid);
	});
	*/
	
	// highlight add menu in post edit view when data is entered
	$("input[name=menu_title]").keypress(function() {
		$(".addmenu h5").addClass("hasmenu");
	});
	$("input[name=menu_title]").blur(function() {
		if( !$(this).val() ) 
		$(".addmenu h5").removeClass("hasmenu");
	});
	
	
	
	
	
	// Widget Sort Value Calculator
	$('select[name=sortcalc]').change(function() {
		var sortcalc = ($(this).val() == 0 ? 0 : $(this).val() - 1);
		$('input[name=sortorder]').val(sortcalc);
	});

	
	
	
	
	/* Delete Items Selector
	------------------------------------*/
	// check all
	$('input[name=checkall]').click(function () {
		$('input[name="item_check"]').not(this).prop('checked', this.checked);
	});
	

	// add each checked item to hidden input field for storage to send to server
	$("button[name=item_delete],button[name=item_disable],button[name=item_enable]").click(function(){
		var ids = [];
		$.each($("input[name='item_check']:checked"), function(){            
			ids.push($(this).val());
		});
		$('#items_id').val(ids.join(","));
	});
	
	
	// menu group delete
	$("button[name=btn_delete_menu]").click(function(){
		var grids = [];
		$.each($("input[name=delete_group]:checked"), function(){            
			grids.push($(this).val());
		});
		$("input[name=group_delete]").val(grids.join(","));
	});
	
	
	
	// Filter Select
	$("select[name=filter_post]").change(function(e) {
		
		var filterpost = $(this).val();
		$("input[name=filter_value]").val(filterpost);
		$(".cmseform").submit();
		e.preventDefault();
	});
	
	
	// template column change image display
	$("select[name=columnorder]").change(function() {
		var sel = $(this).val().replace(/\|/g, '');
		$("#colimg").attr("class","col-"+sel);
	});

	var colimg = $("select[name=columnorder] :selected").val();
	if( typeof colimg != "undefined" ) {
		colimg = colimg.replace(/\|/g, '');
	
		$("#colimg").attr("class","col-"+colimg);
	}
	
	
	
	
	/* number validation when text or numbe field type is used for numbers.
	----------------------------------------------*/
	$('.IsInteger,input[type=number]').focus(function (e) {
		if (this.value == "0") {
			this.value = "";
		}
	});
	$('.IsInteger,input[type=number]').blur(function (e) {
		if (this.value == "") {
			this.value = "";
		}
	});

	$('.IsInteger,input[type=number]').keypress(function (e) {
		var charCode = (e.which) ? e.which : e.keyCode;
		if (charCode > 31
		&& (charCode < 48 || charCode > 57))
			return false;
	});

	
	
	
	
	/* Color Selector
	-------------------------------*/
	$(".colorfield").each( function() {

		$(this).minicolors({
			control:		$(this).attr("data-control") || "hue",
			defaultValue:	$(this).attr("data-defaultValue") || "",
			format:			$(this).attr("data-format") || "hex",
			keywords:		$(this).attr("data-keywords") || "",
			inline:			$(this).attr("data-inline") === "true",
			letterCase:		$(this).attr("data-letterCase") || "lowercase",
			opacity:		$(this).attr("data-opacity"),
			position:		$(this).attr("data-position") || "bottom",
			swatches:		$(this).attr("data-swatches") ? $(this).attr("data-swatches").split("|") : [],
			change: function(value, opacity) {
				if( !value ) return;
				if( opacity ) value += ", " + opacity;
				if( typeof console === "object" ) {
					console.log(value);
				}
			}
		});

	});
	
	
	/* Shortcode Insert */
	function shortcodeSelect(opt, textbox, textbox_alt='', tba_id='', countfield='') 
	{
		$(opt).change(function() {
			$(textbox).val( $("#"+$(this).val()).text() );
			
			if( textbox_alt ) {
				$(textbox_alt).val( $("li#"+tba_id).text() );
			}
			if( $(this).val() == "" ) 
				$(textbox_alt).val("");
			
			if( $(this).val().indexOf('list') != -1 ) {
				$(countfield).val('1');
			}
		});
	};
	
	// global config
	shortcodeSelect("select[name=allcatpreset]", "textarea[name=allcat_layout]", "", "", "input[name=catcolumns]");
	shortcodeSelect(
	"select[name=catpreset]", 
	"textarea[name=catpostlayout]", 
	"textarea[name=catlayout]", 
	"cat", 
	"input[name=postcolumns]"
	);
	shortcodeSelect("select[name=catpostpreset]", "textarea[name=catpostlayout]");
	shortcodeSelect("select[name=postpreset]", "textarea[name=layout]");
	shortcodeSelect("select[name=grouppreset]", "textarea[name=group_layout]", "", "", "input[name=prodcolumns]");
	shortcodeSelect("select[name=productpreset]", "textarea[name=product_layout]");
	// post
	shortcodeSelect("select[name=postpreset]", "textarea[name=item_layout]");
	
	shortcodeSelect("select[name=postpreset]", "textarea[name=singlepost_layout]");
	
	// post category setup
	shortcodeSelect(
	"select[name=catpreset]", 
	"textarea[name=cat_items_layout]", 
	"textarea[name=cat_layout]", 
	"cat",
	"input[name=itemscolumns]"
	);
	shortcodeSelect("select[name=postpreset]", "textarea[name=item_layout]");
	
	shortcodeSelect(
	"select[name=grouppreset]", 
	"textarea[name=groupview]", 
	"textarea[name=group_detailslayout]", 
	"gdetails", 
	"input[name=itemsperrow]"
	);
	shortcodeSelect("select[name=productpreset]", "textarea[name=detailview]");
	
	
	/* Bootstrap HTML button 
	------------------------------*/
	$('#radioBtn a').on('click', function(){
		var val = $(this).data('val');
		var optfield = $(this).data('optfield');
		$('input#'+optfield).val(val);

		$('a[data-optfield="'+optfield+'"]').not('[data-val="'+val+'"]').removeClass('active').addClass('notActive');
		$('a[data-optfield="'+optfield+'"][data-val="'+val+'"]').removeClass('notActive').addClass('active');
	});
	
	// insert table column to products table
	/*https://stackoverflow.com/questions/20239062/add-column-to-table-with-jquery
	$("#tableBackground .datatable:first-child tr").append("<th>ID</th>");
	$("#tableBackground .datatable.sort-groups tr").append("<td>6</td>");
	$("#tableBackground .datatable").find("tr").each(function(){
		$(this).find("th").eq(7).after("<th>ID</th>");
		$(this).find("td").eq(7).after("<td>8</td>");
		$(this).find("td[colspan=\"6\"]").eq(2).after("<td>e</td>");
	});
	*/
	
	$("<div class=\"clearall\"></div>").insertAfter("ul#menu");
	$("<div class=\"clearall\"></div>").insertAfter("div.stats");

});/*jquery*/


// toggler
function cmseToggle(src, selected, toggled) 
{
	$(src).change(function(e) 
	{
		e.preventDefault();
		var srcval = $(this).val();
		
		if( srcval == selected ) {
			$(toggled).show('fast');
		}else{
			$(toggled).hide('fast');
		}
	});
};


/* get a string between given characters used to get src value from iframe
	* when paste into text field
	* getInnerstring('http://site.com?id=red&pwd=gold&usr=jon', '?id=', '&') output red
	*/
function getInnerString(string, start, end) 
{
	var string = ' '+string;
	var ini = string.indexOf(start);
	if( ini == 0 ) return '';
	ini += start.length;
	var len = string.indexOf(end,ini) - ini;
	return string.substr(ini,len);
}

function showit(element,toshow) {
	var elem = document.getElementById(element);
	var show = document.getElementById(toshow);
	
	show.style.display = "none";
	if (elem.checked == true){
		show.style.display = "block";
	}
}
	

// shorthand to get element Id
function inputVal(elm, v) {
	if( v == 1 )
		return document.getElementById(elm).value;
	if( v == 2 )
		return document.getElementById(elm).checked;
}


// ddaccordion initializer
function cmseslides(slidetab,slidecontent, defopen, persist=false) {
ddaccordion.init({
	headerclass: slidetab,
	contentclass: slidecontent,
	revealtype: "click",
	collapseprev: true,
	defaultexpanded: [defopen],
	scrolltoheader: false,
	onemustopen: false,
	animatedefault: false,
	persiststate: persist,
	toggleclass: ["isup", "isdown"],
	togglehtml: ["suffix", "", ""],
	animatespeed: "fast",
	oninit:function(expandedindices){},
	onopenclose:function(header, index, state, isuseractivated){}
});
}




// text area auto height
/*!
	Autosize 3.0.20
	license: MIT
	http://www.jacklmoore.com/autosize
*/
!function(e,t){if("function"==typeof define&&define.amd)define(["exports","module"],t);else if("undefined"!=typeof exports&&"undefined"!=typeof module)t(exports,module);else{var n={exports:{}};t(n.exports,n),e.autosize=n.exports}}(this,function(e,t){"use strict";function n(e){function t(){var t=window.getComputedStyle(e,null);"vertical"===t.resize?e.style.resize="none":"both"===t.resize&&(e.style.resize="horizontal"),s="content-box"===t.boxSizing?-(parseFloat(t.paddingTop)+parseFloat(t.paddingBottom)):parseFloat(t.borderTopWidth)+parseFloat(t.borderBottomWidth),isNaN(s)&&(s=0),l()}function n(t){var n=e.style.width;e.style.width="0px",e.offsetWidth,e.style.width=n,e.style.overflowY=t}function o(e){for(var t=[];e&&e.parentNode&&e.parentNode instanceof Element;)e.parentNode.scrollTop&&t.push({node:e.parentNode,scrollTop:e.parentNode.scrollTop}),e=e.parentNode;return t}function r(){var t=e.style.height,n=o(e),r=document.documentElement&&document.documentElement.scrollTop;e.style.height="auto";var i=e.scrollHeight+s;return 0===e.scrollHeight?void(e.style.height=t):(e.style.height=i+"px",u=e.clientWidth,n.forEach(function(e){e.node.scrollTop=e.scrollTop}),void(r&&(document.documentElement.scrollTop=r)))}function l(){r();var t=Math.round(parseFloat(e.style.height)),o=window.getComputedStyle(e,null),i=Math.round(parseFloat(o.height));if(i!==t?"visible"!==o.overflowY&&(n("visible"),r(),i=Math.round(parseFloat(window.getComputedStyle(e,null).height))):"hidden"!==o.overflowY&&(n("hidden"),r(),i=Math.round(parseFloat(window.getComputedStyle(e,null).height))),a!==i){a=i;var l=d("autosize:resized");try{e.dispatchEvent(l)}catch(e){}}}if(e&&e.nodeName&&"TEXTAREA"===e.nodeName&&!i.has(e)){var s=null,u=e.clientWidth,a=null,p=function(){e.clientWidth!==u&&l()},c=function(t){window.removeEventListener("resize",p,!1),e.removeEventListener("input",l,!1),e.removeEventListener("keyup",l,!1),e.removeEventListener("autosize:destroy",c,!1),e.removeEventListener("autosize:update",l,!1),Object.keys(t).forEach(function(n){e.style[n]=t[n]}),i.delete(e)}.bind(e,{height:e.style.height,resize:e.style.resize,overflowY:e.style.overflowY,overflowX:e.style.overflowX,wordWrap:e.style.wordWrap});e.addEventListener("autosize:destroy",c,!1),"onpropertychange"in e&&"oninput"in e&&e.addEventListener("keyup",l,!1),window.addEventListener("resize",p,!1),e.addEventListener("input",l,!1),e.addEventListener("autosize:update",l,!1),e.style.overflowX="hidden",e.style.wordWrap="break-word",i.set(e,{destroy:c,update:l}),t()}}function o(e){var t=i.get(e);t&&t.destroy()}function r(e){var t=i.get(e);t&&t.update()}var i="function"==typeof Map?new Map:function(){var e=[],t=[];return{has:function(t){return e.indexOf(t)>-1},get:function(n){return t[e.indexOf(n)]},set:function(n,o){e.indexOf(n)===-1&&(e.push(n),t.push(o))},delete:function(n){var o=e.indexOf(n);o>-1&&(e.splice(o,1),t.splice(o,1))}}}(),d=function(e){return new Event(e,{bubbles:!0})};try{new Event("test")}catch(e){d=function(e){var t=document.createEvent("Event");return t.initEvent(e,!0,!1),t}}var l=null;"undefined"==typeof window||"function"!=typeof window.getComputedStyle?(l=function(e){return e},l.destroy=function(e){return e},l.update=function(e){return e}):(l=function(e,t){return e&&Array.prototype.forEach.call(e.length?e:[e],function(e){return n(e,t)}),e},l.destroy=function(e){return e&&Array.prototype.forEach.call(e.length?e:[e],o),e},l.update=function(e){return e&&Array.prototype.forEach.call(e.length?e:[e],r),e}),t.exports=l});


// Sticky Plugin v1.0.4 for jQuery
// =============
// Author: Anthony Garand
// Improvements by German M. Bravo (Kronuz) and Ruud Kamphuis (ruudk)
// Improvements by Leonardo C. Daronco (daronco)
// Created: 02/14/2011
// Date: 07/20/2015
// Website: http://stickyjs.com/
// Description: Makes an element on the page stick on the screen as you scroll
//              It will only set the 'top' and 'position' of your element, you
//              might need to adjust the width in some cases.

(function (factory) {
    if (typeof define === 'function' && define.amd) {
        // AMD. Register as an anonymous module.
        define(['jquery'], factory);
    } else if (typeof module === 'object' && module.exports) {
        // Node/CommonJS
        module.exports = factory(require('jquery'));
    } else {
        // Browser globals
        factory(jQuery);
    }
}(function ($) {
    var slice = Array.prototype.slice; // save ref to original slice()
    var splice = Array.prototype.splice; // save ref to original slice()

  var defaults = {
      topSpacing: 0,
      bottomSpacing: 0,
      className: 'is-sticky',
      wrapperClassName: 'sticky-wrapper',
      center: false,
      getWidthFrom: '',
      widthFromWrapper: true, // works only when .getWidthFrom is empty
      responsiveWidth: false,
      zIndex: 'inherit'
    },
    $window = $(window),
    $document = $(document),
    sticked = [],
    windowHeight = $window.height(),
    scroller = function() {
      var scrollTop = $window.scrollTop(),
        documentHeight = $document.height(),
        dwh = documentHeight - windowHeight,
        extra = (scrollTop > dwh) ? dwh - scrollTop : 0;

      for (var i = 0, l = sticked.length; i < l; i++) {
        var s = sticked[i],
          elementTop = s.stickyWrapper.offset().top,
          etse = elementTop - s.topSpacing - extra;

        //update height in case of dynamic content
        s.stickyWrapper.css('height', s.stickyElement.outerHeight());

        if (scrollTop <= etse) {
          if (s.currentTop !== null) {
            s.stickyElement
              .css({
                'width': '',
                'position': '',
                'top': '',
                'z-index': ''
              });
            s.stickyElement.parent().removeClass(s.className);
            s.stickyElement.trigger('sticky-end', [s]);
            s.currentTop = null;
          }
        }
        else {
          var newTop = documentHeight - s.stickyElement.outerHeight()
            - s.topSpacing - s.bottomSpacing - scrollTop - extra;
          if (newTop < 0) {
            newTop = newTop + s.topSpacing;
          } else {
            newTop = s.topSpacing;
          }
          if (s.currentTop !== newTop) {
            var newWidth;
            if (s.getWidthFrom) {
                padding =  s.stickyElement.innerWidth() - s.stickyElement.width();
                newWidth = $(s.getWidthFrom).width() - padding || null;
            } else if (s.widthFromWrapper) {
                newWidth = s.stickyWrapper.width();
            }
            if (newWidth == null) {
                newWidth = s.stickyElement.width();
            }
            s.stickyElement
              .css('width', newWidth)
              .css('position', 'fixed')
              .css('top', newTop)
              .css('z-index', s.zIndex);

            s.stickyElement.parent().addClass(s.className);

            if (s.currentTop === null) {
              s.stickyElement.trigger('sticky-start', [s]);
            } else {
              // sticky is started but it have to be repositioned
              s.stickyElement.trigger('sticky-update', [s]);
            }

            if (s.currentTop === s.topSpacing && s.currentTop > newTop || s.currentTop === null && newTop < s.topSpacing) {
              // just reached bottom || just started to stick but bottom is already reached
              s.stickyElement.trigger('sticky-bottom-reached', [s]);
            } else if(s.currentTop !== null && newTop === s.topSpacing && s.currentTop < newTop) {
              // sticky is started && sticked at topSpacing && overflowing from top just finished
              s.stickyElement.trigger('sticky-bottom-unreached', [s]);
            }

            s.currentTop = newTop;
          }

          // Check if sticky has reached end of container and stop sticking
          var stickyWrapperContainer = s.stickyWrapper.parent();
          var unstick = (s.stickyElement.offset().top + s.stickyElement.outerHeight() >= stickyWrapperContainer.offset().top + stickyWrapperContainer.outerHeight()) && (s.stickyElement.offset().top <= s.topSpacing);

          if( unstick ) {
            s.stickyElement
              .css('position', 'absolute')
              .css('top', '')
              .css('bottom', 0)
              .css('z-index', '');
          } else {
            s.stickyElement
              .css('position', 'fixed')
              .css('top', newTop)
              .css('bottom', '')
              .css('z-index', s.zIndex);
          }
        }
      }
    },
    resizer = function() {
      windowHeight = $window.height();

      for (var i = 0, l = sticked.length; i < l; i++) {
        var s = sticked[i];
        var newWidth = null;
        if (s.getWidthFrom) {
            if (s.responsiveWidth) {
                newWidth = $(s.getWidthFrom).width();
            }
        } else if(s.widthFromWrapper) {
            newWidth = s.stickyWrapper.width();
        }
        if (newWidth != null) {
            s.stickyElement.css('width', newWidth);
        }
      }
    },
    methods = {
      init: function(options) {
        return this.each(function() {
          var o = $.extend({}, defaults, options);
          var stickyElement = $(this);

          var stickyId = stickyElement.attr('id');
          var wrapperId = stickyId ? stickyId + '-' + defaults.wrapperClassName : defaults.wrapperClassName;
          var wrapper = $('<div></div>')
            .attr('id', wrapperId)
            .addClass(o.wrapperClassName);

          stickyElement.wrapAll(function() {
            if ($(this).parent("#" + wrapperId).length == 0) {
                    return wrapper;
            }
});

          var stickyWrapper = stickyElement.parent();

          if (o.center) {
            stickyWrapper.css({width:stickyElement.outerWidth(),marginLeft:"auto",marginRight:"auto"});
          }

          if (stickyElement.css("float") === "right") {
            stickyElement.css({"float":"none"}).parent().css({"float":"right"});
          }

          o.stickyElement = stickyElement;
          o.stickyWrapper = stickyWrapper;
          o.currentTop    = null;

          sticked.push(o);

          methods.setWrapperHeight(this);
          methods.setupChangeListeners(this);
        });
      },

      setWrapperHeight: function(stickyElement) {
        var element = $(stickyElement);
        var stickyWrapper = element.parent();
        if (stickyWrapper) {
          stickyWrapper.css('height', element.outerHeight());
        }
      },

      setupChangeListeners: function(stickyElement) {
        if (window.MutationObserver) {
          var mutationObserver = new window.MutationObserver(function(mutations) {
            if (mutations[0].addedNodes.length || mutations[0].removedNodes.length) {
              methods.setWrapperHeight(stickyElement);
            }
          });
          mutationObserver.observe(stickyElement, {subtree: true, childList: true});
        } else {
          if (window.addEventListener) {
            stickyElement.addEventListener('DOMNodeInserted', function() {
              methods.setWrapperHeight(stickyElement);
            }, false);
            stickyElement.addEventListener('DOMNodeRemoved', function() {
              methods.setWrapperHeight(stickyElement);
            }, false);
          } else if (window.attachEvent) {
            stickyElement.attachEvent('onDOMNodeInserted', function() {
              methods.setWrapperHeight(stickyElement);
            });
            stickyElement.attachEvent('onDOMNodeRemoved', function() {
              methods.setWrapperHeight(stickyElement);
            });
          }
        }
      },
      update: scroller,
      unstick: function(options) {
        return this.each(function() {
          var that = this;
          var unstickyElement = $(that);

          var removeIdx = -1;
          var i = sticked.length;
          while (i-- > 0) {
            if (sticked[i].stickyElement.get(0) === that) {
                splice.call(sticked,i,1);
                removeIdx = i;
            }
          }
          if(removeIdx !== -1) {
            unstickyElement.unwrap();
            unstickyElement
              .css({
                'width': '',
                'position': '',
                'top': '',
                'float': '',
                'z-index': ''
              })
            ;
          }
        });
      }
    };

  // should be more efficient than using $window.scroll(scroller) and $window.resize(resizer):
  if (window.addEventListener) {
    window.addEventListener('scroll', scroller, false);
    window.addEventListener('resize', resizer, false);
  } else if (window.attachEvent) {
    window.attachEvent('onscroll', scroller);
    window.attachEvent('onresize', resizer);
  }

  $.fn.sticky = function(method) {
    if (methods[method]) {
      return methods[method].apply(this, slice.call(arguments, 1));
    } else if (typeof method === 'object' || !method ) {
      return methods.init.apply( this, arguments );
    } else {
      $.error('Method ' + method + ' does not exist on jQuery.sticky');
    }
  };

  $.fn.unstick = function(method) {
    if (methods[method]) {
      return methods[method].apply(this, slice.call(arguments, 1));
    } else if (typeof method === 'object' || !method ) {
      return methods.unstick.apply( this, arguments );
    } else {
      $.error('Method ' + method + ' does not exist on jQuery.sticky');
    }
  };
  $(function() {
    setTimeout(scroller, 0);
  });
}));

