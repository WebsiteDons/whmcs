<?php
/*
* Copyright (c) 2019 Emuzement Net Inc. All Rights Reserved
* License: EULA
* Author: Alex/Kumar/Manti/Lisa
*/

if( !defined("WHMCS") ) die("This file cannot be accessed directly");

use \WHMCS\Application;
use \WHMCS\Database\Capsule;
use \WHMCS\Carbon;
use \WHMCS\Config\Setting;
use \WHMCS\Session;
use \WHMCS\User\Client;
use \WHMCS\ClientArea;



/** Define MultiUse Variables
-----------------------------------*/

// define user is logged in
$user		= tplVars('loggedin');
$userId		= Session::get('uid');
$tplfilename	= tplVars('filename');
$tplfile	= tplVars('templatefile');

// define variables when in cart
$pid= $gid= $productclass= $groupclass= $cartproduct_class= $cartgroup_class='';
if( !is_null(tplVars('productinfo')) )
{
	$pid = tplVars('productinfo')['pid'];
	$gid = tplVars('productinfo')['gid'];
	$cartproduct_class = ' product-'.$pid;
	$cartgroup_class = ' group-'.$gid;
}


// define component mode
if( !isset(pathinfo(currenturl())['extension']) ) {
	$view_component = true;
	getSmarty()->assign('templatefile', 'component');
}

// get non SEF url request values
list($component, $view, $category, $post, $menuid, $listpage, $prodid, $groupid, $parent) = getNonSEF();


// Get active widgets and add to positions array
$widgets = widgets()->select('id', 'position', 'menuassign', 'access')->where('state', 1)->orderBy('sortorder')->get();

if( $menuid == 0 ) {
	$menuid = menus()->where('url', getCurrentFilename())->value('id');
}

$menu = menus()->select('id', 'url', 'title', 'attribs', 'homepage')->where('id', (int)$menuid)->get()[0];
$homepg = menus()->select('id', 'url')->where('homepage', 1)->get()[0];

// change the value of $menuid to match homepage when url does not include a file extension
if( $tplfile == 'homepage' || getCurrentFilename() == '' ) {
	$menu = menus()->select('id', 'url', 'title', 'attribs', 'homepage')->where('homepage', 1)->get()[0];
	$menuid = $menu->id;
}

// redirect to menu item set as homepage
if( currenturl() == ROOT_URL || (currenturl() == ROOT_URL.'index.php' && $menu->url != 'index.php') ) {
	$sethome = router($homepg->url);
	redirect(ROOT_URL.$sethome, 301);
}


$menuattribs = json_decode($menu->attribs);



/* Set Widget Position Process
-------------------------------------------*/
$positions = [];

foreach($widgets as $widget)
{
	$out[$widget->id] = $widget->position;

	$assigned = json_decode($widget->menuassign)->assigned;
	$catview = json_decode($widget->menuassign)->catview;
	$canAccess = canAccess($widget->access);

	$assign = array_values((array)$assigned);
	$excludes = array_values((array)json_decode($widget->menuassign)->exclude);
	$groupassign = array_values((array)json_decode($widget->menuassign)->group);

	if(
	(in_array($menuid, $assign) && in_array($widget->id, array_keys($out)))
	|| (in_array($menuid, $assign))
	|| (in_array($menu->id, $assign) && in_array(getCurrentFilename(), whmcspages()))
	|| (in_array('All', $assign) && !in_array($menuid, $excludes) )
	|| (in_array($menuid, $assign) && $tplfile == 'homepage' )
	|| (in_array((int)$groupid, $groupassign) && !empty($component) && $component == 'products')
	) {
		if( $canAccess )
		$positions[] = $widget->position;
	}
}




/*
* Load component files and get values
* Set Page Type Output , Browser Title And Meta Tags
* Set body classes based on destination values
-------------------------------------------------------*/

$productgroupclass= $productclass='';
$allcatviewclass= $catviewclass= $postviewclass='';
$menuclass='';

if( !is_null($menu->id) )
	$menuclass = ' active-menu menu-'.$menu->id;


/** Load Component Files
-------------------------------------------*/
if( ($view_component && $component == 'products') || $tplfile == 'products' )
{
	include LIB_PATH.'/Client/com_product.php';

	if( $view == 'productgroup' )
	{
		$item_title = $groupname;
		$itemimg = '';
		$item_metadesc = (!empty($configs->metadesc) ? $configs->metadesc : (!empty($groupvalues->tagline) ? $groupvalues->tagline : ''));
		$item_metakeys = (!empty($configs->metakeys) ? $configs->metakeys : '');
		$prodgroupclass = ' product-group product-group-'.$groupvalues->id;
	}else
	// product detail
	if( $view == 'productdetail' )
	{
		$item_title = $item->name;
		$itemimg = (!empty($prodcmse->prod_image) ? $prodcmse->prod_image : '');
		$item_metadesc = (!empty($attribs->metadesc) ? $attribs->metadesc : $item->description);
		$item_metakeys = (!empty($attribs->metakeys) ? $attribs->metakeys : '');
		$featured = ($item->is_featured == 1 ? ' featured' : '');
		$productclass = ' product-detail product-'.$item->id.' parent-group-'.$item->gid.$featured;
	}

}else

// Cart view
if( $tplfilename === 'cart' )
{
	include LIB_PATH.'/Client/com_product_cart.php';
}else


// Get meta values when in post component
if( $view_component && $component == 'posts' )
{
	include LIB_PATH.'/Client/com_posts.php';

	if( $view == 'categories' )
	{
		$item_title = 'Categories';
		$itemimg = '';
		$item_metadesc = '';
		$item_metakeys = '';
		$allcatviewclass = ' all-categories'.$cat_bodyclass;
	}else

	if( $view == 'category' )
	{
		$item_title = $cat->title;
		$itemimg = (!empty($catconf->catimage) ? $catconf->catimage : '');
		$item_metadesc = (!empty($catconf->metadesc) ? $catconf->metadesc : $cat->description);
		$item_metakeys = (!empty($catconf->metakeys) ? $catconf->metakeys : '');

		$catviewclass = ' is-category category-'.$cat->id.$cat_bodyclass;
	}else

	if( $view == 'post' )
	{
		$item_title = $item->title;

		// social media alternative content process
		if( !empty($itemattribs->smpost) )
		{
			if( count($itemattribs->smpost) == 1 ) {
				$socialtitle = (!is_null($itemattribs->smpost[0]->title) ? $itemattribs->smpost[0]->title : '');
				$socialdesc = (!is_null($itemattribs->smpost[0]->desc) ? $itemattribs->smpost[0]->desc : '');
				$social_altimg = (!is_null($itemattribs->smpost[0]->image) ? $itemattribs->smpost[0]->image : '');
			}else{
				$socialrand = (array)$itemattribs->smpost;
				$socialrand = $socialrand[array_rand($socialrand)];
				$socialtitle = (!empty($socialrand->title) ? $socialrand->title : '');
				$socialdesc = (!empty($socialrand->desc) ? $socialrand->desc : '');
				$social_altimg = (!empty($socialrand->image) ? $socialrand->image : '');
			}
		}

		$itemimg = (!empty($item->post_image) ? $item->post_image : '');
		$item_metadesc = (!empty($item->metadesc) ? $item->metadesc : $item->post_content);
		$item_metakeys = (!empty($item->metakeys) ? $item->metakeys : '');
		$pageclass = (!empty($itemattribs->pageclass) ? ' '.$itemattribs->pageclass : '');

		$postviewclass = ' is-post post-'.$item->id.' parent-category-'.$item->catid . $pageclass;
	}
}




$favicon='';
if( !empty(modConfigs()->favicon) ) {
	$favicon = '<link rel="shortcut icon" href="'.IMAGES.modConfigs()->favicon.'" type="image/x-icon" />';
}

// custom head tags
$headtags=[];
if( !empty(modConfigs()->headtags) ) {
	$head_tags = explode("\n", modConfigs()->headtags);
	foreach($head_tags as $headtag) {
		$headtags[] = '<'.clean(html_entity_decode($headtag)).' />';
	}
}


// Meta Title
if( isset($menuattribs->browser_title)  && !empty($menuattribs->browser_title) ) {
	$metatitle = $menuattribs->browser_title;
}else
if( !empty($item_title) ) {
	$metatitle = $item_title;
}else
if( isset($menu->title) && !empty($menu->title) ) {
	$metatitle = $menu->title;
}else
if( $tplfile == 'products' && requestKey('gid') ) {
	$metatitle = groups()->where('id', getRequest('gid'))->value('name');
}else{
	// if none of above use default WHMCS page title
	$metatitle = $vars['pagetitle'];
}


// Meta Description
if( !empty($item_metadesc) ) {
	$metadesc = $item_metadesc;
}else
if( !empty(modConfigs()->meta_description) ) {
	$metadesc = modConfigs()->meta_description;
}
$meta_desc = str_replace('"', '', strip_tags(html_entity_decode($metadesc)));
$meta_desc = clean(truncText($meta_desc, 140), true);

// Meta Keywords
$metakeys='';
if( !empty($item_metakeys) ) {
	$metakeys = '<meta name="keywords" content="'.$item_metakeys.'" />';
}else
if( !empty(modConfigs()->meta_keywords) ) {
	$metakeys = '<meta name="keywords" content="'.modConfigs()->meta_keywords.'" />';
}



// Meta Tags Output
$ogmeta = '';
if( modConfigs()->ogmeta->og == 1 )
{
	$social_title = $metatitle;
	$social_desc = $meta_desc;

	if( !empty($socialtitle) ) {
		$social_title = $socialtitle;
	}
	if( !empty($socialdesc) ) {
		$social_desc = truncText($socialdesc, 120);
	}

	// Meta Image
	$twitimg= $ogimg='';
	if( !empty($social_altimg) ) {
		$twitimg = '<meta name="twitter:image" content="'.IMAGES.$social_altimg.'" />';
		$ogimg = '<meta property="og:image" content="'.IMAGES.$social_altimg.'" />';
	}else
	if( !empty($itemimg) ) {
		$twitimg = '<meta name="twitter:image" content="'.IMAGES.$itemimg.'" />';
		$ogimg = '<meta property="og:image" content="'.IMAGES.$itemimg.'" />';
	}else
	if( !empty(modConfigs()->default_social_img) ) {
		$socialimg = IMAGES.modConfigs()->default_social_img;
		$twitimg = '<meta name="twitter:image" content="'.$socialimg.'" />
		<meta name="twitter:image:src" content="'.$socialimg.'" />';
		$ogimg = '<meta property="og:image" content="'.$socialimg.'" />';
	}

	$ogmeta = '
	<base href="'.currenturl().'" />
	<link rel="canonical" href="'.currenturl().'" />
	'.$favicon.'
	<meta name="description" content="'.$meta_desc.'" />
	'.$metakeys.'
	<meta name="twitter:title" content="'.htmlentities($social_title).'" />
	<meta name="twitter:description" content="'.$social_desc.'" />
	<meta name="twitter:card" content="summary_large_image" />
	'.$twitimg.'
	<meta property="og:type" content="website" />
	<meta property="og:image:width" content="1200" />
	<meta property="og:image:height" content="628" />
	'.$ogimg.'
	<meta property="og:site_name" content="'.SITENAME.'" />
	<meta property="og:url" content="'.currenturl().'" />
	<meta property="og:title" content="'.htmlentities($social_title).'" />
	<meta property="og:description" content="'.$social_desc.'" />
	'.implode("\n", $headtags);
}





/* Assign Template Variables
* override smarty variable $pagetitle in core template
* Add page type classes to body tag
----------------------------------------------------------*/

$homeclass = (!is_null($homepg) ? ' ishome' : '');
$varclass = ' '.$tplfile.' '.$tplfilename.' '.tplVars('language');
$userclass = (tplVars('loggedin') == 1 ? ' loggedin' : '');
$bodyclass = [
	$varclass,
	$homeclass,
	$menuclass,
	$catviewclass,
	$postviewclass,
	$prodgroupclass,
	$productclass,
	$cartproduct_class,
	$cartgroup_class,
	$userclass
	];

// Arrange browser title display based on global configuration
$browsertitle = $metatitle.' - '.tplVars('companyname');
if( !empty(getConfigVal('sitename_title', true)) ) {
	$browsertitle = (!empty(getConfigVal('sitename_title_pos', true)) ? tplVars('companyname').' '.getConfigVal('sitename_title_sep').' '.$metatitle : $metatitle.' '.getConfigVal('sitename_title_sep').' '.tplVars('companyname'));
}




/*
* Output template configuration processor if the file exists in the template's root
* This also handles the assigning of templates to all page types
--------------------------------------------------------------------------------------*/
$assign_check = tplassign()->where('type', 'category')->select('resource')->get();
$assign_src = loadColumn($assign_check, 'resource');

$assign_check_menu = tplassign()->where('type', 'menu')->select('resource')->get();
$assign_src_menu = loadColumn($assign_check_menu, 'resource');

$assign_check_group = tplassign()->where('type', 'productgroup')->select('resource')->get();
$assign_src_group = loadColumn($assign_check_group, 'resource');

$assigned_tmpl='';

// category
if( ($view == 'category' && in_array((int)$category, $assign_src)) || ($view == 'post' && in_array(posts()->where('id', (int)$post)->value('catid'), $assign_src)) )
{
	if( $view == 'category' ) {
		$cat_id = (int)$category;
	}
	if( $view == 'post' ) {
		$cat_id = posts()->where('id', (int)$post)->value('catid');
	}

	$assigned_tmpl = tplassign()->where([['resource', $cat_id],['type', 'category']])->value('tmpl_id');
}

// product
if( ($view == 'productgroup' && in_array($groupid, $assign_src_group)) || ($view == 'productdetail' && in_array(products()->where('id', (int)$prodid)->value('gid'), $assign_src_group)) )
{
	if( $view == 'productgroup' ) {
		$group_id = $groupid;
	}
	if( $view == 'productdetail' ) {
		$group_id = products()->where('id', (int)$prodid)->value('gid');
	}

	$assigned_tmpl = tplassign()->where([['resource', $group_id],['type', 'productgroup']])->value('tmpl_id');
}

// menu item
if( !empty($menuid) && in_array($menuid, $assign_src_menu) ) {
	$assigned_tmpl = tplassign()->where([['resource', $menuid],['type', 'menu']])->value('tmpl_id');
}

// get template configs
if( !empty($assigned_tmpl) )
{
	$tplval = templates()->where('id', $assigned_tmpl)->get()[0];
	$parent_tpl = $tplval->parent_tpl;
	$params = tplConfig($tplval->name);

	include SITETPLS_DIR.'/'.$parent_tpl.'/_templateConfigs.php';
}else

if( file_exists(SITETPLS_DIR.'/'.getSetting('Template').'/_templateConfigs.php') )
{
	$params = tplConfig(cleanChars(getSetting('Template')));
	include SITETPLS_DIR.'/'.getSetting('Template').'/_templateConfigs.php';
}




// new line
$n = "\n";

$headcss = '
<link href="'.ASSET_URL.'/cmseglobal.css?v='.cmseft(ASSETPATH.'/cmseglobal.css').'" rel="stylesheet" type="text/css" />
<link href="'.ASSET_URL.'/cmsefof.css?v='.cmseft(ASSETPATH.'/cmsefof.css').'" rel="stylesheet" type="text/css" />
<link href="'.TMPL_URL.'/css/template.css" rel="stylesheet" type="text/css" />
<link href="'.LIB_URL.'/cmse/socialshare/rrssb.css" rel="stylesheet" type="text/css" />
<link href="'.LIB_URL.'/vendor/fancybox/jquery.fancybox.min.css" rel="stylesheet" type="text/css" />
';
// dynamically add stylesheet from template and widget if exist
if( !empty(tplVars('stylesheet')) && is_array(tplVars('stylesheet')) ) {
	foreach(tplVars('stylesheet') as $stylesheet) {
		$headcss .= '<link href="'.$stylesheet.'" rel="stylesheet" type="text/css" />'.$n;
	}
}


$headjs = '
<script src="'.ASSET_URL.'/jquery.matchHeight.min.js"></script>
<script src="'.LIB_URL.'/cmse/socialshare/rrssb.min.js"></script>
<script src="'.ASSET_URL.'/jquery.mousewheel.min.js"></script>
<script src="'.ASSET_URL.'/perfect-scrollbar.js"></script>
<script src="'.LIB_URL.'/vendor/fancybox/jquery.fancybox.min.js"></script>
<script src="'.ASSET_URL.'/ddaccordion.js"></script>
<script src="'.LIB_URL.'/cmse/slideshow/jssor.slider-27.5.0.min.js"></script>

';
// dynamically add javascript files from template and widget if exist
if( !empty(tplVars('scriptfile')) && is_array(tplVars('scriptfile')) ) {
	foreach(tplVars('scriptfile') as $scriptfile) {
		$headjs .= '<script src="'.$scriptfile.'"></script>';
	}
}
$headjs .= $n.'<script src="'.ASSET_URL.'/cmsefof.js"></script>';

customScript(html_entity_decode(modConfigs()->head_scripts));

// dynamically add custom scripts to head
if( !empty(tplVars('customscript')) && is_array(tplVars('customscript')) ) {
	foreach(tplVars('customscript') as $customscript) {
		$headjs .= $n.$customscript;
	}
}


if( $user ) {
	$logaction = '
	$(".viewlogout").css("visibility", "visible");
	$(".viewlogin").css("display", "none");
	';
}else{
	$logaction = '
	$(".viewlogout").css("display", "none");
	$(".viewlogin").css("visibility", "visible");
	';
}

// dynamically insert inline css from template and widgets if exist
$inlineCss = '
<style>
'.implode('', tplVars('headoutput')).'
</style>';



// dynamically insert inline javascript from template and widgets if exist
$inlineJs = '
<script>
	jQuery(function($) {
		$(".equalheight").matchHeight();
		$(".stickhead").sticky({ topSpacing: 0, zIndex: 9999 });
		'.$logaction.'
	});';
	if( !empty(tplVars('inlinejs')) && is_array(tplVars('inlinejs')) )
		$inlineJs .= implode('', tplVars('inlinejs'));
$inlineJs .= '
</script>';



// Remove some variables from the template
getSmarty()->clear_assign(['twitterusername', 'announcements']);


// Display Output To Smarty
getSmarty()->assign([
'position'			=> $positions,
'bodyclass'			=> implode('', $bodyclass),
'pagetitle'			=> $browsertitle,
'showsitename'		=> 0,
'productgroups'		=> $product_groups,
'productgroup'		=> $productgroup,
'productdetail'		=> $productdetail,
'postcategories'	=> $postcategories,
'category_view'		=> canAccess($cat, $category_view),
'postitem'			=> canAccess($item, $itemlayout),
'component'			=> $component,
'view'				=> $view,
// cart view
'productData'		=> $productData
]);
