<?php
/*
* Copyright (c) 2019 Emuzement Net Inc. All Rights Reserved
* License: EULA
* Author: Alex/Kumar/Manti/Lisa
*/


if( !defined("WHMCS") ) {
    die("This file cannot be accessed directly");
}

use \WHMCS\Application;
use \WHMCS\Database\Capsule;
use \WHMCS\Carbon;
use \WHMCS\Config\Setting;
use \WHMCS\Session;
// knp labs menu framework
use \Knp\Menu\MenuFactory;



// define stuff
define('MODNAME',		basename(__DIR__), true);
define('SITENAME',		getSetting('CompanyName'), true);
define('HOSTROOT_PATH',	filter_input(INPUT_SERVER, 'DOCUMENT_ROOT', FILTER_SANITIZE_STRING).'/', true);
define('ROOT_PATH',		dirname(__DIR__, 3).'/', true); // /home/user/public_html/whmcs/
define('ROOT_URL',		getSetting('SystemURL').'/', true); // http://site.com/whmcs/
define('IMGUPL',		$_FILES['post_image_upl'], true);
define('TIMEZONE',		date_default_timezone_set(modConfigs()->local_timezone), true);
define('MODPATH',		ROOT_PATH.'modules/addons/'.MODNAME);
define('MODURL',		ROOT_URL.'modules/addons/'.MODNAME);
define('SITETPL_PATH',	ROOT_PATH.'templates/'.getSetting('Template'));
define('SITETPL_URL',	ROOT_URL.'templates/'.getSetting('Template'));
define('SITETPLS_DIR',	ROOT_PATH.'templates');
define('TMPL_URL',		ROOT_URL.'modules/addons/'.MODNAME.'/templates/'.modvars()['template'], true);
define('TMPL_PATH',		MODPATH.'/templates/'.modvars()['template']);
define('TMPLS_DIR',		ROOT_PATH.'templates');
define('TEMPLATES',		ROOT_URL.'templates');
define('ASSETPATH',		MODPATH.'/assets');
define('ASSET_URL',		ROOT_URL.'modules/addons/'.MODNAME.'/assets', true);
define('LIB_PATH',		ROOT_PATH.'modules/addons/'.MODNAME.'/lib', true);
define('LIB_URL',		ROOT_URL.'modules/addons/'.MODNAME.'/lib', true);
define('IMGPATH',		ROOT_PATH.modConfigs()->imagesfolder);
define('IMAGES',		ROOT_URL.modConfigs()->imagesfolder.'/');
define('PUBLISHSTATE',	[1 => 'Published', 2 => 'Unpublished', 3 => 'Delete'], true); // PHP 7+, otherwise use const PUBLISHSTATE = []
define('ACCESS',		[0 => 'Public', 1 => 'Guest', 2 => 'Clients', 3 => 'Sales Operators', 4 => 'Support', 5 => 'Full Admins', 6 => 'Client Group'], true);
define('YESNO',			[1 => 'Yes', 0 => 'No']);
define('CMSETPL', 		ROOTDIR.'/modules/addons/'.MODNAME.'/_copyfiles/templates/sixflix');
define('CMSETPL_URL',	ROOT_URL.'modules/addons/'.MODNAME.'/_copyfiles/templates/sixflix');
define('LINENEW',		"\n");

define('DB_POSTS',		'mod_cmse_posts');
define('DB_CATS',		'mod_cmse_categories');
define('DB_MENUS',		'mod_cmse_menus');
define('DB_MENUGROUPS',	'mod_cmse_menugroups');
define('DB_WIDGETS',	'mod_cmse_widgets');
define('DB_TPLASSIGN',	'mod_cmse_tplassign');
define('DB_TPLMANAGER',	'mod_cmse_tplmanager');
define('DB_GLOBALCONFIG', 'tbladdonmodules');
define('DB_PRODUCTS', 	'tblproducts');
define('DB_BANNERS', 	'mod_cmse_banners');




/*
* Set Language From WHMCS Configuration
* Language files loaded from cmse module lang folder
* files must be .ini extension
* keywords which cannot be used unless double quoted: null, yes, no, true, false, on, off, none.
* eg: CONSTANT = "no true words are on"
*/
$language = parse_ini_file(MODPATH.'/lang/'.getSetting('Language').'.ini');

foreach($language as $key => $value) {
	define(strtoupper($key), $value);
}

$textlines = parse_ini_string(html_entity_decode(modConfigs()->cmse_texts));
foreach($textlines as $key => $val) {
	define($key, $val, true);
}

function iniParse($folder, $filename) 
{
	// get language file if exist
	if( file_exists($folder) ) 
	{
		// abort if neither file exists
		if( !file_exists($folder.'/'.$filename.'.ini') && !file_exists($folder.'/'.getSetting('Language').'.ini') ) {
			return;
		}
		
		// default language file must use the widget's name eg widget_pack.ini
		if( file_exists($folder.'/'.$filename.'.ini') ) {
			$language = parse_ini_file($folder.'/'.$filename.'.ini');
		}else
		// if a language file exists to match system default language eg: spanish.ini
		if( file_exists($folder.'/'.getSetting('Language').'.ini') ) {
			$language = parse_ini_file($folder.'/'.getSetting('Language').'.ini');
		}
		
		// define constants
		foreach($language as $key => $value) {
			define(strtoupper($key), $value);
		}
	}
}


function getSetting($value) {
	return Setting::getValue($value);
}

function getSmarty() {
	global $smarty;
	return $smarty;
}

function assign($var, $value, $multi=false) {
	if( $multi == true ) {
		return getSmarty()->assign();
	}else{
		return getSmarty()->assign($var, $value);
	}
}

// get current template variables
// getSmarty()->get_template_vars('pagetitle')
function tplVars($element='') {
	return getSmarty()->get_template_vars($element);
}

// get list of template directories in the module
function modTpl()
{
	$tmpldir = new \DirectoryIterator(ROOT_PATH.'modules/addons/'.MODNAME.'/templates/');
	$tmpls =[];
	foreach ($tmpldir as $tmpl) {
		if ($tmpl->isDir() && !$tmpl->isDot()) {
			$tmpls[$tmpl->getFilename()] = $tmpl->getFilename();
		}
	}

	return $tmpls;
}

function systpl() {
	global $systpl;

	return $systpl;
}

function endTplSession() {
	session_start();

	$_SESSION = array();

	if (ini_get("session.use_cookies")) {
		$params = session_get_cookie_params();
		//setcookie(session_name(), '', time() - 42000,
		setcookie(session_name(), '', '',
		$params["path"],
		$params["domain"],
		$params["secure"],
		$params["httponly"]
		);
	}

	session_destroy();
}


// database table connection
function posts() {
	return Capsule::table(DB_POSTS);
}

function categories() {
	return Capsule::table(DB_CATS);
}

function menus() {
	return Capsule::table(DB_MENUS);
}

function menugroups() {
	return Capsule::table(DB_MENUGROUPS);
}

function globalconfig() {
	return Capsule::table(DB_GLOBALCONFIG);
}

function widgets() {
	return Capsule::table(DB_WIDGETS);
}

function tplassign() {
	return Capsule::table(DB_TPLASSIGN);
}

function templates() {
	return Capsule::table(DB_TPLMANAGER);
}

function banners() {
	return Capsule::table(DB_BANNERS);
}

function products() {
	return Capsule::table(DB_PRODUCTS);
}

function cmseproducts() {
	return Capsule::table('mod_cmse_products');
}

function groups() {
	return Capsule::table('tblproductgroups');
}

function prices() {
	return Capsule::table('tblpricing');
}

function clientgroups() {
	return Capsule::table('tblclientgroups');
}

function fullAdmin($adminid) {
	if( Capsule::table('tbladmins')->select('id')->where([['id', $adminid], ['roleid', 1]])->get()[0] )
	return true;
}

function adminName($id) {
	$admin = getDbo('tbladmins')->select('firstname', 'lastname')->where('id', $id)->get()[0];
	return $admin->firstname.' '.$admin->lastname;
}

function catName($id) {
	return categories()->where('id', $id)->value('title');
}

function getDbo($table) {
	return Capsule::table($table);
}
// convert db column objects to single array
function loadColumn($columnvalues, $element) {
	$vals =[];
	foreach($columnvalues as $value) {
		$vals[] = $value->$element;
	}

	return $vals;
}

function setDate() {
	return Carbon::now()->toDateTimeString();
}

function sqlDate() {
	TIMEZONE;
	return date('Y-m-d H:i:s');
}

// get module variables for global distribution
function modvars() {
	$modvals = Capsule::table('tbladdonmodules')->select('setting','value')->where('module', MODNAME)->get();
	foreach($modvals as $val) {
		$vars[$val->setting] = $val->value;
	}
	return $vars;
}

// get module global configuration
function modConfigs() {
	return json_decode(modvars()['configs']);
}

function dbColumn($table, $column) {
	return Capsule::schema()->hasColumn($table, $column);
}

function getJson($table, $id, $col) {
	$configs = json_decode(getDbo('mod_cmse_'.$table)->where('id', $id)->value($col));

	return $configs;
}



function cmseUri($relative=false) {
	
	if( $relative == true ) {
		$uri = '/';
	}else{
		$uri = ROOT_URL;
	}

	return $uri;
}


function getNonSEF()
{
	$path = pathinfo(currenturl());
	$filename = $path['filename'];
	$dirnames = explode('/', $path['dirname']);
	preg_match('#[^\/]+$#i', $path['dirname'], $match);


	// product detail and post view
	if( $path['dirname'] == substr(ROOT_URL,0,-1) )
	{
		// get items with menu ID
		// index.php?component=products&view=productgroup&gid=5-web-hosting&menuid=12-shared-hosting
		//menus()->whereIn('type', [1,2,3,5,6])->where('published', 1)->pluck('url');
		
		$postid = posts()->where('alias', getCurrentFilename())->value('id');
		$cat_id = categories()->where('alias', getCurrentFilename())->value('id');

		$groupval = cmseproducts()->select('group_id', 'group_alias')->where('group_alias', $filename)->get()[0];

		if( !empty($postid) ) {
			$queryurl = parse_url(menus()->where([['type', 3], ['src_id', $postid]])->value('url'))['query'];
		}else
		if( !empty($cat_id) ) {
			$url = menus()->where([['src_id', $cat_id], ['type', 2]])->value('url');
			if( !empty($url) ) {
				$queryurl = parse_url($url)['query'];
			}else{
				// category has no menu item
				$queryurl = 'component=posts&view=category&category='.$cat_id.'-'.getCurrentFilename();
			}
		}else
		// product category
		if( $filename == $groupval->group_alias ) {
			$queryurl = 'component=products&view=productgroup&gid='.$groupval->group_id.'-'.$groupval->group_alias;
		//}else
			//index.php?component=products&view=productgroups&menuid=25-all-services
		//if( in_array($filename, menus()->where('type', 5)->pluck('alias')) ) {
		//	$queryurl = parse_url(menus()->where('alias', getCurrentFilename())->value('url'))['query'];
		}else{
			$queryurl = parse_url(menus()->where('alias', getCurrentFilename())->value('url'))['query'];
		}

	}else

	{
		// if view is post and has category alias in url but does not have an assigned menu
		$postval = posts()->select('id', 'catid', 'alias')->where('alias', $filename)->get()[0];

		$prodval = cmseproducts()
		->select('prod_alias', 'prod_id', 'prod_gid')
		->where('prod_alias', $filename)
		->get()[0];

		if( $filename == $postval->alias ) {
			$posturl = menus()->select('id', 'url', 'src_id')->where([['src_id', $postval->catid],['type', 2]])->get()[0];
			parse_str(parse_url($posturl->url)['query'], $urlparts);

			$queryurl = 'component='.$urlparts['component'].'&view=post&category='.$urlparts['category'].'&post='.$postval->id.'-'.$path['filename'].'&menuid='.$urlparts['menuid'];
		}else

		// component is products
		if( $filename == $prodval->prod_alias ) {
			$prodgroup = cmseproducts()->where('group_id', $prodval->prod_gid)->value('group_alias');
			$queryurl = 'component=products&view=productdetail&gid='.$prodval->prod_gid.'-'.$prodgroup.'&pid='.$prodval->prod_id.'-'.$prodval->prod_alias;
		}

	}


	$queryurl = html_entity_decode($queryurl);
	$srcId = getCurrentFilename().'&';
	
	// get query elements
	$view		= getInput($queryurl, 'view');
	$category	= getInput($queryurl, 'category');
	$post		= getInput($queryurl, 'post');
	//if( strstr(currenturl(), '&') != false ) {
	//	$menuid = menus()->whereRaw("url REGEXP '".$srcId."'")->value('id');
	//}else{
		$menuid	= str_replace('-', '', (int)getInput($queryurl, 'menuid'));
	//}
	$listpage	= getInput($queryurl, 'listpage');
	$prodid		= getInput($queryurl, 'pid');
	$groupid	= getInput($queryurl, 'gid');
	$parent		= $match[0];

	// registered components
	$com_posts = ['post', 'category', 'categories'];
	$com_product = ['productdetail', 'productgroup', 'productgroups'];

	// the decider (roger)
	if( in_array($view, $com_product) ) {
		$component	= 'products';
	}else
	if( in_array($view, $com_posts) ) {
		$component	= 'posts';
	}

	$list = [$component, $view, $category, $post, $menuid, $listpage, $prodid, $groupid, $parent];

	return $list;
}



function router($url)
{
	$parts = parse_url(ROOT_URL.$url);
	parse_str($parts['query'], $q);

	$component	= $q['component'];
	$view		= $q['view'];
	$category	= $q['category'];
	$post		= $q['post'];
	$menuid		= $q['menuid'];
	$prodgroup	= $q['gid'];
	$prodid		= $q['pid'];


	if( isset($component) )
	{
		if( $view == 'post' && isset($post) && !isset($category) && isset($menuid) ) {
			$num = (int)$post;
			$route = str_replace($num.'-', '', $post);
		}else
			// posts without menu id uses category alias in url
		if( $view == 'post' && isset($post) && isset($category) ) {
			$num = (int)$post;
			$nums = (int)$category;
			$route = str_replace($nums.'-', '', $category).'/'.str_replace($num.'-', '', $post);
		}else
		// posts category view
		if( $view == 'category' && isset($category) ) {
			$num = (int)$category;
			$route = str_replace($num.'-', '', $category);
		}else
		if( $view == 'categories' ) {
			$num = (int)$menuid;
			$route = str_replace($num.'-', '', $menuid);
		}else

		// product detail view
		if( $view == 'productdetail' && isset($prodgroup) && isset($prodid) ) {
			$route = preg_replace('#\d+\-#', '', strtolower($prodgroup)).'/'.preg_replace('#\d+\-#', '', $prodid);
		}else

		if( isset($view) && $view == 'productgroup' && isset($prodgroup) ) {
			$num = (int)$prodgroup;
			$route = str_replace($num.'-', '', $prodgroup);
		}else
		if( isset($view) && $view == 'productgroups' ) {
			$num = (int)$menuid;
			$route = str_replace($num.'-', '', $menuid);

			if( pathinfo(currenturl())['filename'] == 'cart' && !requestKey('a') ) {
				redirect(str_replace($num.'-', '', $menuid), 301);
			}
		}

	}else{
		// default urls
		$route = $url;
	}
	//debug($route);
	return $route;
}


function getActiveMenu()
{
	$murl = str_replace(ROOT_URL, '', currenturl());
	if( requestKey('menuid') ) {
		$active = menus()->select('id')->where('id', getRequest('menuid'))->get()[0];
	}else
	if( tplVars('templatefile') == 'homepage' ) {
		$active = menus()->select('id')->where('homepage', 1)->get()[0];
	}else{
		$active = menus()->select('id')->where('url', $murl)->get()[0];
	}

	return $active;
}


function getInput($url, $element='')
{
	parse_str($url, $url_elements);

	if( $element !== '' ) {
		return $url_elements[$element];
	}else{
		return $url_elements;
	}
}


// global date format set in WHMCS
function dateFormat($date, $format='')
{
	TIMEZONE;
	if( Setting::getValue('ClientDateFormat') != '' ) {
		$whmcstime = Setting::getValue('ClientDateFormat');
	}else{
		$whmcstime = Setting::getValue('DateFormat');
	}
	switch($whmcstime)
	{
		case 'MM/DD/YYYY': $reform = 'F j, Y, g:i a'; break;
		case 'DD/MM/YYYY': $reform = 'D M j, Y, g:i a'; break;
		case 'DD.MM.YYYY': $reform = 'D M j, Y, g:i a'; break;
		case 'DD-MM-YYYY': $reform = 'D M j, Y, g:i a'; break;
		case 'YYYY/MM/DD': $reform = 'Y M j, g:i a'; break;
		case 'YYYY-MM-DD': $reform = 'Y M j, g:i a'; break;
		case 'full': $reform = 'jS F Y, g:i a'; break;
		case 'shortmonth': $reform = 'jS M Y, g:i a'; break;
		case 'fullday': $reform = 'l, F jS, Y, g:i a'; break;
	}

	if( $format != '' ) {
		$dateformat = date('m/d/Y <\b\r> g:i a', strtotime($date));
	}else{
		$dateformat = date($reform, strtotime($date));
	}


	return $dateformat;
}

function currency() {
	// use formatCurrency() method to get currency symbol
	$currency = Capsule::table('tblcurrencies')->where('default', 1)->get()[0];
	return $currency;
}

function text($slug, $default='')
{
	if( !defined($slug) && !empty($default) ) {
		$text = $default;
	}else{
		$text = LANG::trans($slug);
	}

	return $text;
}

function itemPrice($id, $paytype, $priceall=false, $pricetotal=false, $nowrapper=false, $nocurr=false)
{
	$price = prices()->where('relid', $id)->get()[0];
	$prefix = currency()->prefix;
	$suffix = currency()->suffix;

	// texts
	$free			= FREE;
	$no_servicefee	= NO_SERVICE_FEE;
	$service_fee	= SERVICE_FEE;
	$total			= TOTAL;

	// set wrappers
	$wrapper = '<div class="price-list">';
	$wrapend = '</div>';
	$pwrap = '<p>'; $pend = '</p>';
	if( $nowrapper ) {
		$wrapper= $wrapend= $pwrap= $pend='';
	}

	if( $paytype == 'free' ) {
		$priceout = '<strong>'.$free.'</strong>';
	}else

	if( $paytype == 'recurring' )
	{
		$notset	= ['-1.00', '0.00'];

		$month = (
			!in_array($price->monthly, $notset) && $pricetotal ? '
			<div class="monthly">
				<h5>'.text('orderpaymenttermmonthly').'</h5>
				<dl>
					<dt>'.$prefix.$price->monthly.$suffix.'</dt>
					<dd>'.text('orderpaymenttermmonthly').'</dd>
				</dl>
				<dl>
					<dt>'.$prefix.$price->msetupfee.$suffix.'</dt>
					<dd>'.($price->msetupfee != '0.00' ? $service_fee : $no_servicefee).'</dd>
				</dl>
				<dl>
					<dt>'.$prefix.($price->msetupfee != '0.00' ? ($price->monthly+$price->msetupfee) : $price->monthly).$suffix.'</dt>
					<dd>'.$total.'</dd>
				</dl>
			</div>
			' :
				(
				!in_array($price->monthly, $notset) ?
				$pwrap.'
					<strong>'.$prefix.$price->monthly.$suffix.'</strong>
					<span>'.text('orderpaymenttermmonthly').'</span>'
				.$pend
				 : ''
				)
			);

		$quarter = (
			!in_array($price->quarterly, $notset) && $pricetotal == true ? '
			<div class="quarterly">
				<h5>'.text('orderpaymenttermquarterly').'</h5>
				<dl>
					<dt>'.$prefix.$price->quarterly.$suffix.'</dt>
					<dd>'.text('orderpaymenttermquarterly').'</dd>
				</dl>
				<dl>
					<dt>'.$prefix.$price->qsetupfee.$suffix.'</dt>
					<dd>'.($price->qsetupfee != '0.00' ? $service_fee : $no_servicefee).'</dd>
				</dl>
				<dl>
					<dt>'.$prefix.($price->qsetupfee != '0.00' ? ($price->quarterly+$price->qsetupfee) : $price->quarterly).$suffix.'</dt>
					<dd>'.$total.'</dd>
				</dl>
			</div>
			' :
				(
				!in_array($price->quarterly, $notset) ? '
				<dl class="quarterly">
					<dt>'.$prefix.$price->quarterly.$suffix.'</dt>
					<dd>'.text('orderpaymenttermquarterly').'</dd>
				</dl>
				' : ''
				)
			);

		$semi = (
			!in_array($price->semiannually, $notset) && $pricetotal == true ? '
			<div class="semiannually">
				<h5>'.text('orderpaymenttermsemiannually').'</h5>
				<dl>
					<dt>'.$prefix.$price->semiannually.$suffix.'</dt>
					<dd>'.text('orderpaymenttermsemiannually').'</dd>
				</dl>
				<dl>
					<dt>'.$prefix.$price->ssetupfee.$suffix.'</dt>
					<dd>'.($price->ssetupfee != '0.00' ? $service_fee : $no_servicefee).'</dd>
				</dl>
				<dl>
					<dt>'.$prefix.($price->ssetupfee != '0.00' ? ($price->semiannually+$price->ssetupfee) : $price->semiannually).$suffix.'</dt>
					<dd>'.$total.'</dd>
				</dl>
			</div>
			' :
				(
				!in_array($price->semiannually, $notset) ? '
				<dl class="semiannually">
					<dt>'.$prefix.$price->semiannually.$suffix.'</dt>
					<dd>'.text('orderpaymenttermsemiannually').'</dd>
				</dl>
				' : ''
				)
			);

		$year = (
			!in_array($price->annually, $notset) && $pricetotal == true ? '
			<div class="annually">
				<h5>'.text('orderpaymenttermannually').'</h5>
				<dl>
					<dt>'.$prefix.$price->annually.$suffix.'</dt>
					<dd>'.text('orderpaymenttermannually').'</dd>
				</dl>
				<dl>
					<dt>'.$prefix.$price->asetupfee.$suffix.'</dt>
					<dd>'.($price->asetupfee != '0.00' ? $service_fee : $no_servicefee).'</dd>
				</dl>
				<dl>
					<dt>'.$prefix.($price->asetupfee != '0.00' ? ($price->annually+$price->asetupfee) : $price->annually).$suffix.'</dt>
					<dd>'.$total.'</dd>
				</dl>
			</div>
			':
				(
				!in_array($price->annually, $notset) ? '
				<dl class="annual">
					<dt>'.$prefix.$price->annually.$suffix.'</dt>
					<dd>'.text('orderpaymenttermannually').'</dd>
				</dl>
				' : ''
				)
			);

		$twoyear = (
			!in_array($price->biennially, $notset) && $pricetotal == true ? '
			<div class="biennially">
				<h5>'.text('orderpaymenttermbiennially').'</h5>
				<dl>
					<dt>'.$prefix.$price->biennially.$suffix.'</dt>
					<dd>'.text('orderpaymenttermbiennially').'</dd>
				</dl>
				<dl>
					<dt>'.$prefix.$price->bsetupfee.$suffix.'</dt>
					<dd>'.($price->bsetupfee != '0.00' ? $service_fee : $no_servicefee).'</dd>
				</dl>
				<dl>
					<dt>'.$prefix.($price->bsetupfee != '0.00' ? ($price->biennially+$price->bsetupfee) : $price->biennially).$suffix.'</dt>
					<dd>'.$total.'</dd>
				</dl>
			</div>
			' :
				(
				!in_array($price->biennially, $notset) ? '
				<dl class="biennially">
					<dt>'.$prefix.$price->biennially.$suffix.'</dt>
					<dd>'.text('orderpaymenttermbiennially').'</dd>
				</dl>
				' : ''
				)
			);

		$threeyear = (
			!in_array($price->triennially, $notset) && $pricetotal == true ? '
			<div class="triennially">
				<h5>'.text('orderpaymenttermtriennially').'</h5>
				<dl>
					<dt>'.$prefix.$price->triennially.$suffix.'</dt>
					<dd>'.text('orderpaymenttermtriennially').'</dd>
				</dl>
				<dl>
					<dt>'.$prefix.$price->tsetupfee.$suffix.'</dt>
					<dd>'.($price->tsetupfee != '0.00' ? $service_fee : $no_servicefee).'</dd>
				</dl>
				<dl>
					<dt>'.$prefix.($price->tsetupfee != '0.00' ? ($price->triennially+$price->tsetupfee) : $price->triennially).$suffix.'</dt>
					<dd>'.$total.'</dd>
				</dl>
			</div>
			' :
				(
				!in_array($price->triennially, $notset) ? '
				<dl class="triennially">
					<dt>'.$prefix.$price->triennially.$suffix.'</dt>
					<dd>'.text('orderpaymenttermtriennially').'</dd>
				</dl>
				' : ''
				)
			);

		$price_all='';
		if( $priceall )
			$price_all = $quarter . $semi . $year . $twoyear . $threeyear;


		$priceout = $wrapper.$month.$price_all.$wrapend;
	}else

	if( $paytype == 'onetime' ) {
		$priceout = '<strong>'.$prefix.$price->monthly.$suffix.'</strong>';
		if( $nocurr )
			$priceout = $price->monthly;
	}

	return $priceout;
}


// get menu group for menu widget
function menugroup($groupid) {
	$menuitems = menus()->where([
	['published', 1],
	['menugroup', $groupid]
	])->get();

	return $menuitems;
}






// get category configuration
function catData($id) {
	$catval = Capsule::table(DB_CATS)->where('id', $id)->get();
	$catval = $catval[0];

	return $catval;
}



// get post item object
function postitem() {
	preg_match('#\d+#s', getRequest('page'), $id);
	$post = Capsule::table(DB_POSTS)->where('id', $id[0])->get();
	$post = $post[0];

	return $post;
}


// get the last ID in table
function lastId($table) {
	$last = end($table()->select('id')->get())->id;
	$last = ($last+1);

	return $last;
}

function getConfigVal($query, $check=false, $default='', $select='')
{
	$val = (!is_null(modConfigs()->$query) ? modConfigs()->$query : $default);
	if( $check == true)
	{
		if( strstr($query, ',') )
		{
			$str = explode(',', $query);
			$b = (string)$str[0];
			$p = (string)$str[1];
			$query = modConfigs()->$b->$p;
		}else{
			$query = modConfigs()->$query;
		}
		$val = ($query == 1 ? 'checked' : '');
	}

	if( $select != '' ) {
		$val = ((modConfigs()->$query == $select) || (modConfigs()->$query == $select && $select == $default) ? 'selected' : '');
	}

	return $val;
}




/* Document Elements
-----------------------------*/
// get file modify time
function cmseft($file, $convert=false) 
{
	if( strstr($file, (string)$_SERVER["SERVER_NAME"]) ) {
		$file = str_replace(ROOT_URL, ROOT_PATH, $file);
	}
	$val='';
	if( file_exists($file) ) 
	{
		$val = md5(filemtime($file));
		
		if( $convert ) {
			$makedate = filemtime($file);
			clearstatcache();
			$val = date('m-d-Y|H-i-s', $makedate);
		}
	}
	
	return $val;
}


// widgets only - TODO Fix the damn thing!
function inline_Css($css) {
	if( $css != '' )
	return '<style>'. $css . '</style>';
}
function inline_Js($js) {
	$n = "\n";
	if( $js != '' )
	return '<script>'. $js . $n.'</script>';
}

// templates
function inlineCss($css) {
	return getSmarty()->append('headoutput', $css, true);
}

function inlineJs($js) {
	return getSmarty()->append('inlinejs', $js);
}

function styleSheet($stylesheet, $attribs=[]) 
{
	$val=[];$v='';
	if( !empty($attribs) ) 
	{
		foreach($attribs as $key=>$att) 
		{
			if( $key === 'ft' )
				$att = cmseft($stylesheet, true);
			$val[] = '&'.$key.'='.$att;
		}
		
		$v = '?css=v'.implode('', $val);
	}

	return getSmarty()->append('stylesheet', $stylesheet.$v);
}

function scriptFile($scriptfile) {
	return getSmarty()->append('scriptfile', $scriptfile);
}

function customScript($script) {
	return getSmarty()->append('customscript', $script);
}

function customFootScript($script) {
	return getSmarty()->append('customfootscript', $script);
}


function metatags()
{
	$itemimg = ROOT_URL.'images/posts/'.postitem()->post_image;
	if( !empty(postitem()->metadesc) ) {
		$metadesc = postitem()->metadesc;
	}else{
		$metadesc = truncText(html_entity_decode(postitem()->post_content), 140);
		$metadesc = htmlentities($metadesc);
	}

	$metakeys='';
	if( !empty(postitem()->metakeys) ) {
		$metakeys = '<meta name="keywords" content="'.postitem()->metakeys.'" />';
	}

	$favicon='';
	if( !empty(modConfigs()->favicon) ) {
		$favicon = '<link rel="shortcut icon" href="'.ROOT_URL.modConfigs()->favicon.'" type="image/x-icon" />';
	}

	// custom head tags
	$headtags=[];
	if( !empty(modConfigs()->headtags) ) {
		$head_tags = explode("\n", modConfigs()->headtags);
		foreach($head_tags as $headtag) {
			$headtags[] = '<'.clean(html_entity_decode($headtag)).' />';
		}
	}

	$og = modConfigs()->ogmeta->og;
	if( $og == 1 )
	{
		$ogmeta = '
		<link rel="canonical" href="'.currenturl().'" />
		'.$favicon.'
		<meta name="description" content="'.$metadesc.'" />
		'.$metakeys.'
		<meta name="twitter:title" content="'.htmlentities(postitem()->title).'" />
		<meta name="twitter:description" content="'.$metadesc.'" />
		<meta name="twitter:card" content="summary_large_image" />
		<meta name="twitter:image" content="'.$itemimg.'" />
		<meta property="og:image:width" content="600" />
		<meta property="og:image:height" content="315" />
		<meta property="og:site_name" content="'.SITENAME.'" />
		<meta property="og:url" content="'.currenturl().'" />
		<meta property="og:title" content="'.htmlentities(postitem()->title).'" />
		<meta property="og:description" content="'.$metadesc.'" />
		<meta property="og:image" content="'.$itemimg.'" />
		'.implode("\n", $headtags);

		return $ogmeta;
	}
}




function headjs() {
	modConfigs();
}


// get current page body
function getbody($filename)
{
	$file = file_get_contents($filename);
	$dom = new DOMDocument;
	$dom->loadHTML($file);
	$bodies = $dom->getElementsByTagName('body');
	assert($bodies->length === 1);
	$body = $bodies->item(0);

	for ($i = 0; $i < $body->children->length; $i++) {
		$body->remove($body->children->item($i));
	}

	$stringbody = $dom->saveHTML($body);
	return $stringbody;
}



function footjs()
{
	$socialapi = modConfigs()->socialapi;
	$n = "\n";

	$fb= $twt= $gp= $ig= $pin='';
	if( in_array('fb', $socialapi) ) {
		$fb = '
		<div id="fb-root"></div>
		<script type="text/javascript">
		(function(d, s, id) {
		  var js, fjs = d.getElementsByTagName(s)[0];
		  if (d.getElementById(id)) return;
		  js = d.createElement(s); js.id = id;
		  js.src = "//connect.facebook.net/en_US/all.js#xfbml=1";
		  fjs.parentNode.insertBefore(js, fjs);
		}(document, "script", "facebook-jssdk"));
		</script>'.$n;
	}

	if( in_array('twit', $socialapi) ) {
		$twt = '
		<script>!function(d,s,id){var js,fjs=d.getElementsByTagName(s)[0],p=/^http:/.test(d.location)?\'http\':\'https\';if(!d.getElementById(id)){js=d.createElement(s);js.id=id;js.src=p+"://platform.twitter.com/widgets.js";fjs.parentNode.insertBefore(js,fjs);}}(document,"script","twitter-wjs");</script>
		<script async src="//platform.twitter.com/widgets.js" charset="utf-8"></script>
		'.$n;
	}

	if( in_array('gplus', $socialapi) ) {
		$gp = '
		<script>(function() {
			window.___gcfg = {lang: "en"};
			var po = document.createElement("script"); po.type = "text/javascript"; po.async = true;
			po.src = "https://apis.google.com/js/plusone.js";
			var s = document.getElementsByTagName("script")[0]; s.parentNode.insertBefore(po, s);
		  })();
		</script>
		'.$n;
	}

	if( in_array('ig', $socialapi) ) {
		$ig = '<script src="//platform.instagram.com/en_US/embeds.js" type="text/javascript" defer></script>'.$n;
	}

	if( in_array('pin', $socialapi) ) {
		$pin = '<script async defer src="//assets.pinterest.com/js/pinit.js"></script>'.$n;
	}

	return $fb . $twt . $gp . $ig . $pin;
}


// Load Preset Format
function layoutPreset()
{
	$pre = file_get_contents(ASSETPATH.'/layoutpreset/preset.txt');
	echo '<ul style="display: none;">'.$pre.'</ul>';
	preg_match_all('#\<li id=\"(.*?)\"\>#i', $pre, $matches, PREG_SET_ORDER);

	return $matches;
}



/* Form Fields
-----------------------------------*/
function fieldset($attribs=[])
{
	$attribs = (object)$attribs;

	$setclass= $innerclass= $setlabel= $labelclass= $innercontainer= $innercontainerend='';
	if( isset($attribs->slide) )
	{
		$setclass = ' class="groupslide"';
		$innercontainer = '<div'.(isset($attribs->innerclass) ? ' class="'.$attribs->innerclass.'"' : '').'>';
		$innercontainerend = '</div>';
		$labelclass = ' class="slidetab"';
		$setlabel = '<h5'.$labelclass.'><span class="title">'.(isset($attribs->setlabel) ? $attribs->setlabel : '').'</span></h5>';
		$slideclass = ' class="slidecontent"';
	}

	$info = (isset($attribs->info) ? '<small class="info">'.$attribs->info.'</small>' : '');

	if( isset($attribs->start) ) {
		echo '<fieldset'.$setclass.'>
		'.$setlabel.'
		<div'.$slideclass.'>'.$info.$innercontainer;
	}

		if( isset($attribs->end) ) {
		echo $innercontainerend.'</div>
	</fieldset>';
		}
}

// set a passable variable to tinymce php plug script
// to determin what toolbar to use
// the value is sent via the field() attribs
$tb='';
function getToolBar($toolbar) {
	global $tb;
	$tb = $toolbar;
	return $tb;
}
function mcegt() {
	global $tb;
	return $tb;
}

function field($type, $name, $value='', $options=[], $label='', $attribs=[], $info='')
{
	$wrapclass= $fieldattr= $field_class= $toggle= $nodisplay= $wrapid='';
	if( !empty($attribs) && is_array($attribs) )
	{
		$class=[]; $fieldclass=[]; $attrib=[];
		foreach($attribs as $key => $val)
		{
			if( $key == 'class' ) {
				$class[] = ' '.$val;
			}else
			if( $key == 'fieldclass' ) {
				$fieldclass[] = ' '.$val;
			}else
			if( $key == 'showon' )
			{
				$wrapid = 'id="'.$name.'" ';
				$src = explode(':', $val);
				$toggle = '
				<script>
				cmseToggle("select[name='.$src[0].']", "'.$src[1].'", "div#'.$name.'");
				</script>
				';
				$nodisplay = ' style="display: none;"';
			}else
			if( $key == 'data-toolbar' ) {
				getToolBar($val);
			}else{
				$attrib[] = ' '.$key.'="'.$val.'"';
			}
		}

		$field_class = implode('', $fieldclass);
		$wrapclass = implode('', $class);
		$fieldattr = implode('', $attrib);
	}

	$info = (!empty($info) ? '<small class="info">'.$info.'</small>' : '');
	$label = (!empty($label) ? '<div class="control-label">'.$label.'</div>' : '');

	$noflex = (isset($attribs['noflex']) ? '</div><div>' : '');
	if( $type == 'sep' ) echo '<hr />';

	$fieldwrap = $noflex.'<div '.$wrapid.'class="control-group'.$wrapclass.'"'.$nodisplay.'>'.$label.$info.'<div class="control">';
	$fieldend = '</div></div>';



	// textarea
	if( $type == 'textarea' )
	{
		$field_class = (!empty($field_class) ? 'class="'.$field_class.'"' : '');
		echo $fieldwrap;
		echo '<textarea name="'.$name.'"'.$fieldattr.$field_class.'>'.$value.'</textarea>';
		echo $fieldend;
	}
	// text
	if( $type == 'text' || $type == 'checkbox' || $type == 'radio' || $type == 'number')
	{
		$field_class = (!empty($field_class) ? 'class="'.$field_class.'"' : '');
		echo $fieldwrap;
		echo '<input type="'.$type.'" name="'.$name.'" value="'.$value.'"'.$fieldattr.$field_class.' />';
		echo $fieldend;
	}
	// hidden
	if( $type == 'hidden' ) {
		echo '<input type="'.$type.'" name="'.$name.'" value="'.$value.'"'.$fieldattr.' />';
	}
	// select
	if( $type == 'select' && !empty($options) )
	{
		if( $value == 'choose' ) {
			$nulloption = '<option value="">-- Choose --</option>';
		}else
		if( $value == 'default' ) {
			$nulloption = '<option value="">-- Use Default --</option>';
		}else
		if( $value == '' ) {
			$nulloption = '';
		}
		echo $fieldwrap;
		echo '<select name="'.$name.'"'.$fieldattr.'>';
		echo $nulloption;
		foreach($options as $key => $val) {
			$selected = ($key == $value ? ' selected' : '');
			echo '<option value="'.$key.'"'.$selected.'>'.$val.'</option>';
		}
		echo '</select>';
		echo $fieldend;
		echo $toggle;
	}
	// select opt group
	if( $type == 'optgroup' && !empty($options) )
	{
		echo $fieldwrap;
		echo '<select name="'.$name.'"'.$fieldattr.'>';
		foreach($preset as $keys => $grp) {
			echo '<optgroup label="'.$keys.'">';
				foreach($grp as $vall => $txt) {
					echo '<option value="'.$vall.'">'.$txt.'</option>';
				}
			echo '</optgroup>';
		}
		echo '</select>';
		echo $fieldend;
	}
	// image upload
	if( $type == 'image' )
	{
		echo $fieldwrap;
		echo imageManager($name, $value);
		echo $fieldend;
	}
	// button
	if( $type == 'button' )
	{
		$field_class = ' class="btn'.$field_class.'"';
		echo '<button type="submit" name="'.$name.'"'.$fieldattr.$field_class.' >'.$value.'</button>';
	}

}




/* XML Form Fields
----------------------------------*/
function formFields($fieldsxml, $fieldsrc='', $id='', $fieldnames=false)
{
	$fields = simplexml_load_file($fieldsxml.'.xml');

	if( !isset($fields->fields) ) {
		return;
	}

	$params=[];

	if( $fieldsrc == 'template' ) {
		$tpl = templates()->where('id', $id)->get()[0];
		$params = json_decode($tpl->configs);
	}else
	if( $fieldsrc == 'widget' && !empty($id) ) {
		$widget = widgets()->where('id', $id)->get()[0];
		$params = json_decode($widget->params);
	}


	// restrict field to admins set in global config
	$adminallowed = in_array(Session::get('adminid'), modConfigs()->admin_restrict);


	$output = [];
	foreach($fields->fields->fieldset as $fieldset)
	{
		$html='';
		foreach($fieldset->field as $field)
		{
			$att = $field->attributes();

			if( $att->type != 'divopen' || $att->type != 'divclose' ) {
				if( (!isset($att->type) || empty($att->type)) )
					echo 'error: missing name and or type attribute';
			}

			// convert field name to string to append
			$namestring = (string)$att->name;

			//$value = $params->$namestring;


			/* output field attributes
			-----------------------------------*/
			// default value
			if( !empty($params->$namestring) ) {
				$value = $params->$namestring;
			}else
			if( isset($att->value) && !empty($att->value) ) {
				$value = $att->value;
			}else{
				$value = '';
			}


			$min='';
			if( isset($att->min) )
				$min = ' min="'.$att->min.'"';
			$max='';
			if( isset($att->max) )
				$max = ' max="'.$att->max.'"';
			$multiple='';
			if( isset($att->multiple) )
				$multiple = ' multiple="multiple"';
			$size='';
			if( isset($att->size) )
				$size = ' size="'.$att->size.'"';
			$class='';
			if( isset($att->class) && !empty($att->class) )
				$class = ' '.$att->class;
			$label='';
			if( isset($att->label) && !empty($att->label) ) 
				$label = '<div class="control-label"><label>'.(defined($att->label) ? constant($att->label) : $att->label).'</label></div>';
			
			$info='';
			if( isset($att->info) && !empty($att->info) )
				$info = '<small class="info">'.(defined($att->info) ? constant($att->info) : $att->info).'</small>';
			$divclass='';
			if( isset($att->divclass) )
				$divclass = ' class="'.$att->divclass.'"';
			$placeholder='';
			if( isset($att->placeholder) )
				$placeholder = ' placeholder="'.(defined($att->placeholder) ? constant($att->placeholder) : $att->placeholder).'"';
			$emptyelement='';
			if( isset($att->emptyelement) )
				$emptyelement = '<div id="'.$att->emptyelement.'"></div>';

			if( $att->type == 'number' ) {
				$fieldtype = '"number"';
			}else
			if( $att->type == 'color' ) {
				$fieldtype = '"text" id="colorfield" class="colorfield" data-control="hue" data-format="rgb" data-opacity="1" ';
			}else{
				$fieldtype = '"text"';
			}

			// define element ID
			$idelem = (isset($att->id) ? $att->id : $att->name);

			// set toggler
			$toggle= $togglestate='';
			if( isset($att->showon) )
			{
				$elements = explode(':', $att->showon);
				$selector = $elements[0];
				$optval = $elements[1];
				$togglestate = ' style="display: none"';

				$toggle = '
				<script>
				jQuery(function($) {
				$("select[name='.$selector.']").slideopen("#'.$idelem.'", "'.$optval.'");
				});
				</script>
				';
			}

			// output fields
			$open = $toggle.'
			<div id="'.$idelem.'" class="control-group'.$class.'"'.$togglestate.'>
			'.$label . $info.'
			<div class="control">
			';
			$close = '</div></div>';

			// field grouping wrapper
			$addslide= $slide2class= $slide2script= $flexwrap='';

			if( $att->type == 'divopen' ) {
				$div_id = (isset($att->id) ? ' id="'.$att->id.'" ' : '');
				if( preg_match('#\bslidewrap2\b#is', $divclass) ) {
					$addslide = '<h6 class="slidetab2">'.$att->label.'</h6>';
					$slide2class = ' class="slidecontent2"';
				}else
				if( preg_match('#\bflex-wrap\b#is', $divclass) ) {
					$flexwrap = ' class="flex wrap"';
				}
				$html .= $toggle.'<div'.$div_id.$divclass.$togglestate.'>'.$addslide.'<div'.$slide2class.$flexwrap.'>';
			}else
			if( $att->type == 'divclose' ) {
				$html .= '</div></div>';
			}else
				// horizontal line
			if( $att->type == 'hr' ) {
				$html .= '<hr />';
			}else

			// Select Options
			if( $att->type == 'list' )
			{
				$html .= $open.'
				<select name="'.$att->name.'"'.$multiple.$size.'>';

				foreach($field->option as $option) {
					$opt = $option->attributes();
					$selected = ($opt->value == $params->$namestring ? ' selected' : '');

					$html .= '<option value="'.$opt->value.'"'.$selected.'>'.(string)$option.'</option>';
				}

				if( isset($att->src) )
				{
					if( $att->src == 'menugroup' ) {
						$menugroups = menugroups()->get();
						foreach($menugroups as $menugroup) {
							$selected = ($menugroup->id == $params->$namestring ? ' selected' : '');
							$html .= '<option value="'.$menugroup->id.'"'.$selected.'>'.$menugroup->groupname.'</option>';
						}
					}else

					// file list
					if( $att->src == 'file' )
					{
						$filesrc = getFiles(ROOTDIR.'/'.$att->path, $att->ext);
						if( $att->ext == 'css' && in_array('sixflix', explode('/', $att->path)) ) {
							$filesrc = array_merge($filesrc, getFiles(SITETPLS_DIR.'/sixflix/css/themes/', 'css'));
						}
						foreach($filesrc as $file) {
							$selected = ($file == $params->$namestring ? ' selected' : '');
							$html .= '<option value="'.$file.'"'.$selected.'>'.$file.'</option>';
						}
					}
				}


				$html .= '</select>
				'.$emptyelement . $close;
			}else

			// Single Checkbox
			if( $att->type == 'checkbox' ) {
				$html .= $open.'
				<div class="inlineblock check-btn">
					<label>
						<span style="padding: 6px;">
						<input style="height: 0 !important; margin: 0; vertical-align: middle;" type="checkbox" name="'.$att->name.'" value="1" '.($params->$namestring == 1 ? 'checked' : '').' />
						</span>
						<span style="padding: 4px 8px">'.($params->$namestring == 1 ? 'Yes' : 'No').'</span>
					</label>
				</div>
				'.$close;
			}else

			// Select - categories list as multi select field
			if( $att->type == 'categories' )
			{
				//if( !$att->cattype || !$att->src ) {
				//	echo 'The categories select field has been set but a required parameter for <strong>cattype</strong> is missing';
				//	return ;
				//}

				if( isset($att->cattype) ) {
					$cats = categories()->where([['state', 1], ['type', $att->cattype]])->pluck('title', 'id');
				}else

				if( isset($att->src) && $att->src == 'products' ) {
					$cats = getDbo('tblproductgroups')->where('hidden', 0)->pluck('name', 'id');
					$products = true;
				}

				$html .= $open.'<div><select name="'.$att->name.'[]" size="1" multiple>';
				foreach($cats as $key => $val)
				{
					$selected =[];
					foreach(array_values((array)$params->$namestring) as $select) {
						$selected[] = ($key == $select ? ' selected' : '');
					}

					$html .= '<option value="'.$key.'"'.implode('', $selected).'>'.$val.'</option>';
				}
				$html .= '</select></div>'.$close;
			}else

			// Textarea
			if( $att->type == 'textarea' )
			{
				$editor= $codeeditorJs= $codeeditorctrl='';
				if( !empty($att->editor) ) 
				{
					// set code mirror
					if( $att->editor == 'codeeditor' ) 
					{
						$codeeditorJs = cmseCodeEditor('codeeditor-'.$att->name, '-'.$att->name);
						
						$editor = ' id="codeeditor-'.$att->name.'"';
					}else{
					$editor = ' id="wysiwyg"';
					}
				}

				$textval = $att->value;
				if( !empty($params->$namestring) )
					$textval = html_entity_decode($params->$namestring);

				if( $att->restricted == true && !$adminallowed ) {$html .= 'Restricted';} else {
					$html .= $open.'<textarea class="autosize" name="'.$att->name.'"'.$editor.$placeholder.'>'.$textval.'</textarea>'.$close.$codeeditorJs;
				}

			}else
			
				
			// image manager
			if( $att->type == 'image' )
			{
				$html .= $open.'
				<div class="table">
					<div class="table-cell flexwrap">
						<input type="text" id="getimgname'.$att->name.'" name="'.$att->name.'" value="'.$value.'" class="alignmiddle width-220" />
						<button
						data-toggle="modal"
						data-target="#imgmanager-'.$att->name.'"
						class="btn btn-info btn-sm alignmiddle"
						type="button">Select</button>
						<a class="btn btn-sm btn-warning clearfield">
						<i class="fas fa-times alignmiddle" title="clear field"></i>
						</a>
					</div>
					'.(!empty($value) ? '<div class="table-cell width-80"><img src="'.IMAGES.$value.'" /></div>' : '').'
				</div>

				<div id="imgmanager-'.$att->name.'" class="modal" role="dialog">
					<div class="modal-dialog modal-lg">
						<div class="modal-content">
							<div class="modal-body">
								<iframe src="'.LIB_URL.'/vendor/filemanager/dialog.php?type=1&field_id=getimgname'.$att->name.'&relative_url=1&multiple=false&descending=false&lang=undefined&akey=whmcsfilemanager" height="600" width="100%"></iframe>
							</div>
						</div>
					</div>
				</div>'.$close;
			}else
			if( $att->type == 'info' )
			{
				$html .= $info;
			}else
			if( $att->type == 'illustration' && isset($att->src) ) {
				$html .= $open.'<img class="illustration" src="'.LIB_URL.'/widgets/'.$att->src.'" />'.$close;
			}else
			// layout shortcode
			if( $att->type == 'layout' )
			{
				$matches = layoutPreset();
				$selectname = 'wpreset-'.$att->name;
				$selectstring = (string)$selectname;

				$scselect = '
				<script>
				jQuery(function($) {
					$("#wpreset-'.$att->name.'").change(function() {
						$("#txt-'.$att->name.'").val( $("#"+$(this).val()).text() );
					});
				});
				</script>

				<select id="'.$selectname.'" name="'.$selectname.'">';
					foreach($matches as $match) {
						//include strings beginning with any
						if( !preg_match(chr(1).$att->filter.chr(1), $match[1]) )
							continue;

						$selected = ($match[1] == $params->$selectstring ? ' selected' : '');
					$scselect .= '<option value="'.$match[1].'"'.$selected.'>'.$match[1].'</option>';
					}
				$scselect .= '
				</select>
				';

				$shortcode = $att->value;
				if( !empty($params->$namestring) )
					$shortcode = html_entity_decode($params->$namestring);

				$html .= $open.$scselect.'<textarea id="txt-'.$att->name.'" class="autosize" name="'.$att->name.'">'.$shortcode.'</textarea>'.$close;
			}else
				
			// boostrap yes no button
			if( $att->type == 'yesno' ) 
			{
				$default = (isset($att->value) ? $att->value : 0);
				$state1 = ($default == 1 ? 'active' : 'notActive');
				$state0 = ($default == 0 ? 'active' : 'notActive');
				if( isset($params->$namestring) ) {
					$default = $params->$namestring;
					$state1 = ($params->$namestring == 1 ? 'active' : 'notActive');
					$state0 = ($params->$namestring == 0 ? 'active' : 'notActive');
				}
				
				
				$html .= $open.'
						<div id="radioBtn" class="btn-group" style="min-width: 83px;">
							<a class="btn btn-info btn-sm btn-yes '.$state1.'" data-optfield="'.$att->name.'" data-val="1">YES</a>
							<a class="btn btn-default btn-sm btn-no '.$state0.'" data-optfield="'.$att->name.'" data-val="0">NO</a>
						
							<input type="hidden" name="'.$att->name.'" id="'.$att->name.'" value="'.$default.'" />
						</div>
				'.$close;
				
			// text field
			}else
			if( $att->type =='button' ) {
				$btnclass = (!empty($att->btnclass) ? $att->btnclass : 'btn-sm btn-primary');
				$html .= $open.'<button type="submit" class="btn '.$btnclass.' alignbottom" name="'.$att->name.'">'.$att->label.'</button>'.$close;
			}else
			
			{
				// text field which serves multiple purposes including number, color, text
				$html .= $open.'<input type='.$fieldtype.' name="'.$att->name.'" value="'.$value.'" '.$size.($att->type == 'number' ? $min.$max : '').$placeholder.' />'.$close;
			}

			// output field names
			if( $fieldnames ) {
				$fldname[] = array_merge((array)$att->name, (array)$selectname);
			}

		}

		// fieldset wrapper
		$attr = $fieldset->attributes();
		$icon='';
		if( isset($attr->icon) )
			$icon = '<i class="'.$attr->icon.'" style="margin-right: 12px;"></i>';

		// set class for fieldset wrapper
		$setclass= $slidetab= $slidecontainer= $slideclose= $readme='';

		if( isset($attr->info) ) {
			$readme = '<small class="info">'.(defined($attr->info) ? constant($attr->info) : $attr->info).'</small>';
		}

		if( isset($attr->class) )
		{
			$setclass = ' class="'.$attr->class.'"';
			if( preg_match('#groupslide\b#is', $attr->class) ) {
				$slidetab = ' class="slidetab"';
				$slidecontainer = '<div class="slidecontent">';
				$slideclose = '</div>';
			}
		}

		// set toggler
		$togglefs= $togglestatefs='';
		if( isset($attr->showon) )
		{
			$elements = explode(':', $attr->showon);
			$selector = $elements[0];
			$optval = $elements[1];
			$togglestatefs = ' style="display: none;"';
			$togglefs = '
			<script>
			jQuery(function($) {
			$("select[name='.$selector.']").slideopen("#'.$attr->id.'", "'.$optval.'");
			});
			</script>
			';
		}

		$setlabel = 'Fieldset';
		if( isset($attr->label) )
			$setlabel = $attr->label;
		$setid='';
		if( isset($attr->id) )
			$setid = ' id="'.$attr->id.'" ';

		// output the fields
		if( $fieldnames == false )
		{
			echo $togglefs.'<fieldset'.$setid.$setclass.$togglestatefs.'>';
			echo '<h5'.$slidetab.'><span class="title">'.$icon.$setlabel.'</span></h5>';
			echo $slidecontainer;
			echo $readme;
			echo $html;
			echo $slideclose;
			echo '</fieldset>';
		}

	}


	// get fieldnames for use in form post
	if( $fieldnames ) {
		$fldname = array_merge(...$fldname);
		$getnames=[];
		foreach($fldname as $val) {
			$getnames[$val] = getPost($val, false);
		}
		return $getnames;
	}

}


function userInfo($var) {
	if( tplVars('loggedin') )
		return getClientsDetails(Session::get('uid'))[$var];
}


// WHMCS core pages
function whmcspages() {
	$whmcspages = [
		'index.php',
		'contact.php',
		'clientarea.php',
		'submitticket.php',
		'domainchecker.php',
		'register.php',
		'pwreset.php',
		'supporttickets.php',
		'affiliates.php',
		'logout.php',
		'cart.php',
		'serverstatus.php'
		];

	return $whmcspages;
}



function insertWidget($id, $showtitle=1)
{
	$widgetval = widgets()->where([['id', $id], ['state', 1]])->select('type', 'params', 'attribs', 'access')->get()[0];
	$params = json_decode($widgetval->params);
	$attrib = json_decode($widgetval->attribs);

	ob_start();
	include LIB_PATH.'/widgets/'.$widgetval->type.'/'.$widgetval->type.'.php';
	$widgetfile = ob_get_clean();

	$widget = '
	<div id="widget-'.$id.'" class="w1'.(isset($attrib->widgetclass) ? ' '.$attrib->widgetclass : '').'">
		'.(!isset($attrib->show_widget_title) && $showtitle ? '<h2 class="w2"><span>'.$attrib->title.'</span></h2>' : '').'
		<div class="w3">
			<div class="inner">
			'.$widgetfile.'
			<div class="clearall"></div>
			</div>
		</div>
	</div>
	';

	if( canAccess($widgetval->access) )
		return $widget;
}


/* Widget Output
-------------------------------------*/
function getWidgets($position)
{
	list($component, $view, $category, $post, $menuid, $listpage, $prodid, $groupid, $parent) = getNonSEF();

	$widgets = widgets()->where([['state', 1],['position', $position]])->orderBy('sortorder')->get();
	foreach($widgets as $widget)
	{
		$attr = json_decode($widget->attribs);
		$params = json_decode($widget->params);

		// assign a variable for smarty tpl use
		getSmarty()->assign('params', $params);


		$menu = menus()->select('id', 'url', 'type')->where('id', $menuid)->get()[0];
		//$groupid = cmseproducts()->where([['type', 'group'], ['group_alias', getCurrentFilename()]])->value('group_id');
		//$prodgroup = groups()->where('id',

		$homepg = menus()->select('id', 'homepage')->where('homepage', 1)->get()[0];
		if( tplVars('templatefile') == 'homepage' || getCurrentfilename() == '' ) {
			$menu = menus()->select('id', 'url', 'title', 'attribs', 'type')->where('id', $homepg->id)->get()[0];
			$menuid = $menu->id;
		}
		
		
		// get menu id for whmcs core pages
		if( $menuid == 0 ) {
			$menuid = menus()->where('url', getCurrentFilename())->value('id');
		}
		

		$assign = array_values((array)json_decode($widget->menuassign)->assigned);
		$excludes = array_values((array)json_decode($widget->menuassign)->exclude);
		$catview = json_decode($widget->menuassign)->catview;
		$groupassign = array_values((array)json_decode($widget->menuassign)->group);

		$canAccess = canAccess($widget->access);

		if(
		(in_array($menuid, $assign) && !isset($catview))
		|| (in_array($menuid, $assign) && isset($catview) && empty($catview))
		|| (in_array($menuid, $assign) && isset($catview) && (int)$catview === 2 && !isset($post))
		|| (in_array($menuid, $assign) && isset($catview) && (int)$catview === 1 && isset($post))
		|| (in_array('All', $assign) && !in_array($menuid, $excludes))
		|| (in_array($menu->id, $assign) && in_array(getCurrentFilename(), whmcspages()))
		//|| (in_array($menu->id, $assign))
		|| (in_array($menu->id, $assign) && tplVars('templatefile') == 'homepage' )
		|| (in_array((int)$groupid, $groupassign) && !empty($component) && $component == 'products')
		)
		{
			if( $canAccess ) {
			echo '<div id="widget-'.$widget->id.'" class="w1'.(isset($attr->widgetclass) ? ' '.$attr->widgetclass : '').'">';
			echo (!isset($attr->show_widget_title) ? '<h2 class="w2"><div><span>'.$attr->title.'</span></div></h2>' : '');
			echo '<div class="w3"><div class="inner">';
			include LIB_PATH.'/widgets/'.$widget->type.'/'.$widget->type.'.php';
			echo '<div class="clearall"></div></div></div>';
			echo '</div>';
			}
		}
	}
}




/* User Access
---------------------------*/
function userAccess($value)
{
	$access = json_decode($value);
	$canAccess = (
		($access->access == 2 && tplVars('loggedin')) ||
		($access->access == 1 && tplVars('loggedin') != 1) ||
		($access->access == 6 && tplVars('loggedin') && in_array(userInfo('groupid'), (array)$access->cg)) ||
		($access->access == 0) ||
		(fullAdmin(Session::get('adminid')))
	);

	return $canAccess;
}


function canAccess($src, $resource='', $msg=true)
{
	$access = json_decode($src);
	$message = ($msg == true ? '<div class="alert alert-warning">'.html_entity_decode($access->no_access_msg).'</div>' : '');

	if( !empty($resource) ) {
	$canAccess = (
		($access->access == 2 && tplVars('loggedin')) ||
		($access->access == 1 && tplVars('loggedin') != 1) ||
		($access->access == 6 && tplVars('loggedin') && in_array(userInfo('groupid'), (array)$access->cg)) ||
		($access->access == 0) ||
		(fullAdmin(Session::get('adminid')))
		? $resource : $message
	);
	}else{
		$canAccess = (
		($access->access == 2 && tplVars('loggedin')) ||
		($access->access == 1 && tplVars('loggedin') != 1) ||
		($access->access == 6 && tplVars('loggedin') && in_array(userInfo('groupid'), (array)$access->cg)) ||
		($access->access == 0) ||
		(fullAdmin(Session::get('adminid')))
		);
	}

	return $canAccess;
}



function widgetTpl($tpl, $file = 'default') {
	return getSmarty()->display(LIB_PATH.'/widgets/'.$tpl.'/tmpl/'.$file.'.tpl');
}



/* Menu Process
---------------------------------*/
function cmseMenu($menuitems)
{
	// get non SEF url request values
	list($component, $view, $category, $post, $menuid, $listpage, $prodid, $groupid, $parent) = getNonSEF();

	$factory = new MenuFactory();
	$menu	= $factory->createItem('root');
	
	// define parent and sub menu items
	$menuparents = menus()->where([['published', 1], ['menuparent', '>', 0]])->pluck('menuparent');
	$childmenus = menus()->whereIn('menuparent', $menuparents)->get();
	
	// define menu active state
	if( !empty($menuid) ) {
		$active = $menuid;
	}else
	if( tplVars('templatefile') == 'homepage' ) {
		$active = menus()->where('homepage', 1)->value('id');
	}
	
	foreach($menuitems as $menuitem) 
	{
		$url = ROOT_URL.router(html_entity_decode($menuitem->url)); 
		$attribs = json_decode($menuitem->attribs);
		
		// menu attributes
		$id = 'menu-'.$menuitem->id;
		$activeclass = ($menuitem->id == $active ? ' active ' : '');
		$customclass = (!empty($attribs->menuclass) ? ' '.$attribs->menuclass : '');
		
		// set items without sub menu
		if( $menuitem->menuparent == 0 && !in_array($menuitem->menuparent, $menuparents) )
		{
			$menu->addChild($menuitem->id)
				->setUri($url)
				->setLabel($menuitem->title)
				->setAttributes([
					'id' => $id,
					'class' => $activeclass . $customclass,
					'target' => $attribs->target,
					'icon' => $attribs->menuicon
					])
				;
		}
		
		// set parent with sub menu
		if( in_array($menuitem->id, $menuparents) ) 
		{
			$nav = $menu->addChild($menuitem->id)
			->setUri($url)
			->setLabel($menuitem->title)
			->setAttributes([
				'id' => $id,
				'class' => 'haschild' . $activeclass . $customclass,
				'icon' => $attribs->menuicon
				])
			->setChildrenAttribute('class', 'childmenu');

			foreach($childmenus as $childmenu) 
			{
				$childId = $childmenu->id;
				$childTitle = $childmenu->title;
				$childUrl = ROOT_URL.router(html_entity_decode($childmenu->url));
				
				if( $childmenu->menuparent == $menuitem->id ) {
					$nav->addChild($childId)
					->setUri($childUrl)
					->setLabel($childTitle);
				}
			}
		}

	}
	
	return $menu;
}





// Get Template Configuration
function tplConfig($name)
{
	// get name of parent folder of template where the file using this function is located
	//$key = array_search(__FUNCTION__, array_column(debug_backtrace(), 'function'));
	//$name = getinnerstring(debug_backtrace()[$key]['file'], 'templates/', '/_templateConfigs.php');

	// get data from database
	$configs = templates()->where('name', $name)->get()[0];
	$configs = json_decode($configs->configs);

	return $configs;
}


// get social share buttons
function socialShare() {
	ob_start();
	include LIB_PATH.'/cmse/socialshare/socialshare.php';
	return ob_get_clean();
}





/** File Handling
--------------------------------*/

// create file
function cmseMakeFile($dest) {
	if( !file_exists($dest) ) {
		$filenew = fopen($dest, 'w');
		fclose($filenew);
	}else{
		echo '<p class="alert alert-warning">The file name already exists at the destination</p>';
	}
}

// Image Manager
function imageManager($fieldname, $dbvalue, $fieldid='getimgname', $datatarget='imgmanager', $frameheight='600')
{
	$imgmanager = '
	<div class="input-group-append pad-v-10">
	<input type="text" id="'.$fieldid.'" name="'.$fieldname.'" value="'.$dbvalue.'" />
	<button
	data-toggle="modal"
	data-target="#'.$datatarget.'"
	class="btn btn-info btn-sm"
	type="button">Select Image</button>
	<a class="btn btn-sm btn-warning clearfield"><i class="fas fa-times table-cell" title="clear field"></i></a>
	</div>
	<div id="'.$datatarget.'" class="modal" role="dialog">
		<div class="modal-dialog modal-lg">
			<div class="modal-content">
				<div class="modal-body">
					<iframe src="'.LIB_URL.'/vendor/filemanager/dialog.php?type=1&field_id='.$fieldid.'&relative_url=1&multiple=false&descending=false&lang=undefined&akey=whmcsfilemanager" height="'.$frameheight.'" width="100%"></iframe>
				</div>
			</div>
		</div>
	</div>';

	return $imgmanager;
}


function cmseCodeEditor($elementId, $themeId='') 
{
	$ctrl = '
		<fieldset>
			<label>Editor Theme</label>
			<select onchange="selectTheme()" id="codemirror-theme'.$themeId.'">
				<option selected>Light</option>
				<option>3024-night</option>
			</select>
			<span>F11 Toggle Fullscreen Editor | Ctrl+F to search</span>
		</fieldset>';
						
	$init = '
	<script>
	var editor = CodeMirror.fromTextArea(document.getElementById("'.$elementId.'"), {
	lineNumbers: true,
    styleActiveLine: true,
	matchBrackets: true,
	theme: "3024-night",
	extraKeys: {
        "F11": function(cm) {
          cm.setOption("fullScreen", !cm.getOption("fullScreen"));
        },
        "Esc": function(cm) {
          if (cm.getOption("fullScreen")) cm.setOption("fullScreen", false);
        }
      }
  });
  
  var input = document.getElementById("codemirror-theme'.$themeId.'");
  function selectTheme() {
    var theme = input.options[input.selectedIndex].textContent;
    editor.setOption("theme", theme);
    location.hash = "#" + theme;
  }
  var choice = (location.hash && location.hash.slice(1)) ||
               (document.location.search &&
                decodeURIComponent(document.location.search.slice(1)));
  if (choice) {
    input.value = choice;
    editor.setOption("theme", choice);
  }
  CodeMirror.on(window, "hashchange", function() {
    var theme = location.hash.slice(1);
    if (theme) { input.value = theme; selectTheme(); }
  });
  
	function clearSlate() {
		editor.setValue("");
	}
	</script>';
	
	return $ctrl . $init;
}


// get the full path of the file using this function
function getFileUsingThis() {
	$key = array_search(__FUNCTION__, array_column(debug_backtrace(), 'function'));
	return debug_backtrace()[$key]['file'];
}


// set unit of measure for max file upload size
function fileunit() {
	$base	= log(modConfigs()->maxupload, 1024);
	$units	= ['B', 'KB', 'MB'];
	$unit	= round(pow(1024, $base - floor($base)), 2).$units[floor($base)];

	return $unit;
}



// File upload processor
function getFileUpload($fieldname, $dest, $filemax, $success='')
{
	$maxupl = ((int)$filemax * 1024);

	$files = $_FILES[$fieldname];
	if( isset($files['type']) && !empty($files['type']) )
	{
		$filename	= $files['name'];
		$imgtype	= $files['type'];
		$filesize	= $files['size'];

		$validext	= ['jpeg', 'jpg', 'png', 'gif', 'webp', 'zip', 'ZIP'];
		$mimetypes	= ['image/png', 'image/jpg', 'image/jpeg', 'image/gif', 'image/webp', 'application/zip', 'application/x-zip', 'application/x-zip-compressed'];
		$temporary	= explode('.', $filename);
		$file_extension = end($temporary);

		$temp_path = $files['tmp_name'];
		$storefile = $dest.'/'.$filename;


		if(
		in_array($imgtype, $mimetypes)
		&&
		$filesize < $maxupl
		&&
		in_array($file_extension, $validext)
		)
		{
			if( $files['error'] > 0 ) {
				echo 'Error Code: '.$files['error'].'<br/><br/>';
			}else{
				if( file_exists($storefile) ) {
					echo '<p class="alert alert-warning"> '.$filename.' already exists</p>';
				}else{
					move_uploaded_file($temp_path, $storefile);
					if( $success != '' )
						echo '<p class="alert alert-success">'.$success.'</p>';
				}
			}
		}else{
			echo '<span class="alert alert-warning">Invalid file Size or Type<span>';
		}
	}
}

// Zip File Extractor
function zipex($file, $success='Extracted successfully')
{
	$path = pathinfo(realpath($file), PATHINFO_DIRNAME);

	$zip = new ZipArchive;
	$res = $zip->open($file);
	if ($res === true) {
		$zip->extractTo($path);
		$zip->close();
		echo '<p class="alert alert-success">'.$success.'</p>';
		unlink($file);
	} else {
		echo '<p class="alert alert-warning">could not open '.$file.'</p>';
	}
}




// get all folders in a given directory and return array
function getFolders($path)
{
	$tmpldir = new \DirectoryIterator($path);
	$tmpls =[];
	foreach($tmpldir as $tmpl)
	{
		if( !$tmpl->isDot() ) {
			if( $tmpl->isDir() )
				$tmpls[] = $tmpl->getFilename();
		}
	}

	return $tmpls;
}


function getFilez($path)
{
	try{
	$filesrc = new \DirectoryIterator($path);
	$files =[];
	foreach($filesrc as $file)
	{
		if( !$file->isDot() ) {
			if( $file->isFile() ) {
				$files[] = $file->getFilename();
			}
		}
	}

	return $files;
	} catch(\Exception $e) {
		cmseNotice($e->getMessage());
	}
}




// Recursive Folder Copy
function copyAll($src, $dst)
{
	$dir = opendir($src);
	@mkdir($dst);

	while(false !== ( $file = readdir($dir)) ) {
		if (( $file != '.' ) && ( $file != '..' )) {
			if ( is_dir($src.'/'.$file) ) {
				copyAll($src.'/'.$file, $dst.'/'.$file);
			}
			else {
				copy($src.'/'.$file, $dst.'/'.$file);
			}
		}
	}
	closedir($dir);
}


// Recursive Folder Delete
function deleteFolder($dir)
{
	if (is_file($dir)) {
		return unlink($dir);
	}
	elseif (is_dir($dir)) {
		$scan = glob(rtrim($dir,'/').'/*');
		foreach($scan as $index => $path) {
			deleteFolder($path);
		}

		rmdir($dir);
	}
}


// delete a folder and all content.
// also serve as single file delete
function deleteFolders($dir)
{
	if( is_dir($dir) )
	{
		$objects = scandir($dir);
		foreach($objects as $object) {
			if( $object != "." && $object != ".." ) {
				if( is_dir($dir."/".$object) )
					deleteFolders($dir."/".$object);
				else
					unlink($dir."/".$object);
			}
		}
		rmdir($dir);
	}else
	if( is_file($dir) ) {
		unlink($dir);
	}
}


// get files using extension inclusion filter
// getFiles($path, 'css')
function getFiles($path, $extensions = '') {
	$ext = ($extensions != '' ? '*.{'.$extensions.'}' : '*');

	return str_replace($path, '', glob($path. $ext, GLOB_BRACE));
}


function getCurrentFilename() {
	return end(explode('/', $_SERVER['SCRIPT_URL']));
}



// clean title alias
function cleanChars($value, $underscore=false, $cleanall=false, $keephyphen=false) {
	$str = ['#[\?\*\\\+\[\^\]\$\(\)\{\}\=\!\<\>\|\:\-\#\"\&\/\.\']#', '#\s+#'];
	$rpl = ['', '-'];

	if( $underscore )
		$rpl = ['','_'];
	if( $keephyphen )
		$rpl = ['-','-'];
	if( $cleanall )
		$rpl = ['',''];
	$alias = preg_replace($str, $rpl, strtolower($value));

	return $alias;
}

// remove htmlencoding when alias is queried from DB
function cleanalias($value) {
	return str_replace(['&',';','amp','quot','lt','gt'], ['','','','','',''], $value);
}

function redirect($url, $method = 302) {

	if( !headers_sent() ) {
	return header('location: '.$url, true, $method);
	exit;
	}
}

function getUri($filter=true) {
	if( $filter == false ) {
		return $_SERVER['REQUEST_URI'];
	}else{
		return filter_input(INPUT_SERVER, 'REQUEST_URI', FILTER_SANITIZE_STRING);
	}
}


function getPost($input, $filter=true) {
	$out = filter_input(INPUT_POST, $input, FILTER_SANITIZE_STRING);
	if( $filter == false )
		$out = $_POST[$input];

	return $out;
}

function currenturl($filter=false) {
	$url = (isset($_SERVER['HTTPS']) ? 'https://' : 'http://').$_SERVER['SERVER_NAME'].$_SERVER['REQUEST_URI'];
	if( $filter == true ) {
		return filter_var($url, FILTER_SANITIZE_STRING, FILTER_FLAG_STRIP_HIGH);
	}else{
		return $url;
	}
}


// alternative root url
function cmserootUrl()
{
	$abspath = dirname(__DIR__,3);
	
	//replace windows OS backslash
	$abspath = str_replace('\\', '/', realpath($abspath));

	$rooturl = (!empty($_SERVER['HTTPS']) ? 'https://' : 'http://').$_SERVER['HTTP_HOST'].substr($abspath, strlen($_SERVER['DOCUMENT_ROOT']));

	return $rooturl;
}





function getRequest($element, $isset='') {

	if( $isset == 'ifset' ) {
		return isset($_REQUEST[$element]);
	}else{
		return $_REQUEST[$element];
	}
}

function findKey($key, $array) {
	return array_key_exists($key, $array);
}

function requestKey($key) {
	return findKey($key, $_REQUEST);
}

function makeAlias($val) {
	return cleanChars(getPost($val));
}

// truncaterizer
function truncText($text, $charcount, $keeptag='')
{
	// strip plugin content shortcodes eg {rsform 5}
	$text = preg_replace('#\[(.*?)\]#i', '', $text);

	$text = strip_tags($text, $keeptag);

	if( strlen($text) > $charcount && $charcount != 0 )
	{
		$text = $text." ";
		$text = substr($text,0,$charcount);
		$text = substr($text,0,strrpos($text,' '));
		if($charcount != 0) {
		$text = $text." ...";
		}
	}
	return $text;
}

/* Find in string position using array
method
$string = 'http://google.com';
$array = ['google', 'yahoo', 'aol'];
if( inString($string, $array) ) $dothis = 'the thing to do';
------------------------------------------*/
function inString($haystack, $needle, $offset=0)
{
    if( !is_array($needle) )
		$needle = array($needle);
    foreach($needle as $query) {
        if(strpos($haystack, $query, $offset) !== false)
			return true;
    }
    return false;
}

// find string within given characters
// getInnerstring('http://site.com?id=red&pwd=gold&usr=jon', '?id=', '&') result red
function getInnerstring($string, $start, $end)
{
	$string = " ".$string;
	$ini = strpos($string,$start);
	if ($ini == 0) return "";
	$ini += strlen($start);
	$len = strpos($string,$end,$ini) - $ini;
	return substr($string,$ini,$len);
}

function getYoutubeID($url)
{
	$url = parse_url($url);

	if( ($url['host'] == 'youtu.be' && !isset($url['query'])) || ($url['host'] == 'www.youtu.be' && !isset($url['query'])) ) {
		$result = substr($url['path'], 1);
	}else
	if( ($url['host'] == 'youtu.be' && isset($url['query'])) || ($url['host'] == 'www.youtu.be' && isset($url['query'])) ) {
		$result = substr($url['path'], 1).'?'.$url['query'];
	}else{
		$result = substr($url['query'], 2);
	}
	return $result;
}

function getYoutubeTitle($yid)
{
	$content = @file_get_contents('https://youtube.com/get_video_info?video_id='.$yid);
	parse_str($content, $ytarr);
	if( isset($ytarr['title']) ) {
	return  $ytarr['title'];
	}
}


function getVevoID($vevoUrl) {
	$vevoId = explode('/',$vevoUrl);
	$vevoId = end($vevoId);
	return $vevoId;
}


// Get video thumb image for Vimeo video
function getVimeoThumb($id) {
	$vimeodata = @file_get_contents("http://vimeo.com/api/v2/video/$id.json");
	$vimeodata = json_decode($vimeodata);
	return $vimeodata[0]->thumbnail_medium;
}

function apiData($url)
{
	$data='';

	if( strstr($url, 'youtu') )
	{
		if( strstr($url, 'youtu.be') ) {
			$ytId = basename($url);
		}else{
			$ytId = str_replace('watch?v=','',basename($url));
		}
		if( remoteFileExists('https://i.ytimg.com/vi/'.$ytId.'/maxresdefault.jpg') ) {
			$data = 'https://i.ytimg.com/vi/'.$ytId.'/maxresdefault.jpg';
		}else{
			$data = 'https://i.ytimg.com/vi/'.$ytId.'/0.jpg';
		}

	}

	if( strstr($url, 'vimeo') ) {
		$data = json_decode(get_remote_data('http://vimeo.com/api/v2/video/'.basename($url).'.json'));
	}

	if( strstr($url, 'facebook') ) {
		$data = json_decode(get_remote_data('https://graph.facebook.com/'.basename($url).'?access_token=544441599233044|hiUGSUC7H0uhamDjGSABZ_IPlyQ&fields=format,description,title,source'));
	}

	if( strstr($url, 'dailymotion') ) {
		$data = @simplexml_load_file('https://www.dailymotion.com/services/oembed?url='.urlencode($url).'&format=xml');
	}

	if( strstr($url, 'vevo') ) {
		$data = basename($url);
	}

	if( stristr($url, 'issuu') ) {
		$data = json_decode(get_remote_data('https://issuu.com/oembed?url='.urlencode($url).'&format=json'));
	}

	return $data;
}


function curlremote($url)
	{
		$c = curl_init();
		curl_setopt($c, CURLOPT_RETURNTRANSFER, 1);
		curl_setopt($c, CURLOPT_URL, $url);
		$contents = curl_exec($c);
		curl_close($c);

		if ($contents) return $contents;
			else return FALSE;
	}


// CURL
function get_remote_data($url, $post_paramtrs=false)
{
    $c = curl_init();
    curl_setopt($c, CURLOPT_URL, $url);
    curl_setopt($c, CURLOPT_RETURNTRANSFER, 1);
    if($post_paramtrs) {
        curl_setopt($c, CURLOPT_POST,TRUE);
        curl_setopt($c, CURLOPT_POSTFIELDS, "var1=bla&".$post_paramtrs );
    }
    curl_setopt($c, CURLOPT_SSL_VERIFYHOST,false);
    curl_setopt($c, CURLOPT_SSL_VERIFYPEER,false);
    curl_setopt($c, CURLOPT_USERAGENT, "Mozilla/5.0 (Windows NT 6.1; rv:33.0) Gecko/20100101 Firefox/33.0");
    curl_setopt($c, CURLOPT_COOKIE, 'poptype[1]1=Value;');
    curl_setopt($c, CURLOPT_MAXREDIRS, 10);
    $follow_allowed = ( ini_get('open_basedir') || ini_get('safe_mode')) ? false:true;
    if ($follow_allowed) {
        curl_setopt($c, CURLOPT_FOLLOWLOCATION, 1);
    }
    curl_setopt($c, CURLOPT_CONNECTTIMEOUT, 9);
    curl_setopt($c, CURLOPT_REFERER, $url);
    curl_setopt($c, CURLOPT_TIMEOUT, 60);
    curl_setopt($c, CURLOPT_AUTOREFERER, true);
    curl_setopt($c, CURLOPT_ENCODING, 'gzip,deflate');
    $data = curl_exec($c);
    $status = curl_getinfo($c);
    curl_close($c);
    preg_match('/(http(|s)):\/\/(.*?)\/(.*\/|)/si',  $status['url'],$link);
	$data = preg_replace('/(src|href|action)=(\'|\")((?!(http|https|javascript:|\/\/|\/)).*?)(\'|\")/si','$1=$2'.$link[0].'$3$4$5', $data);
	$data = preg_replace('/(src|href|action)=(\'|\")((?!(http|https|javascript:|\/\/)).*?)(\'|\")/si','$1=$2'.$link[1].'://'.$link[3].'$3$4$5', $data);
    if( $status['http_code']==200 ) {
        return $data;
    }
    elseif( $status['http_code']==301 || $status['http_code']==302 )
	{
        if (!$follow_allowed)
		{
            if( !empty($status['redirect_url']) ) {
                $redirURL=$status['redirect_url'];
            }else{
                preg_match('/href\=\"(.*?)\"/si',$data,$m);
                if( !empty($m[1]) ) {
                    $redirURL=$m[1];
                }
            }
            if( !empty($redirURL) ) {
                return  call_user_func( __FUNCTION__, $redirURL, $post_paramtrs);
            }
        }
    }
    return "ERRORCODE22 with $url!!<br/>Last status codes<b/>:".json_encode($status)."<br/><br/>Last data message<br/>:$data";
}

// check for a remote file
function remoteFileExists($url)
{
    $curl = curl_init($url);
    curl_setopt($curl, CURLOPT_NOBODY, true);
    $result = curl_exec($curl);
    $filestatus = false;

    if ($result !== false)
	{
        $statusCode = curl_getinfo($curl, CURLINFO_HTTP_CODE);

        if ($statusCode == 200) {
            $filestatus = true;
        }
    }

    curl_close($curl);

    return $filestatus;
}

// strip html near shortcode brackets which is auto created by wysiwyg editor
function stripHtmlNearShortcode($articletext)
{
	$strips = array(
		'<p>[' => '[',
		']</p>' => ']',
		']<br />' => ']',
		'<strong>[' => '[',
		']</strong>' => ']',
		'&lt;p&gt;[' => '[',
		']&lt;/p&gt;' => ']',
		']&lt;br /&gt;' => ']',
		'&lt;strong&gt;[' => '[',
		']&lt;/strong&gt;' => ']',
		'</li><br />' => '</li>',
		'<ul><br />' => '<ul>'
		);
	return strtr($articletext, $strips);
}

// remove shortcodes from meta description tag
function cleanmeta($introtext) {

	$res = trim(preg_replace('/\\s*[\\n\\r]\\s*/','', $introtext));
	$res = preg_replace(['/\[tabs\]/i','/\[tab\s+(.*?)\](.*?)\[\/tabs\]/i'], ['',''], $res);

	return $res;
}




// resize image with GD2 backup method incase joomla deprecates the above
function cmseCreateThumb($path, $width, $dest, $quality = 80)
{
	if( empty(getimagesize($path)) ) {
		return;
	}

	list($w, $h, $type) = getimagesize($path);

	$twidth = $width;
	$theight = $width * $h / $w;

	switch($type) {
		case 1: $source = imagecreatefromgif($path); break;
		case 2: $source = imagecreatefromjpeg($path); break;
		case 3: $source = imagecreatefrompng($path); break;
	}

	$imgname = substr(strrchr(rtrim($path, '/'), '/'), 1);

	$thumb_size = imagecreatetruecolor($twidth, $theight);
	imagecopyresampled($thumb_size, $source, 0, 0, 0, 0, $twidth, $theight, $w, $h);

	if( !JFolder::exists($dest) )
		JFolder::create($dest);

	$dest = JPATH_ROOT.'/'.JPATH::clean($dest).'/'.$width.'_'.$imgname;
	imagejpeg($thumb_size, $dest, $quality);
	imagedestroy($source);
	imagedestroy($thumb_size);
}

/* Strip new lines from textarea data
-----------------------------------------*/
function clean($textdata, $space=false) {
	$cleaned = trim(preg_replace('/\\s*[\\n\\r]\\s*/', '', $textdata));
	if( $space )
		$cleaned = trim(preg_replace('/\\s*[\\n\\r]\\s*/', ' ', $textdata));

	return $cleaned;
}


/* Countdown Clock
----------------------*/
function cmseCountDown($date, $id='', $styleclass='', $endmsg='Ready')
{
	$cd = 'cd'.$id;
	$inlineJs = '
	<script>
	var '.$cd.' = new countdown("'.$cd.'");
	'.$cd.'.Div = "counter'.$id.'";
	'.$cd.'.TargetDate	= "'.$date.' 0:01 AM";
	'.$cd.'.DisplayFormat = "<div class=\"clockblock\"><div class=\"digit days\"><div class=\"digit-inner\"><div>%%D%%</div><span>Days</span></div></div><div class=\"digit hours\"><div class=\"digit-inner\"><div>%%H%%</div><span>Hours</span></div></div><div class=\"digit minutes\"><div class=\"digit-inner\"><div>%%M%%</div><span>Minutes</span></div></div><div class=\"digit seconds\"><div class=\"digit-inner\"><div>%%S%%</div><span>Seconds</span></div></div></div>";
	'.$cd.'.FinishMessage = "<div class=\"endmsg\">'.$endmsg.'</div>";
	</script>
	';

	if( !empty($styleclass) )
		$styleclass = ' '.$styleclass;
	// clock block output
	$html = $inlineJs.'<div id="cmsecount'.$id.'" class="cmse-countdown'.$styleclass.'">
		<div class="count-inner">
			<div id="counter'.$id.'" class="counter-elements"></div>
		</div>
		<script language="javascript">
		<!--
			'.$cd.'.Setup();
		//-->
		</script>
	</div>';

	return $html;

}




/* Random Items
-------------------------*/
function cmserandom ($enabled, $randitems, $randcount)
{
	if( $enabled && !empty($randitems) )
	{
		// processor for object from mod_cmse_random
		if( is_object($randitems) )
		{
			$rand_items=[]; $img= $imgname= $imgtext= $link= $linkend='';
			foreach($randitems as $randitem)
			{
				if( !empty($randitem->photo) ) {
					['filename' => $imgalt] = pathinfo(JPATH_ROOT.'/'.$randitem->photo);
					$img = '<img src="'.$randitem->photo.'" alt="'.$imgalt.'" />';
				}
				if( !empty($randitem->photoname) )
					$imgname = '<div class="img-name">'.$randitem->photoname.'</div>';
				if( !empty($randitem->phototext) )
					$imgtext = '<div class="img-text">'.$randitem->phototext.'</div>';
				if( !empty($randitem->imglink) ) {
					$link = '<a href="'.$randitem->imglink.'">';
					$linkend = '</a>';
				}
				$rand_items[] = $link . $img . $linkend . $imgname . $imgtext;
			}
		}

		// process shortcode inserted randomized content
		if( is_array($randitems) )
		{
			$rand_items=[];
			foreach($randitems as $randitem) {
				$rand_items[] = $randitem;
			}
		}


		if( $randcount == 1 )
		{
			// do not want to waste time shuffling the entire array just for 1 random element
			$randout = '<div class="randitem">'.$rand_items[mt_rand(0, count($rand_items) - 1)].'</div>';
		}else{
			shuffle($rand_items);
			$items = array_splice($rand_items, 0, $randcount);

			$randout='';
			foreach($items as $item) {
				$randout.= '<div class="randitem">'.$item.'</div>';
			}

		}

		return '<div class="cmserandom">'.$randout.'</div>';
	}
}


/* Shortcode Replacement
---------------------------------------------*/
function cmseElements($data)
{
	$data = stripHtmlNearShortcode($data);

	/* get divs and spans with attributes
	---------------------------------------*/
	preg_match_all('#\[div\s+(.*?)\]|\[div\]|\[span\s+(.*?)\]|\[span\]|\[box\]#i', clean($data), $divs, PREG_SET_ORDER);

	foreach($divs as $div)
	{

		$element = str_replace(['[',']','&quot;','&#34;'], ['<','>','"','"'], $div[0]);

		$str = [
			$div[0],
			'[div]', '[/div]',
			'[span]', '[/span]',
			'[box]', '[/box]'
			];
		$replace = [
			$element,
			'<div>', '</div>',
			'<span>', '</span>',
			'<div class="boxed"><div class="inner equalheight">', '</div></div>'
			];
		$data = str_replace($str, $replace, $data);
	}
	
	
	/* Preformatted place holders
	--------------------------------------*/
	preg_match_all('#\[section\s+(.*?)\]#is', $data, $sections, PREG_SET_ORDER);
	
	foreach($sections as $section) {
		$data = str_replace($section[0], '<div class="cmse-section '.$section[1].'"><div class="cmse-inner">', $data);
	}
	
	preg_match_all('#\[col\s+(.*?)\]#is', $data, $cols, PREG_SET_ORDER);
	
	$i=0;
	foreach($cols as $col) {
		$i++;
		$data = str_replace($col[0], '<div class="cmse-col '.$col[1].' i'.$i.'"><div class="col-inner">', $data);
	}
	

	/* common elements no attributes
	----------------------------------*/
	$cstr = [
		'[clearall]',
		'[h2]', '[/h2]',
		'[h3]', '[/h3]',
		'[h4]', '[/h4]',
		'[b]', '[/b]',
		'[hr]', '[br]',
		'[tabs]', '[/tabs]',
		'[slides]', '[/slides]',
		'[/link]',
		'&quot;','&#34;',
		'[section]','[/section]',
		'[col]','[/col]',
		'[---]',
		'[masonry]','[/masonry]',
		'[rate="5"]'
		];
	$creplace = [
		'<div class="clearall"></div>',
		'<h2>', '</h2>',
		'<h3>', '</h3>',
		'<h4>', '</h4>',
		'<strong>', '</strong>',
		'<hr />', '<br />',
		'<div class="slidewrap tabs"><div class="tabnav" /></div>', '</div>',
		'<div class="slidewrap slides">', '</div>',
		'</a>',
		'"','"', 
		'<div class="cmse-section"><div class="cmse-inner">', '<div class="clearall"></div></div></div><!-- sect end -->',
		'<div class="cmse-col"><div class="col-inner">','<div class="clearall"></div></div></div><!-- col end -->',
		'<div class="clearall"></div>
		</div>
		</div>
		<div class="cmse-col">
		<div class="col-inner">',
		//
		'<div class="masonry-gallery">','</div>',
		'<span class="ratestar"><i class="fas fa-star"></i><i class="fas fa-star"></i><i class="fas fa-star"></i><i class="fas fa-star"></i><i class="fas fa-star"></i></span>'
		];
	$data = str_replace($cstr, $creplace, $data);


	


	/* Post Insert
	---------------------------*/
	if( preg_match_all('#\[post=\"(.*?)\"\]#is', $data, $postinsets, PREG_SET_ORDER) )
	{
		$post_inset='';
		foreach($postinsets as $postinset)
		{
			$inset = posts()
					->where([['id', $postinset[1]],['published', 1]])
					->select('id', 'title', 'alias', 'post_image', 'catid')
					->get()[0];
			$cat = categories()->where('id', $inset->catid)->select('alias', 'title')->get()[0];
			$menuid='';

			$rawurl = 'index.php?component=posts&view=post&category='.$inset->catid.'-'.$cat->alias.'&post='.$inset->id.'-'.$inset->alias.'&menuid='.$menuid;
			$itemlink = ROOT_URL.router($rawurl);

			$post_inset = '
			<dl class="post-inset postitem">
			'.(!empty($inset->post_image) ? '
			<dd>
				<a href="'.$itemlink.'" title="See Details">
					<img src="'.IMAGES.$inset->post_image.'" alt="'.$inset->title.'" />
				</a>
			</dd>'
			:'').'
			<dt>
				<h3><a href="'.$itemlink.'" title="See Details">'.$inset->title.'</a></h3>
			</dt>
			</dl>';

			$data = str_replace($postinset[0], $post_inset, $data);
		}
	}


	/* Product Insert
	---------------------------*/
	if( preg_match_all('#\[product=\"(.*?)\"\]#is', $data, $prodinsets, PREG_SET_ORDER) )
	{
		$prod_inset='';
		foreach($prodinsets as $prodinset)
		{
			$prodval = cmseproducts()
					->select('prod_id', 'prod_image', 'prod_gid', 'prod_alias', 'group_alias')
					->where('prod_id', $prodinset[1])
					->get()[0];
			$prod = products()
					->where([['id', $prodval->prod_id], ['hidden', 0], ['retired', 0]])
					->select('id', 'name', 'gid', 'description', 'paytype')
					->get()[0];

			$menuid='';
			$rawurl = 'index.php?component=products&view=productdetail&gid='.$prod->gid.'-'.$prodval->group_alias.'&pid='.$prod->id.'-'.cleanChars($prod->name).'&menuid='.$menuid;

			$itemlink = ROOT_URL.router($rawurl);

			$prod_inset = '
			<dl class="post-inset product">
			'.(!empty($prodval->prod_image) ? '
			<dd>
				<a href="'.$itemlink.'" title="See Details">
					<img src="'.IMAGES.$prodval->prod_image.'" alt="'.$prod->name.'" />
				</a>
			</dd>'
			:'').'

			<dt>
				<h3><a href="'.$itemlink.'" title="See Details">'.$prod->name.'</a></h3>
				<div>'.truncText(html_entity_decode($prod->description), 120).'<br />
				<a class="btn btn-info" href="'.$itemlink.'" title="See Details">
				<span>'.itemPrice($prod->id, $prod->paytype, '', '', true).'</span>
				View Details</a>
				</div>
			</dt>
			</dl>';

			$data = str_replace($prodinset[0], $prod_inset, $data);
		}
	}


	/* Widget Insert
	---------------------------------*/
	if( preg_match_all('#\[widget=\"(.*?)\"(.*?)\]#is', $data, $widgets, PREG_SET_ORDER) )
	{
		foreach($widgets as $widget) {
			$title=1;
			if( isset($widget[2]) && getInnerString($widget[2], 'title="','"') == 'off' )
				$title = 0;
			$data = str_replace($widget[0], '<div class="post-inset">'.insertWidget((int)$widget[1], $title).'</div>', $data);
		}
	}




	/* Popup Window
	---------------------*/
	if( preg_match('#\[popwin(.*?)\]#is', $data, $popwin) )
	{
		if( isset($popwin[1]) && !empty($popwin[1]) )
		{
			preg_match('#exp=\"(.*?)\"#is', $popwin[1], $exp);
			preg_match('#once=\"(.*?)\"#is', $popwin[1], $once);
			preg_match('#delay=\"(.*?)\"#is', $popwin[1], $delay);
			preg_match('#class=\"(.*?)\"#is', $popwin[1], $class);
			preg_match('#poptype=\"(.*?)\"#is', $popwin[1], $poptype);
		}

		$exptime = ( isset($exp[1]) && !empty($exp[1]) ? $exp[1] : 0 );
		$showonce = ( isset($once[1]) && !empty($once[1]) ? $once[1] : 'false' );
		$delaytime = ( isset($delay[1]) && !empty($delay[1]) ? $delay[1] : 3 );
		$wrapclass = ( isset($class[1]) && !empty($class[1]) ? ' class="'.$class[1].'"' : '' );

		// page load
		if( isset($poptype[1]) && !empty($poptype[1]) && $poptype[1] == 'onload' )
		{
			$inlineJs = '<script>
			jQuery(function($)
			{
				cookieValue = getCookie("'.$poptype[1].'");
				if( cookieValue == "" )
				{
					$(".noticewindow.nw-'.$poptype[1].'").fadeIn("fast");

					setTimeout(function(){
						$(".noticewindow.nw-'.$poptype[1].'").fadeOut("fast", function () {
							$(this).remove();
						});

					}, '.$delaytime.'0000);
				}

				$(".noticewindow.nw-'.$poptype[1].' a.closewindow, .noticewindow.nw-'.$poptype[1].' .click-to-close").on("click", function()
				{
					$(".noticewindow.nw-'.$poptype[1].'").fadeOut("fast", function () {
						$(this).remove();
						$("body img, .footwrap").removeClass("blurr");
					});

					var now = new Date();
					now.setDate(now.getDate() + ('.$exptime.' * 365));
					setCookie("'.$poptype[1].'", 0, now, "/");
				});
			});
			</script>';

			$bg = '
			<style>
				.noticewindow.nw-'.$poptype[1].' {
					background-color: rgba(0,0,0, 0.7);
				}
			</style>
			';

			$pop_win = $bg.$inlineJs.'<div class="noticewindow notice nw-'.$poptype[1].'">
				<div class="msgbox">
					<div style="position: relative;">
						<a class="closewindow">X</a>
						<div class="msg">';

						$popend = '</div>
					</div>
				</div>
			</div>';
		}else{
		// mouse exit
			$inlineJs = '<script>
				bioEp.init({
				delay: '.$delaytime.',
				cookieExp: '.$exptime.',
				showOncePerSession: '.$showonce.',
				});
			</script>';

			$pop_win = '
			<div id="exitpop"'.$wrapclass.'>
				<div class="wrapper">
					<div id="exitpop_close"></div>
					<div class="pop-content">
					';
					$popend ='
					</div>
				</div>
			</div>
			'.$inlineJs;
		}

		$data = str_replace([$popwin[0], '[/popwin]'], [$pop_win, $popend], $data);
	}


	// Google map
	if( preg_match_all('#\[googlemap=\"(.*?)\"\]#is', $data, $gmaps, PREG_SET_ORDER) )
	{
		$googlemap='';
		foreach($gmaps as $gmap) {
			$googlemap = '<address class="gmaps">'.$gmap[1].'</address>';
			$data = str_replace($gmap[0], $googlemap, $data);
		}
	}



	// Countdown clock
	if( preg_match_all('#\[countdown(.*?)\]#is', $data, $countdowns, PREG_SET_ORDER) )
	{
		foreach($countdowns as $countdown)
		{
			if( preg_match('#date=\"(.*?)\"#is', $countdown[1], $date) )
			{
				preg_match('#class=\"(.*?)\"#is', $countdown[1], $class);
				preg_match('#msg=\"(.*?)\"#is', $countdown[1], $msg);

				$msge = (isset($msg[1]) && !empty($msg[1]) ? $msg[1] : 'Ready');
				$style = (isset($class[1]) && !empty($class[1]) ? $class[1] : '');
				$id = str_replace('/', '', $date[1]);

				$data = str_replace($countdown[0], cmseCountDown($date[1], $id, $style, $msge), $data);
			}
		}
	}



	/* Iframe
	---------------------*/
	if( preg_match_all('#\[iframe=\"(.*?)\"\]#i', $data, $iframes, PREG_SET_ORDER) )
	{
		foreach($iframes as $fkey => $iframe) {
			$frame = '<iframe src="'.$iframe[1].'" width="100%" name="frame'.$fkey.'" class="cmseframe frame'.$fkey.'" scrolling="no" frameborder="0" marginheight="0" marginwidth="0" seamless allowfullscreen allowtransparency></iframe>';
			$data = str_replace($iframe[0], $frame, $data);
		}
	}
	
	
	/* Video
	-------------------*/
	if( preg_match_all('#\[video=\"(.*?)\"\]#is', $data, $videos, PREG_SET_ORDER) )
	{
		foreach($videos as $video) 
		{
			$data = str_replace($video[0], cmseVideoPlayer($video[1]), $data);
		}
	}

	// Font Awesome Icons [fa="fas fa-arrow-alt-circle-down"]
	if( preg_match_all('#\[fa=\"(.*?)\"\]#si', $data, $fas, PREG_SET_ORDER) )
	{
		foreach($fas as $fa) {
			$data = str_replace($fa[0], '<i class="'.$fa[1].' faicon"></i>', $data);
		}
	}


	// Tabs
	// [tab The Story|newclass]The data[/tab]
	if( preg_match_all('#\[tab\s+(.*?)(|\|(.*?))\]#si', $data, $verticalslides, PREG_SET_ORDER) )
	{
		inlineJs('cmseslides("slidetab","slidecontent",0);');
		inlineJs('
			jQuery(function($) {

				if( $(window).width() > 980 ) {
					//$(".slidetab.tab").wrapAll("<div class=\"tabnav\" />");
					$(".tabnav").append($(".tab"));
				}

			});
		');

		// slide output
		foreach($verticalslides as $vslide)
		{
			// insert css class per slide
			$vslidestyle='';
			if( isset($vslide[3]) ) {
				$vslidestyle = ' '.$vslide[3];
			}

			$vstr = [$vslide[0], '[/tab]'];
			$vrpl = ['<h4 class="slidetab tab'.$vslidestyle.'"><span>'.$vslide[1].'</span></h4><div class="slidecontent'.$vslidestyle.'">', '<div class="clearall"></div></div>'];
			$data = str_replace($vstr, $vrpl, $data);
		}
	}

	// Slides
	// [slide The Story|newclass]The data[/slide]
	if( preg_match_all('#\[slide\s+(.*?)(|\|(.*?))\]#si', $data, $verticalslides, PREG_SET_ORDER) )
	{
		inlineJs('cmseslides("slidetab","slidecontent",0);');

		// slide output
		foreach($verticalslides as $vslide)
		{
			// insert css class per slide
			$vslidestyle='';
			if( isset($vslide[3]) ) {
				$vslidestyle = ' '.$vslide[3];
			}

			$vstr = [$vslide[0], '[/slide]'];
			$vrpl = ['<h4 class="slidetab'.$vslidestyle.'"><span>'.$vslide[1].'</span></h4><div class="slidecontent'.$vslidestyle.'">', '<div class="clearall"></div></div>'];
			$data = str_replace($vstr, $vrpl, $data);
		}
	}




	/* Social network
	--------------------------*/
	preg_match_all('#\[facebook\s+(.*?)\]#i', $data, $fb, PREG_SET_ORDER);

	foreach($fb as $fbi)
	{
		// facebook post embed shortcode using the pot URL eg: [insert fbpost="https://www.facebook.com/irishandchin/posts/10155576519091075"]
		if( preg_match('#post=\"(.*?)\"#i', $fbi[1], $fbobj) ) {
			$fbpost = '<div class="text-center"><div class="fb-post" data-href="'.rawurldecode($fbobj[1]).'" data-width="500" data-show-text="true"></div></div>';
			$data = str_replace($fbi[0], $fbpost, $data);
		}
		//facebook post comment [facebook postcomment="https://www.facebook.com/mcr/videos/10155458479561636/?comment_id=10155458718791636"]
		if( preg_match('#postcomment=\"(.*?)\"#i', $fbi[1], $fbpc) ) {
			$fbpostcomment = '<div class="fb-comment-embed" data-href="'.rawurldecode($fbpc[1]).'" data-width="500" data-include-parent="false"></div>';
			$data = str_replace($fbi[0], $fbpostcomment, $data);
		}
		// facebook page feed
		if( preg_match('#page=\"(.*?)\"#i', $fbi[1], $fbpg) )
		{
			$fbatt = explode(',',$fbpg[1]);

			/*
			* [facebook page="url,width,height,facepile,timeline,events,messages"]
			* [facebook page="https://www.facebook.com/mycaribbeanradio/,500,600,true,timeline"]
			* only the facebook URL is required, however other elements are used, they must follow the order as above
			* If an attribute is to be ommitted, a comma must exist as a placeholder
			* example of skipped attribute: URL,,height,,timeline
			*/

			if( isset($fbatt[0]) && !empty($fbatt[0]) && strstr($fbatt[0], 'facebook.com') )
			{
				$fb_pg = '<div class="fb-page"
				data-href="'.$fbatt[0].'"
				data-small-header="false"
				data-tabs="'.(empty($fbatt[4]) ? '' : $fbatt[4]).(empty($fbatt[5]) ? '' : ','.$fbatt[5]).(empty($fbatt[6]) ? '' : ','.$fbatt[6]).'"
				data-width="'.(empty($fbatt[1]) ? '300' : $fbatt[1]).'"
				data-height="'.(empty($fbatt[2]) ? '600' : $fbatt[2]).'"
				data-adapt-container-width="true"
				data-hide-cover="false"
				data-show-facepile="'.(empty($fbatt[3]) ? 'true' : $fbatt[3]).'"
				>
					<div class="fb-xfbml-parse-ignore">
						<blockquote cite="'.$fbatt[0].'">
							<a href="'.$fbatt[0].'"></a>
						</blockquote>
					</div>
				</div>';
			}

			$data = str_replace($fbi[0], $fb_pg, $data);
		}
	}


	//----[ Twitter inserts ]-------//
	preg_match_all('#\[twitter\s+(.*?)\]#i', $data, $twts, PREG_SET_ORDER);

	foreach($twts as $twt)
	{
		// twitter feed shortcode
		if( preg_match('#page=\"(.*?)\"#i', $twt[1], $twtpg) )
		{
			$twitatt = explode(',',$twtpg[1]);

			/*
			* [twitter page="url,theme,width,height"]
			* [twitter page="https://twitter.com/subaru_usa,dark,width,height"]
			* only the twitter URL is required, however all subsequent attributes must follow the order
			* If an attribute is to be ommitted, a comma must exist as a placeholder
			* example of skipped attribute: URL,,width,
			*/
			if( isset($twitatt[0]) && !empty($twitatt[0]) && strstr($twitatt[0], 'twitter.com') )
			{
				$twt_pg = '<a class="twitter-timeline"
				data-chrome="nofooter"
				data-theme="'.(empty($twitatt[1]) ? 'dark' : $twitatt[1]).'"
				data-height="'.(empty($twitatt[3]) ? '300' : $twitatt[3]).'"
				data-width="'.(empty($twitatt[2]) ? '300' : $twitatt[2]).'"
				href="'.$twitatt[0].'"></a>';
			}

			$data = str_replace($twt[0], $twt_pg, $data);
		}


		// twitter post embed
		// get the link to tweet
		// [twitter post="https://twitter.com/eugenegu/status/911935874711085057"]
		if( preg_match('#post=\"(.*?)\"#i', $twt[1], $twtpost) )
		{
			$twitpostatt = explode(',',$twtpost[1]);

			$twt_post = '<blockquote class="twitter-tweet"
				data-conversation="'.(empty($twitpostatt[1]) ? 'none' : $twitpostatt[1]).'"
				data-lang="'.(empty($twitpostatt[2]) ? 'en' : $twitpostatt[2]).'"
				data-theme="'.(empty($twitpostatt[3]) ? 'light' : $twitpostatt[3]).'"
				data-width="'.(empty($twitpostatt[4]) ? '' : $twitpostatt[4]).'"
				data-cards="'.(empty($twitpostatt[5]) ? '' : $twitpostatt[5]).'"
				>
				<a href="'.$twitpostatt[0].'"></a></blockquote>';

				$data = str_replace($twt[0], $twt_post, $data);
		}

	}

	//----[ Instagram inserts ]-------//
	preg_match_all('#\[ig=\"(.*?)\"\]#i', $data, $igs, PREG_SET_ORDER);
	foreach($igs as $ig)
	{
		$igpost = '
		<blockquote class="instagram-media"
		data-instgrm-captioned=""
		data-instgrm-permalink="'.$ig[1].'"
		data-instgrm-version="8">
		</blockquote>
		';
		$data = str_replace($ig[0], $igpost, $data);
	}

	//-----[ Pinterest ]-----/
	preg_match_all('#\[pin=\"(.*?)\"\]#i', $data, $pins, PREG_SET_ORDER);
	foreach($pins as $pin)
	{
		$pinval = explode(',', $pin[1]);
		$pinpost = '<a data-pin-do="embed'.$pinval[1].'" data-pin-width="large" data-pin-terse="true" href="'.$pinval[0].'"></a>';

		if( $pinval[1] == 'User' ) {
			$pinpost = '
				<a
				data-pin-do="embed'.$pinval[1].'"
				data-pin-board-width="'.(empty($pinval[2]) ? '' : $pinval[2]).'"
				data-pin-scale-height="'.(empty($pinval[3]) ? '' : $pinval[3]).'"
				data-pin-scale-width="'.(empty($pinval[4]) ? '' : $pinval[4]).'"
				href="'.$pinval[0].'"></a>
			';
		}

		$data = str_replace($pin[0], $pinpost, $data);
	}


	/* Contact Form Shortcode
	-----------------------------*/
	if( preg_match_all('#\[contactform="(.*?)"(.*?)\]#is', $data, $contacts, PREG_SET_ORDER) )
	{
		foreach($contacts as $contact)
		{
			$selectfield= $selection= $subjectAppend='';
			if( isset($contact[2]) && !empty($contact[2]) )
			{
				if( preg_match('#labels=\"\d\"#is', $contact[2], $labl) ) {
					$contact[2] = str_replace($labl[0], '', $contact[2]);
					if( (int)$labl[0] == 0 ) {
						$nolabel = true;
					}
				}
				// get select options if set
				parse_str($contact[2], $val);
				$lbl = array_keys($val)[0];
				$selects = explode(',', str_replace('"', '', $val[$lbl]));

				$selectfield = '
				<div class="form-group">';
				if( !$nolabel ) $selectfield .= '<label>'.ucfirst($lbl).'</label>';
				$selectfield .= '<div class="control">
				<select name="'.cleanChars($lbl, '', true).'">';
				foreach($selects as $select) {
					$selectfield .= '<option value="'.$select.'">'.$select.'</option>';
				}
				$selectfield .= '</select></div></div>
				';

				$selection = '<h3>'.ucfirst($lbl).': '.getPost(cleanChars($lbl, '', true), false).'</h3>';
				$subjectAppend = ' - '.ucfirst($lbl).': '.getPost(cleanChars($lbl, '', true), false);
			}

			ob_start();
			include LIB_PATH.'/Admin/forms/contactform.php';
			$data = str_replace($contact[0], ob_get_clean(), $data);
		}
	}
	
	
	/* File Download
	* [download="directory/file.zip"]
	-------------------------*/
	if( preg_match_all('#\[download="(.*?)"\]#is', $data, $downloads, PREG_SET_ORDER) )
	{
		$statsdir = LIB_PATH.'/Admin/resource/';
		$i=0;
		
		foreach($downloads as $download) 
		{
			if( !isset($download[1]) )
				return;
			
			$filepath = ROOTDIR.'/'.$download[1];
			$fileurl = ROOT_URL.$download[1];
			$filename = pathinfo($download[1])['basename'];
			$statfile = $statsdir.$filename.'.txt';
			
			$i++;
			
			// output count data from download log files
			$count='';

			if( file_exists($statfile) ) 
			{
				$c = fopen($statfile, "r");
				$v = fread($c, filesize($statfile));
				fclose($c);
				$count = ' <span class="dlcount">('.$v.' downloads)</span>';
			}
			
			if( file_exists($filepath) ) 
			{
				if( !is_null(getPost('file'.$i, false)) ) 
				{
					if( file_exists($statfile) ) {
						$c = fopen($statfile, "w");
						fwrite($c, $v+1);
						fclose($c);
					
					}else{
						$c = fopen($statfile, "w+");
						fwrite($c, 1);
						fclose($c);
					}
				
					header('Content-Description: File Transfer');
					header('Content-Type: application/octet-stream');
					header('Content-Disposition: attachment; filename="'.$filename.'"');
					header('Expires: 0');
					header('Cache-Control: must-revalidate');
					header('Pragma: public');
					header('Content-Length: ' . filesize($filepath));
					readfile($filepath);
					exit;
				}
			
				// convert bytes to get file size in KB or MB
				$decimal = 2;
				$um = 'BKMGTP';
				$factor = floor((strlen(filesize($filepath)) - 1) / 3);
				$size = sprintf("%.{$decimal}f", filesize($filepath) / pow(1024, $factor)) . @$um[$factor];

				// hash value
				$hash = hash_file('md5', $filepath);
			
				// enable file information display
				$fileinfo = '
				<div class="fileinfo">
				<span>'.$filename.' ('.$size.')</span>
				<span>file hash value: '.$hash.'</span>
				</div>';
		  
				$html = '
				<div class="dlblock">
					<form method="post">
						<button class="btn btn-primary" name="file'.$i.'">
						<span><i class="fas fa-cloud-download-alt"></i></span><span> Download</span></button>'.$count.'
					</form>
					'.$fileinfo.'
				</div>
				';
				$data = str_replace($download[0], $html, $data);
			}
		}
	}


	return $data;
}


// Strip shortcodes for meta description
function stripShortcodes() {
}


/* Pagination
-----------------------------*/
function pagingLinks($total, $limit, $page = 1, $links = 10, $list_class = 'cmse-pagination')
{
	list($component, $view, $category, $post, $menuid, $listpage, $prodid, $groupid, $parent) = getNonSEF();

	if( requestKey('module') ) {
		// admin area
		$current = 'addonmodules.php?module='.MODNAME.'&listpage=';
	}else{
		// front end
		$menu_id='';
		if( isset($menuid) )
			$menu_id = '&menuid='.$menuid;
		$current = router('index.php?component=posts&view=category&category='.$category.$menu_id).'?listpage=';
	}

	$last	= ceil( $total / $limit );
	$start	= ( ( $page - $links ) > 0 ) ? $page - $links : 1;
	$end	= ( ( $page + $links ) < $last ) ? $page + $links : $last;

	$html	= '<ul class="'.$list_class.'">';
	$class	= ( $page == 1 ) ? "disabled" : "";
	$html	.= '<li class="'.$class.'"><a href="'.$current.($page - 1).'">&laquo;</a></li>';

	if( $start > 1 ) {
		$html	.= '<li><a href="'.$current.'1">1</a></li>';
		$html	.= '<li class="disabled"><span>...</span></li>';
	}

	for( $i = $start ; $i <= $end; $i++ ) {
		$class	= ($page == $i) ? "active" : "";
		$html	.= '<li class="'.$class.'"><a href="'.$current.$i.'">'.$i.'</a></li>';
	}

	if( $end < $last ) {
		$html	.= '<li class="disabled"><span>...</span></li>';
		$html	.= '<li><a href="'.$current.$last.'">'.$last.'</a></li>';
	}

	$class	= ($page == $last) ? "disabled" : "";
	$html	.= '<li class="'.$class.'"><a href="'.$current.($page + 1).'">&raquo;</a></li>';

	$html	.= '</ul>';

	if( $limit > $total ) {
		return;
	}else{
		return $html;
	}
}



/* JS Paginator
-----------------------*/
function cmsePaginatejs($values, $instanceId)
{
	$document = JFactory::getDocument();

	$pagecount = explode(',',$values);
	$document->addScriptDeclaration('
	jQuery(function($){
		$("#paginate-'.$instanceId.'").pajinate({
			item_container_id : ".paginate-'.$instanceId.'",
			items_per_page : '.$pagecount[0].',
			num_page_links_to_display : '.$pagecount[1].'
		});
	});
	');

}



/* Slideshow
-----------------------*/
function cmseSlideShow($slides, $id, $autostart=1, $height=500, $width=100, $delay=3000, $nav=0, $navwidth=30, $navcount=5, $slidespeed=800)
{
	ob_start();
	include LIB_PATH.'/cmse/slideshow/slideshow.php';
	$slidewrap = ob_get_clean();

	return $slidewrap;
}


function cmseSlides($input, $id, $config=[])
{
	$config = (object)$config;
	$autostart = (!empty($config->autostart) ? $config->autostart : 1); // 1 or 0
	$height = (!empty($config->height) ? $config->height : 500); // pixel
	$width = (!empty($config->width) ? $config->width : 100); // percentage max 100
	$delay = (!empty($config->delay) ? $config->delay : 3000); // milisecond 3000 = 3 seconds
	$slidespeed = (!empty($config->slidespeed) ? $config->slidespeed : 800); // millisecond
	$shownav = (!empty($config->shownav) ? $config->shownav : 0); // 1 or 0
	$navwidth = (!empty($config->navwidth) ? $config->navwidth : 30); // percentage max 100
	$navcount = (!empty($config->navcount) ? $config->navcount : 5);

	$slidejs = '
	<script>
        '.$id.'_jssor_1_slider_init = function()
		{
            var '.$id.'_jssor_1_SlideoTransitions = [
              [{b:-1,d:1,o:-0.7}],
              [{b:900,d:2000,x:-379,e:{x:7}}],
              [{b:900,d:2000,x:-379,e:{x:7}}],
              [{b:-1,d:1,o:-1,sX:2,sY:2},{b:0,d:900,x:-171,y:-341,o:1,sX:-2,sY:-2,e:{x:3,y:3,sX:3,sY:3}},{b:900,d:1600,x:-283,o:-1,e:{x:16}}]
            ];

            var '.$id.'_jssor_1_options = {
              $AutoPlay: '.$autostart.',
              $SlideDuration: '.$slidespeed.',
			  $Idle: '.$delay.',
              $SlideEasing: $Jease$.$OutQuint,
              $CaptionSliderOptions: {
                $Class: $JssorCaptionSlideo$,
                $Transitions: '.$id.'_jssor_1_SlideoTransitions
              },
              $ArrowNavigatorOptions: {
                $Class: $JssorArrowNavigator$
              },
              $BulletNavigatorOptions: {
                $Class: $JssorBulletNavigator$
              }
            };

            var '.$id.'_jssor_1_slider = new $JssorSlider$("'.$id.'_jssor_1", '.$id.'_jssor_1_options);

            /*#region responsive code begin*/

            var MAX_WIDTH = 3000;

            function ScaleSlider() {
                var containerElement = '.$id.'_jssor_1_slider.$Elmt.parentNode;
                var containerWidth = containerElement.clientWidth;

                if (containerWidth) {

                    var expectedWidth = Math.min(MAX_WIDTH || containerWidth, containerWidth);

                    '.$id.'_jssor_1_slider.$ScaleWidth(expectedWidth);
                }
                else {
                    window.setTimeout(ScaleSlider, 30);
                }
            }

            ScaleSlider();

            $Jssor$.$AddEvent(window, "load", ScaleSlider);
            $Jssor$.$AddEvent(window, "resize", ScaleSlider);
            $Jssor$.$AddEvent(window, "orientationchange", ScaleSlider);
            /*#endregion responsive code end*/
        };
		</script>
	';

	//inlineJs($slidejs);
	// no method yet to implement navigation - pending
	$nav = '
	<!-- Bullet Navigator -->
        <div data-u="navigator" class="jssorb032" style="position:absolute;bottom:12px;right:12px;" data-autocenter="1" data-scale="0.5" data-scale-bottom="0.75">
            <div data-u="prototype" class="i" style="width:16px;height:16px;">
                <svg viewbox="0 0 16000 16000" style="position:absolute;top:0;left:0;width:100%;height:100%;">
                    <circle class="b" cx="8000" cy="8000" r="5800"></circle>
                </svg>
            </div>
        </div>
        <!-- Arrow Navigator -->
        <div data-u="arrowleft" class="jssora051" style="width:65px;height:65px;top:0px;left:25px;" data-autocenter="2" data-scale="0.75" data-scale-left="0.75">
            <svg viewbox="0 0 16000 16000" style="position:absolute;top:0;left:0;width:100%;height:100%;">
                <polyline class="a" points="11040,1920 4960,8000 11040,14080 "></polyline>
            </svg>
        </div>
        <div data-u="arrowright" class="jssora051" style="width:65px;height:65px;top:0px;right:25px;" data-autocenter="2" data-scale="0.75" data-scale-right="0.75">
            <svg viewbox="0 0 16000 16000" style="position:absolute;top:0;left:0;width:100%;height:100%;">
                <polyline class="a" points="4960,1920 11040,8000 4960,14080 "></polyline>
            </svg>
        </div>
	';

	// slide output
	$slidewrap = '
	<div id="'.$id.'_jssor_1" class="jssorwrap" style="height: '.$height.'px;">
		<!-- Loading Screen -->
		<div data-u="loading" class="jssorl-009-spin">
			<img src="'.LIB_URL.'/cmse/slideshow/spin.svg" />
		</div>
		<div data-u="slides" class="jssorslides">
		'.$input.'
		</div>
	</div>
	<script type="text/javascript">'.$id.'_jssor_1_slider_init();</script>
	';

	return $slidejs . $slidewrap;
}


//--------[ Video Player ]
function cmseVideoplayer($videoitems, $autoplay='', $firstvid='')
{
	$itemcount=''; $vid=[];

	if( is_array($videoitems) && count($videoitems) >= 1 )
	{
		$itemcount = count($videoitems);

		foreach($videoitems as $vidobj) {
			$vid[] = (object)$vidobj;
		}

		$firstitem = $vid[0]->url;
	}else{
		$firstitem = $videoitems;
	}

	ob_start();
	include LIB_PATH.'/cmse/videoplayer/vidblock.php';
	return ob_get_clean();
}




//--------[ Audio Player ]
function cmseAudio_Player($audioitems, $autoplay='', $first='')
{
	$itemcount=''; $audio=[];

	$firstitem = $first;
	if( count($audioitems) >= 1 )
	{
		$itemcount = count($audioitems);

		foreach($audioitems as $audioobj) {
			$audio[] = (object)$audioobj;
		}

		$firstitem = $audio[0]->url;
	}

	ob_start();
	include LIB_PATH.'/cmse/audioplayer/audioblock.php';
	return ob_get_clean();
}

function cmseAudioPlayer($audiolist, $playerid, $autoplayaudio='', $playerposition='')
{
	$audioitems=[];

	if( count($audiolist) >= 1 )
	{
		$item_count = count($audiolist);

		foreach($audiolist as $audobj) {
			$audioitems[] = (object)$audobj;
		}

		$first_item = $audioitems[0]->url;
	}

	ob_start();
	include LIB_PATH.'/cmse/audioplayer/audioblock.php';
	return ob_get_clean();
}



// admin tool bar
function loadTemplate($tmpl)
{
	if( requestKey('module') ) {
		$src = LIB_PATH.'/Admin/'.$tmpl;
	}else{
		$src = ROOT_PATH.$tmpl;
	}

	include $src;
}


function showHooks() {
	global $hooks;
	return $hooks;
}

function varWhmcs() {
	$whmcs = Application::getInstance();
	return $whmcs;
}

function whmcsGlobal() {
	global $whmcs;
	return $whmcs;
}

function smartyVals() {
	global $smartyvalues;
	return $smartyvalues;
}

function getReferer() {
	return $_SERVER['HTTP_REFERER'];
}

function getRemoteIp() {
	$ip = filter_var($_SERVER['REMOTE_ADDR'], FILTER_VALIDATE_IP);
	return $ip;
}


function getCmseVersion() {
	$ver = simplexml_load_file(MODPATH.'/cmseframework.xml');
	$version = (string)$ver->version;
	
	return $version;
}

function cmseVersion($vars) {
	echo '<p class="text-center version">'.$vars['module'].' '.getCmseVersion().' - Support <a href="https://cmsenergizer.com" target="_blank">CMSEnergizer.com</a></p>';
}


function httpResponse() {
	$request = \WHMCS\Http\Message\ServerRequest::fromGlobals();
	$resp = DI::make("Frontend\\Dispatcher")->dispatch($request);

	return $resp->getStatusCode();
}


function setNewStatus($code)
{
	$response = new WHMCS\ClientArea();
	$response->setPageTitle('');
	$response->setTemplate('');
	$response = $response->withStatus($code);

	(new Zend\Diactoros\Response\SapiEmitter())->emit($response);
}


function fileWritePrepend($file, $data, $string) {
	$content = file_get_contents($file);

	if( preg_match('#\b('.$string.')\b#i', $content) ) {
		return;
	}else{
		return file_put_contents($file, $data.$content, LOCK_EX);
	}
}

// tool tip
function cmseToolTip($data, $title='Information')
{
	$tip = (defined($data) ? constant($data) : $data);
	
	$tooltip = ' 
	data-toggle="popover" 
	data-placement="top" 
	data-trigger="hover" 
	data-html="true" 
	title="'.$title.'" 
	data-content="'.$tip.'"
	';
	
	return $tooltip;
}

function cmseNotice($error, $alert='danger', $message='Caught Exception') {
	echo '<div class="alert alert-'.$alert.'">'.$message.':<br />',  $error.'</div>';
}


// version resolution
function doVersion() {
	return version_compare(getSetting('Version'), '7.6', '<');
}

function doCaptcha() 
{
	if( doVersion() ) {
		$captcha = clientAreaInitCaptcha();
	}else{
		$captcha = new \WHMCS\Utility\Captcha;
	}
	
	return $captcha;
}


function debug($var) {
	$out = print_r($var, true);
	echo '<pre>'.$out.'</pre>';
}

