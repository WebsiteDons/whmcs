<?php
/*
* Copyright (c) 2019 CMSEnergizer.com. All Rights Reserved
* License: GNU General Public License version 2 or later; see http://www.gnu.org/licenses/
* Author: Alex
*/

if( !defined("WHMCS") ) die("This file cannot be accessed directly");

$tpl = basename(__DIR__);




/*
* The is parent file is used to process php actions and pass to the display as either SMARTY or php variables
*
* Assign Smarty Variables for use in widget template
* getSmarty()->assign([
* 'myfield' => $my_php_var,
* 'myothervar' => $my_other_var
* ]);

* If the output is SMARTY tpl file:					widgetTpl($tpl);
* if the out put file is .php:						include 'tmpl/default.php';
* If display file is php, output field values:		echo $params->domain_text;
* If is smarty tpl, output field values:			{$params->domain_text}
*/


if( $params->order == 'rand' ) {
	$banners = banners()
			->where('state', 1)
			->whereIn('catid', $params->bannercats)
			->limit($params->count)
			->inRandomOrder()
			->get();
}else{
	$banners = banners()
			->where('state', 1)
			->whereIn('catid', $params->bannercats)
			->limit($params->count)
			->orderBy($params->order, $params->direction)
			->get();
}

$banneritem =[];
foreach($banners as $banner) 
{
	$attribs = json_decode($banner->attribs);
	
	$styleheight = ($attribs->bannerheight != '' ? ' style="min-height: '.$attribs->bannerheight.'px;"' : '');
	$link= $linkend='';
	if( !empty($attribs->link) ) {
		$link = '<a class="displayblock" href="'.$attribs->link.'"'.$styleheight.'>';
		$linkend = '</a>';
	}
	
	$bannertext = ($attribs->bannertext != '' ? cmseElements(html_entity_decode($attribs->bannertext)) : '');
	$bannerheight = ($attribs->bannerheight != '' ? ' min-height: '.$attribs->bannerheight.'px' : '');
	
	$image= $video= $html= $bgstyle= $innerwrap='';
	
	// image
	if( $banner->type == 'image' ) 
	{
		$img = ($attribs->setbg == '' ? $bannertext.'<img src="'.IMAGES.$banner->adcontent.'" style="display: block; margin: auto;" />' : $bannertext);
		
		if( $attribs->setbg == 'cover' || $attribs->setbg == 'contain' ) {
			$bgsize = ($attribs->setbg == 'cover' ? 'cover' : 'contain');
			$bgstyle = ' style="background: url('.IMAGES.$banner->adcontent.') top no-repeat; overflow: hidden; background-size: '.$bgsize.';'.$bannerheight.'"';
			$innerwrap = ' inner-wrap';
		}
		
		$image = '
			<div class="bn-item bn-image"'.$bgstyle.'>
				<div class="bn-detail'.$innerwrap.'">'.$link.$img.$linkend.'</div>
			</div>';
	}
	// video
	if( $banner->type == 'video' ) 
	{
		
		$vidlink='';
		if( $attribs->link != '' && $attribs->linktext != '' ) {
			$vidlink = '<a class="layer layerleft-40 layertop-60 btn btn-lg btn-primary" href="'.$attribs->link.'">'.$attribs->linktext.'</a>';
		}
		
		$endplay = ($attribs->endplay == 1 ? 'player.playVideo()' : '');
		
		$hideplayer= $hideclass='';
		if( $attribs->endplay == 2 ) {
			$hideplayer = '
			jQuery(function($) {
				$(".hidevideo").slideToggle(1000);
			});
			';
			$hideclass = ' hidevideo';
		}
		
		$autoplay = 0; $mute = '';
		if( $attribs->autoplay == 1 ) {
			$autoplay = 1;
			$mute = 'onReady: function(e) {e.target.mute();},';
		}else
		if( $attribs->autoplay == 2 ) {
			$autoplay = 1;
		}
		
		$output = '
		<div id="YouTubeVideo"></div>
			
			<script>
			var tag = document.createElement("script");
			tag.src = "https://www.youtube.com/iframe_api";
			var firstScriptTag = document.getElementsByTagName("script")[0];
			firstScriptTag.parentNode.insertBefore(tag, firstScriptTag);

			function onYouTubeIframeAPIReady() {
				var player;
				player = new YT.Player("YouTubeVideo", {
					videoId: "'.getYoutubeID($banner->adcontent).'",
					
					playerVars: {
						autoplay: '.$autoplay.',
						controls: 0,
						showinfo: 0,
						vq: "hd",
						modestbranding: 1,
						loop: '.$attribs->endplay.',
						rel: 0,
						fs: 0,
						cc_load_policy: 0,
						iv_load_policy: 3,
						autohide: 0
					},
					events: {
						'.$mute.'
						onStateChange: function(e){
							if (e.data === YT.PlayerState.ENDED) {
								'.$endplay.$hideplayer.';
							}
						}
					}
				});
			}
			</script>
			';
		
		
		$video = '
			<div class="bn-item bn-video'.$hideclass.'">
			'.$vidlink.'
			<div class="vidwrap">'.$output.'</div>
			'.$bannertext.'
			</div>';
	}
	//html
	if( $banner->type == 'html' ) {
		$html = '<div class="bn-item bn-html">'.$link.'<div>'.$banner->adcontent.'</div>'.$linkend.'</div>';
	}
	
	$banneritem[] = $image . $video . $html;
}

getSmarty()->assign('banners', implode('', $banneritem));

/* load display file after php processes above
-------------------------------------------------*/
widgetTpl($tpl);