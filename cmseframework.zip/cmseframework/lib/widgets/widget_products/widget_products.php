<?php
/*
* Copyright (c) 2019 CMSEnergizer.com. All Rights Reserved
* License: GNU General Public License version 2 or later; see http://www.gnu.org/licenses/
* Author: Alex/Kumar/Manti/Lisa
*/

if( !defined("WHMCS") ) die("This file cannot be accessed directly");

$tpl = basename(__DIR__);
list($component, $view, $category, $post, $menuid, $listpage, $prodid, $groupid) = getNonSEF();

// post items in category view
$itemclass = $itemwidth= $equalheight= $eqtitle= $eqimg='';
if( $params->itemsperrow > 1 )
{
	$itemclass = ' boxsize break grid';
	$equalheight = ' equalheight';
	$itemwidth = ' style="width: '.round(100/(int)$params->itemsperrow).'%;"';
	$eqtitle = ' data-mh="eqtitle"';
	if( $params->imgmask =='' )
		$eqimg = ' data-mh="eqimg"';
}

$imgmask='';
if( $params->imgmask !='' ) {
	$imgmask = ' style="height: '.$params->imgmask.'px;"';
}





/** categories
------------------------------------*/
if( $params->displaytype == 'groups' )
{
	if( !empty($params->postcats) ) 
	{
		// get categories by selected ID
		$gids = (array)$params->postcats;
		$groups = groups()
			->whereIn('id', $gids)
			->where('hidden', 0)
			->select('id', 'name', 'headline', 'tagline')
			->orderBy($params->sortmethod, $params->sortdirection)
			->get();
	}else
	{
		// get all categories
		$groups = groups()
			->where('hidden', 0)
			->select('id', 'name', 'headline', 'tagline')
			->orderBy($params->sortmethod, $params->sortdirection)
			->get();
	}
		
	/*$low = products()->whereIn('gid', explode(',', $params->groupid))->pluck('gid', 'id');
	$pric = getDbo('tblpricing')
		->select('monthly','quarterly','semiannually','annually','biennially','triennially')
		->where('type', 'product')
		->where('monthly','<>','-1.00')
		->whereIn('relid', [8,9,10])
		->get();
		*/

		
	$output=[];
	foreach($groups as $group) 
	{
		$layout = cmseElements(html_entity_decode($params->layout));
		$link = '<a href="'.ROOT_URL.cleanChars($group->name).'">';
		$btnlink = '<a class="btn btn-block btn-lg btn-info" href="'.ROOT_URL.cleanChars($group->name).'">';
		$linkend = '</a>';
		$gid = $group->id;
		
		$title = '<h3 class="post-title product-group"><span>'.$link.$group->name.$linkend.'</span></h3>';
		$introtext = '<div class="introtext">'.cmseElements(html_entity_decode($group->headline)).'</div>';
		$text = '<div class="longtext">'.cmseElements(html_entity_decode($group->tagline)).'</div>';
		$button = '<div class="readmore">'.$btnlink.$params->buttonlabel.$linkend.'</div>';
		
		$imgsrc = cmseproducts()->where('group_id', $group->id)->value('group_image');
		$defimg = (!empty($params->defaultimg) ? '<div class="postimg"><span><img src="'.IMAGES.$params->defaultimg.'" /></span></div>' :'');
		$image = (!empty($imgsrc) ? '<div class="postimg"><span><img src="'.IMAGES.$imgsrc.'" alt="'.$group->name.'" /></span></div>' : $defimg);
		
		// shortcode replace
		$sc = [
		'[title]',
		'[introtext]',
		'[text]',
		'[image]',
		'[button]'
		];
		
		$rpl = [
		$title,
		$introtext,
		$text,
		$image,
		$button
		];
		
		$output[] = '
		<div class="post-item gid-'.$gid.$itemclass.$featured.'"'.$itemwidth.'>
			<div class="inner'.$equalheight.'">
			'.str_replace($sc, $rpl, $layout).'
			<div class="clearall"></div>
			</div>
		</div>
		';
	}



}else{



/** Products
-------------------------------------*/
if( !empty($params->product_id) ) {
	$itemids = explode(',', $params->product_id);
	$items = products()
		->select('id','gid','name','description','paytype','is_featured','created_at')
		->whereIn('id', $itemids)
		->where('hidden', 0)
		->get();
}else{
	$groups = (array)$params->postcats;
	$items = products()
		->select('id','gid','name','description','paytype','is_featured','created_at')
		->whereIn('gid', $groups)
		->where('hidden', 0)
		->orderBy($params->sortmethod, $params->sortdirection)
		->limit($params->itemcount)
		->get();
}



$output=[];
foreach($items as $item)
{
	$layout = cmseElements($params->layout);

	$groupname = groups()->where('id', $item->gid)->value('name');
	$prodcmse = cmseproducts()->where('prod_id', $item->id)->get()[0];

	$rawurl = 'index.php?component=products&view=productdetail&gid='.$item->gid.'-'.cleanChars($groupname).'&pid='.$item->id.'-'.$prodcmse->prod_alias;
	$itemlink = ROOT_URL.router($rawurl);
	$featured = ($item->is_featured == 1 ? ' featured' : '');

	$title = '<h3 class="post-title"'.$eqtitle.'><span><a href="'.$itemlink.'">'.$item->name.'</a></span></h3>';

	$text = (!empty($params->textlimit) ? truncText(html_entity_decode($item->description), $params->textlimit) : html_entity_decode($item->description));
	$text = '<div class="post-text" data-mh="eqtext">'.cmseElements($text).'</div>';

	// default to secure hosted image if none of the below values are true
	$img = 'https://i.ibb.co/qRvM4MP/default.png';
	if( !empty($prodcmse->prod_image) && file_exists(IMGPATH.'/'.$prodcmse->prod_image) ) {
		$img = IMAGES.$prodcmse->prod_image;
	}else
	if( !empty($params->defaultimg) && file_exists(IMGPATH.'/'.$params->defaultimg) ) {
		$img = IMAGES.$params->defaultimg;
	}else
	if( file_exists(IMGPATH.'/assets/default.png') ) {
		$img = IMAGES.'assets/default.png';
	}
	$image = '
	<div class="post-image">
		<span class="imgmask"'.$imgmask.$eqimg.'>
			<a href="'.$itemlink.'"><img src="'.$img.'" alt="'.$item->name.'" /></a>
		</span>
	</div>
	';

	$date = '<span class="post-date">'.dateFormat($item->created_at).'</span>';

	$price = '<div>'.itemPrice($item->id, $item->paytype).'</div>';
	$addcart = '<a class="btn btn-sm btn-success" href="'.cmseUri().'cart.php?a=add&pid='.$item->id.'"><i class="fas fa-cart-plus"></i> Order Now</a>';

	$author='';
	$hits='';
	$votes='';


	$objectholders = [
	'[title]',
	'[image]',
	'[text]',
	'[date]',
	'[price]',
	'[addcart]',
	'[author]',
	'[hits]',
	'[votes]'
	];

	$objects = [
	$title,
	$image,
	$text,
	$date,
	$price,
	$addcart,
	$author,
	$hits,
	$votes
	];


	$output[] = '
	<div class="post-item'.$itemclass.$featured.'"'.$itemwidth.'>
	<div class="inner'.$equalheight.'">'.str_replace($objectholders, $objects, $layout).'<div class="clearall"></div></div>
	</div>
	';
}


}


// get pre and post text
$pretext = cmseElements(html_entity_decode($params->pretext));
$posttext = cmseElements(html_entity_decode($params->posttext));
$pretext = (!empty($params->pretext) ? '<div class="pretext">'.$pretext.'</div>' : '');
$posttext = (!empty($params->posttext) ? '<div class="posttext">'.$posttext.'</div>' : '');

getSmarty()->assign('product_items_layout', $pretext . implode('', $output) . $posttext);

/* load display file after php processes above
-------------------------------------------------*/
widgetTpl($tpl);