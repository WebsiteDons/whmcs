<?php
/*
* Copyright (c) 2019 CMSEnergizer.com. All Rights Reserved
* License: GNU General Public License version 2 or later; see http://www.gnu.org/licenses/
* Author: Alex
*/

?>

<div class="latest-posts">
<?php echo $product_items_layout; ?>
<div class="clearall"></div>
</div>