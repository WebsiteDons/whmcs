<?php
/*
* Copyright (c) 2019 CMSEnergizer.com. All Rights Reserved
* License: GNU General Public License version 2 or later; see http://www.gnu.org/licenses/
* Author: Alex
*/

if( !defined("WHMCS") ) die("This file cannot be accessed directly");

// get widget parent folder name
$tpl = basename(__DIR__);

// get menu items from selected group
$menuitems = menugroup($params->menugroup);


// process menu HTML
$cmsenav=[];
foreach(cmseMenu($menuitems) as $navitem) 
{
	$icon = ($navitem->getAttribute('icon') ? '<i class="'.$navitem->getAttribute('icon').'"></i> ' : '');
	$target = ($navitem->getAttribute('target') ? ' target="'.$navitem->getAttribute('target').'"' : '');

	$dropdown= $dropclass= $toggle= $caret= $subul= $subulend= $submenu='';
	
	// child menu items output condition
	if( $navitem->hasChildren() ) 
	{
		$dropdown = ' dropdown';
		if( $params->navtemplate == 'hover' ) {
			$drophover = '
			.dropdown-menu li:hover .sub-menu {visibility: visible;}
			.dropdown:hover .dropdown-menu {display: block;}
			';
		}
		$subul = '<ul class="subnav dropdown-menu">';
		$subulend = '</ul>';
		$dropclass = ' class="dropdown-toggle"';
		$toggle = ' data-toggle="dropdown"';
		$caret = ($params->showcaret ? ' <span class="caret"></span>' : '');
		
		// child items
		foreach($navitem->getChildren() as $subitem) 
		{
			$submenu .= '
			<li>
				<a href="'.$subitem->getUri().'">'.$subitem->getLabel().'</a>
			</li>
			';
		}
	}
	
	$cmsenav[] = '
	<li id="'.$navitem->getAttribute('id').'" class="navitem '.$navitem->getAttribute('class').$dropdown.'">
		<a href="'.$navitem->getUri().'"'.$dropclass.$toggle.$target.'>'.$icon.$navitem->getLabel().$caret.'</a>
		'.$subul . $submenu . $subulend.'
	</li>
	';
}
	

// output mini menu when on small mobile screen
$mobilenav= $css='';
if( $params->mobilenav && ($params->navtemplate == 'dropdown' || $params->navtemplate == 'hover') ) 
{
	$toggletext = 'Menu';
	$iconbar = '
	<span class="icon-bar"></span>
	<span class="icon-bar"></span>
	<span class="icon-bar"></span>
	';
	$txtel = ' class="sr-only"';
	
	if( !empty($params->togtext) ) {
		$toggletext = $params->togtext;
		$iconbar= $txtel='';
	}
	
	$mobilenav = '
	<div class="'.$params->togposition.'">
		<a class="btn btn-navbar navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse-'.$widget->id.'">
			<span'.$txtel.'><i class="fas fa-caret-square-down"></i> '.$toggletext.'</span>
			'.$iconbar.'
		</a>
	</div>
	';
	
	$collapseClass = ' class="collapse navbar-collapse-'.$widget->id.'"';

// set css
$css = inline_Css(
$drophover.'

.navbar-collapse-'.$widget->id.' {
  overflow-x: visible;
  -webkit-overflow-scrolling: touch;
  border-top: 1px solid transparent;
  -webkit-box-shadow: inset 0 1px 0 rgba(255, 255, 255, .1);
          box-shadow: inset 0 1px 0 rgba(255, 255, 255, .1);
}
.navbar-collapse-'.$widget->id.'.in {
  overflow-y: auto;
}
@media (min-width: 768px) {
  .navbar-collapse-'.$widget->id.' {
    width: auto;
    border-top: 0;
    -webkit-box-shadow: none;
            box-shadow: none;
  }
  .navbar-collapse-'.$widget->id.'.collapse {
    display: block !important;
    height: auto !important;
    padding-bottom: 0;
    overflow: visible !important;
  }
  .navbar-collapse-'.$widget->id.'.in {
    overflow-y: visible;
  }
  .navbar-fixed-top .navbar-collapse-'.$widget->id.',
  .navbar-static-top .navbar-collapse-'.$widget->id.',
  .navbar-fixed-bottom .navbar-collapse-'.$widget->id.' {
    padding-right: 0;
    padding-left: 0;
  }
}
');

}


getSmarty()->assign([
'cmsenav' => implode('', $cmsenav) . $css,
'hoverclass' => ($params->navtemplate == 'parent' ? ' class="nav menu nav-pills"' : ''),
'mobilenav' => $mobilenav,
'widgetid' => $widget->id,
'collapseClass' => $collapseClass
]);


widgetTpl($tpl);