<?php
/*
* Copyright (c) 2019 CMSEnergizer.com. All Rights Reserved
* License: GNU General Public License version 2 or later; see http://www.gnu.org/licenses/
* Author: Alex
*/

if( !defined("WHMCS") ) die("This file cannot be accessed directly");

$tpl = basename(__DIR__);


/*
The is parent file is used to process php actions and pass to the display as either SMARTY or php variables
If the output is SMARTY tpl file:					widgetTpl($tpl);
if the out put file is .php:						include 'tmpl/default.php';
If display file is php, output field values:		echo $content->domain_text;
If is smarty tpl, output field values:				{$content->domain_text}
*/


/* Mincart
----------------------------*/
if( $params->objecttype == 'minicart' )
{
	// get current cart session
	$cartsess = $_SESSION['cart'];
	$products = (isset($cartsess['products']) && is_array($cartsess['products']) ? $cartsess['products'] : []);
	$addons = (isset($cartsess['addons']) && is_array($cartsess['addons']) ? $cartsess['addons'] : []);
	$domains = (isset($cartsess['domains']) && is_array($cartsess['domains']) ? $cartsess['domains'] : []);
	$renewals = (isset($cartsess['renewals']) && is_array($cartsess['renewals']) ? $cartsess['renewals'] : []);


	$css='';

	if( !$products ) {
		if( $params->hideempty ) 
			$css = inline_Css('#widget-'.$widget->id.' {display: none;}');
		$mini_cart = (!empty($params->cartemptymsg) ? '<span class="emptycart"><i class="fas fa-shopping-cart"></i> '.$params->cartemptymsg.'</span>' : '');
	}

	// output if session is true
	if( $products )
	{
		$minicart =[]; $tot=[];
		foreach($products as $key => $product) 
		{
			$prod = products()->where('id', $product['pid'])->select('name', 'paytype')->get()[0];
			$minicart[] = '
			<li>
			<span class="mcartitem">'.$prod->name.'</span>
			<span class="mcartprice">'.itemPrice($product['pid'], $prod->paytype).'</span>
			</li>
			';

			$tot[] = itemPrice($product['pid'], $prod->paytype, '', '', '', true);
		}
		
		// set currency format
		setlocale(LC_MONETARY);
		
		$total='';
		if( $params->showtotal )
			$total = '
			<p class="totaldue">
			'.($params->totaltext ? '<span class="totaltext">'.text('ordertotalduetoday').':</span>' : '').'
			<span>'.currency()->prefix . money_format('%i', array_sum($tot)) . currency()->suffix.'</span>
			</p>
			';
			
		
		$pretext = (!empty($params->pretext) ? '<div class="pretext">'.cmseElements($params->pretext).'</div>' : '');
		$posttext = (!empty($params->posttext) ? '<div class="posttext">'.cmseElements($params->posttext).'</div>' : '');
		
		// full cart display
		if( $params->display == 1 )
		{
			$mini_cart = 
			$pretext.'
			
			<ul>'.implode('', $minicart).'</ul>
			'.$total.'
			<p><a class="btn btn-info btn-block" href="'.ROOT_URL.'cart.php?a=view">'.text('viewcart').'</a></p>
			
			'.$posttext;
		}
		
		// minimal display
		if( $params->display == 2 ) 
		{
			$mini_cart = '
			<div class="minimal">
			'.$total.'
			<p class="cartbtn">
				<a class="btn btn-info btn-sm" href="'.ROOT_URL.'cart.php?a=view">'.text('viewcart').'</a>
			</p>
			</div>
			';
		}
	}

	$output = '<div class="minicart">'.$mini_cart.'</div>' . $css;
}





/* Copyright Footer
----------------------------*/
if( $params->objecttype == 'footer' )
{
	$pretext = (!empty($params->pretext) ? '<div class="pretext">'.cmseElements($params->pretext).'</div>' : '');
	$posttext = (!empty($params->posttext) ? '<div class="posttext">'.cmseElements($params->posttext).'</div>' : '');
	
	$copyright = '
	<p>
	'.text('copyright').' &copy; '.$params->start_year.' - '.tplVars('date_year').' '.tplVars('companyname').' '.text('allrightsreserved').'
	</p>
	';
	
	$js = inline_Js('
		jQuery(function($) {
			
			$(window).scroll(function() {
				var height = $(window).scrollTop();
				if (height > 100) {
					$("#back2Top").fadeIn();
				} else {
					$("#back2Top").fadeOut();
				}
			});

			$("#back2Top").click(function(event) {
				event.preventDefault();
				$("html, body").animate({ scrollTop: 0 }, "slow");
				return false;
			});

		});
	');

	$totop = ($params->totop ? '<a id="back2Top" title="Scroll to top" href="#">&#10148;</a>'.$js : '');
	
	$output = $pretext . $copyright . $posttext . $totop;
}



/* Login Form
----------------------------*/
if( $params->objecttype == 'loginform' )
{
	$pretext = (!empty($params->pretext) ? '<div class="pretext">'.cmseElements($params->pretext).'</div>' : '');
	$posttext = (!empty($params->posttext) ? '<div class="posttext">'.cmseElements($params->posttext).'</div>' : '');
	$orient = ($params->orientation == 2 ? 'form-inline':'form-vertical');
	
	$login = '
	<form method="post" action="'.ROOT_URL.'dologin.php" class="'.$orient.'">
		<div>
			'.($params->showlabels == 1 ? '<label>'.text('loginemail').'</label>' : '').'
			<input class="form-control" type="text" name="username" placeholder="'.text('loginemail').'" />
		</div>
		
		<div>
			'.($params->showlabels == 1 ? '<label>'.text('loginpassword').'</label>' : '').'
			<input class="form-control" type="password" name="password" autocomplete="off" placeholder="'.text('loginpassword').'" />
		</div>
		<div>
			<input class="btn btn-info" type="submit" value="'.text('loginbutton').'" />
		</div>
	</form>
	';
	
	$output = $pretext . $login . $posttext;
}



/* Language Selector
-----------------------------*/
if( $params->objecttype == 'language' )
{
	$languages = \Lang::getLocales();
	
	$langselect ='';
	if( getSetting('AllowLanguageChange') == 'on' && count($languages) > 1 )
	{
		$langselect = '
		<a href="#" class="choose-language" data-toggle="popover" id="languageChooser">
		'.tplVars('activeLocale')['localisedName'].'
		<span class="caret"></span>
		</a>
		
		<div id="languageChooserContent" class="hidden">
		<ul>
		';
		
		foreach($languages as $language) {
			$langselect .= '
			<li>
				<a href="'.tplVars('currentpagelinkback').'language='.$language['language'].'">'.$language['localisedName'].'</a>
			</li>';
		}
		
		$langselect .= '</ul>
		</div>';
	}
	
	$output = $langselect;
}



/* Domain Search
-----------------------------*/
if( $params->objecttype == 'domainsearch' )
{
	$fieldhint = (!empty($params->search_hint) ? $params->search_hint : text(SEARCH_DOMAIN, 'Search for the perfect domain'));
	
	// get domain extensions
	$exts = getDbo('tbldomainpricing')->select('extension')->pluck('extension');

	$extoption =[];
	foreach($exts as $ext) {
		$extoption[] = '<option value="'.$ext.'">'.$ext.'</option>';
	}
	
	$domainsearch = '
		<div class="domain-search">
			<form class="form-inline" action="'.ROOT_URL.'domainchecker.php" method="post">
				<input type="hidden" name="direct" value="true" />
				<input type="text" name="domain" class="form-control" placeholder="'.$fieldhint.'" />
				<select name="ext" class="form-control">
				'.implode('', $extoption).'
				</select>
				<button type="submit" class="btn btn-primary"><i class="fas fa-search"></i></button>
			</form>
			<div class="clearall"></div>
		</div>
	';
	
	$output = $domainsearch;
}



/* Cookie
-----------------------------*/
if( $params->objecttype == 'cookie' )
{
}



/* Out Put Variable
------------------------------------*/
getSmarty()->assign('widgetpack', $output);

// load display file
widgetTpl($tpl);