<?php
/*
* Copyright (c) 2019 CMSEnergizer.com. All Rights Reserved
* License: GNU General Public License version 2 or later; see http://www.gnu.org/licenses/
* Author: Alex
*/

if( !defined("WHMCS") ) die("This file cannot be accessed directly");

$tpl = basename(__DIR__);


/*
* The is parent file is used to process php actions and pass to the display as either SMARTY or php variables
*
* Assign Smarty Variables for use in widget template
* getSmarty()->assign([
* 'myfield' => $my_php_var,
* 'myothervar' => $my_other_var
* ]);

* If the output is SMARTY tpl file:					widgetTpl($tpl);
* if the out put file is .php:						include 'tmpl/default.php';
* If display file is php, output field values:		echo $params->domain_text;
* If is smarty tpl, output field values:			{$params->domain_text}
*/

$css = inline_Css($params->customcss);

$modurl = 'index.php?component=posts&view=post';

$catid = (array)$params->postcats;

// itemized by ID
if( !empty($params->postitems) ) {
	$itemids = explode(',', $params->postitems);
	if( $params->sortmethod == 'rand' ) {
		$posts = posts()->whereIn('id', $itemids)->where('published', 1)->inRandomOrder()->get();
	}else{
		$posts = posts()->whereIn('id', $itemids)->where('published', 1)->get();
	}
}else
// from categories selected
if( !empty($params->postcats) )
{
	if( $params->sortmethod == 'rand' ) {
		$posts = posts()
		->whereIn('catid', $catid)
		->where('published', 1)
		->inRandomOrder()
		->limit($params->itemcount)
		->get();
	}else{
		$posts = posts()
		->whereIn('catid', $catid)
		->where('published', 1)
		->orderBy($params->sortmethod, $params->sortdirection)
		->limit($params->itemcount)
		->get();
	}
}

// post items in category view
$itemclass = $itemwidth= $equalheight= $eqtitle= $eqimg='';
if( $params->itemsperrow > 1 )
{
	$itemclass = ' boxsize break grid';
	$equalheight = ' equalheight';
	$itemwidth = ' style="width: '.round(100/(int)$params->itemsperrow).'%;"';
	$eqtitle = ' data-mh="eqtitle"';
	if( $params->imgmask =='' )
		$eqimg = ' data-mh="eqimg"';
}

$imgmask='';
if( $params->imgmask !='' ) {
	$imgmask = ' style="height: '.$params->imgmask.'px;"';
}


$outlay=[];
foreach($posts as $post)
{
	$cat = categories()->select('id', 'alias')->where([['id', $post->catid], ['type', 'post']])->get()[0];
	$layout = cmseElements($params->layout);
	$rawurl = $modurl.'&category='.$post->catid.'-'.$cat->alias.'&post='.$post->id.'-'.$post->alias.'&menuid='.$menuid;
	$postlink = ROOT_URL.router($rawurl);

	$active = (currenturl() == $postlink ? ' active' : '');

	$link= $linkend='';
	if( $params->addlink ) {
		$link = '<a href="'.$postlink.'">';
		$linkend = '</a>';
	}

	$title = '
		<h3 class="post-title"'.$eqtitle.'>
			'.$link.'<span class="before"></span><span>'.$post->title.'</span><span class="after"></span>'.$linkend.'
		</h3>';

	$text = (!empty($params->textlimit) ? truncText(html_entity_decode($post->post_content), $params->textlimit) : html_entity_decode($post->post_content));
	$text = '<div>'.cmseElements($text).'</div>';

	// default to secure hosted image if none of the below values are true
	$img = 'https://i.ibb.co/qRvM4MP/default.png';
	if( !empty($post->post_image) && file_exists(IMGPATH.'/'.$post->post_image) ) {
		$img = IMAGES.$post->post_image;
	}else
	if( !empty($params->defaultimg) && file_exists(IMGPATH.'/'.$params->defaultimg) ) {
		$img = IMAGES.$params->defaultimg;
	}else
	if( file_exists(IMGPATH.'/assets/default.png') ) {
		$img = IMAGES.'assets/default.png';
	}
	$image = '
	<div class="post-image">
		<span class="imgmask"'.$imgmask.$eqimg.'>
			'.$link.'<img src="'.$img.'" />'.$linkend.'
		</span>
	</div>
	';

	$date = '<span class="post-date">'.dateFormat($post->created_at).'</span>';

	$author='';
	$hits='';
	$votes='';

	$objectholders = [
	'[title]',
	'[image]',
	'[text]',
	'[date]',
	'[author]',
	'[hits]',
	'[votes]'
	];

	$objects = [
	$title,
	$image,
	$text,
	$date,
	$author,
	$hits,
	$votes
	];


	$outlay[] = '
	<div class="post-item'.$itemclass.$active.'"'.$itemwidth.'>
	<div class="inner'.$equalheight.'">'.str_replace($objectholders, $objects, $layout).'<div class="clearall"></div></div>
	</div>
	';
}

$output = implode('', $outlay);

// Slideshow options
$config = [
'autostart' => $params->slidestart, 
'height' => $params->slideheight, 
'delay' => $params->slidedelay, 
'slidespeed' => $params->slidespeed
];

if( $params->slideshow )
	$output = cmseSlides($output, 'widget'.$widget->id, $config);

getSmarty()->assign('latest_post_layout', $output . $css);

/* load display file after php processes above
-------------------------------------------------*/
widgetTpl($tpl);