<?php
/*
* Copyright (c) 2019 CMSEnergizer.com. All Rights Reserved
* License: GNU General Public License version 2 or later; see http://www.gnu.org/licenses/
* Author: Alex
*/

if( !defined("WHMCS") ) die("This file cannot be accessed directly");

$tpl = basename(__DIR__);

/*
The is parent file is used to process php actions and pass to the display as either SMARTY or php variables
If the output is SMARTY tpl file:					widgetTpl($tpl);
if the out put file is .php:						include 'tmpl/default.php';
If display file is php, output field values:		echo $content->domain_text;
If is smarty tpl, output field values:				{$content->domain_text}
*/


$bgimg= $innerwrap= $wrapend='';
if( !empty($params->bgimg) ) {
	$bgimg = ' style="background: url('.IMAGES.$params->bgimg.') top no-repeat; background-size: cover;"';
	$innerwrap = '<div class="inner-wrap">';
	$wrapend = '</div>';
}

if( !empty($params->customcss) ) {

	//getSmarty()->append('inlinecss', ['widgetcss' => $params->customcss], true);
	call_user_func('cssout', $params->customcss);
}


$data = '<div'.$bgimg.'>'.$innerwrap.cmseElements(html_entity_decode($params->custom_html)).$wrapend.'</div>';
getSmarty()->assign('custom_html', $data);

// load display file
widgetTpl($tpl);