<?php
/*
* Copyright (c) 2019 CMSEnergizer.com. All Rights Reserved
* License: GNU General Public License version 2 or later; see http://www.gnu.org/licenses/
* Author: Alex
*/

if( !defined("WHMCS") ) die("This file cannot be accessed directly");

$data = cmseElements(html_entity_decode($params->custom_html));


if( !empty($params->bgimg) ) {
	getSmarty()->append('widgetcss', '#widget-'.$widget->id.' {background: #ffcc00;}');
}

if( !empty($params->customcss) ) {

	//getSmarty()->append('inlinecss', ['widgetcss' => $params->customcss], true);
	call_user_func('cssout', $params->customcss);
}



echo $data;