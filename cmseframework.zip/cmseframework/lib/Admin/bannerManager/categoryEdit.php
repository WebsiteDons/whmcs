<?php
/*
* Copyright (c) 2019 Emuzement Net Inc. All Rights Reserved
* License: EULA
* Author: Alex/Kumar/Manti/Lisa
*/

if( !defined("WHMCS") ) die("This file cannot be accessed directly");

use \WHMCS\Session;

$action		= $modlink.'&view=bannerManager&task=';
$firstsave	= $action.'edit&type=category&id=';
$saveedit	= $action.'edit&type=category&id='.getRequest('id').'&itemsaved=1';
$savenew	= $action.'edit&type=category';
$saveclose	= $action.'list&type=categories';

TIMEZONE;
$now 		= date('Y-m-d H:i:s');

$edit = requestKey('id');
$cat = categories()->where([['id', getRequest('id')],['type', 'banner']])->get()[0];

if( $edit )
{
	$title = (!empty($cat->title) ? $cat->title : '');
	$state = (!empty($cat->state) ? $cat->state : '');
	$access = (!empty($cat->access) ? json_decode($cat->access) : '');
}

if( !$edit ) {
	$created = $now;
	$update = '';
	$updateauthor = '';
}else{
	$created = $cat->created_at;
	$update = $now;
	$updateauthor = Session::get('adminid');
}

if( !is_null(getPost('saveitem', false)) || !is_null(getPost('savenew', false)) || !is_null(getPost('saveclose', false)) )
{
	$viewaccess = [
	'access'		=> getPost('access', false), 
	'cg'			=> getPost('cg', false), 
	'no_access_msg' => getPost('no_access_msg')
	];
	
	$fields = [
		'title'		=> getPost('title'),
		'alias' 	=> makeAlias('title'),
		'type'		=> 'banner',
		'state'		=> getPost('state', false),
		'access'	=> json_encode($viewaccess),
		'created_at'	=> $created,
		'updated_at'	=> $update,
		'author'	=> Session::get('adminid'),
		'update_author'	=> $updateauthor
	];
	
	// insert data
	if( !$edit )
	{
		// new banner
		try{
			$cid = categories()->insertGetId($fields);
		}
		catch (\Exception $e) {
			cmseNotice($e->getMessage());
		}
		
		if( !is_null(getPost('saveitem', false)) && !empty($cid) ) {
			redirect($firstsave.$cid.'&itemsaved=1');
		}else
		if( !is_null(getPost('savenew', false)) ) {
			redirect($savenew);
		}else
		if( !is_null(getPost('saveclose', false)) ) {
			redirect($saveclose);
		}
	}else{
		// delete item if set to delete
		if( !is_null(getPost('stateval', false)) && getPost('stateval', false) == 3 ) {
			try{
				categories()->where('id', getRequest('id'))->delete();
			}
			catch (\Exception $e) {
				cmseNotice($e->getMessage());
			}
			redirect($saveclose);
		}else{
			try{
				categories()->where('id', getRequest('id'))->update($fields);
			}catch (\Exception $e) {
				cmseNotice($e->getMessage());
			}
			
			if( !is_null(getPost('saveitem', false)) ) {
				redirect($saveedit);
			}else
			if( !is_null(getPost('savenew', false)) ) {
				redirect($savenew);
			}else
			if( !is_null(getPost('saveclose', false)) ) {
				redirect($saveclose);
			}
		}
	}
}

?>

<fieldset>
<div class="flexwrap">
<?php 
field('text', 'title', $title, '', 'Category Title', ['required' => 'required']);
field('select', 'state', $state, PUBLISHSTATE, 'Status');
field('select', 'access', $access, ACCESS, 'Viewer Access');
field('select', 'cg', $cg, ['admin' => 'Admin'], 'Client Groups');
field('textarea', 'no_access_msg', $msg, '', 'Message');
 ?>
 </div>
</fieldset>