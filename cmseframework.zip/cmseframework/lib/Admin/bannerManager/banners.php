<?php
/*
* Copyright (c) 2019 Emuzement Net Inc. All Rights Reserved
* License: EULA
* Author: Alex/Kumar/Manti/Lisa
*/

if( !defined("WHMCS") ) die("This file cannot be accessed directly");

$modlink = $modlink.'&view=bannerManager&task=edit&type=';

$banners = banners()->get();

// delete items by checkbox
if( !is_null(getPost('item_delete', false)) )
{
	$dels = explode(',', getPost('items_id', false));
	try{
		banners()->whereIn('id',$dels)->delete();
	// if error
	} catch (\Exception $e) {
		cmseNotice($e->getMessage());
	}
	redirect($returnview);
}

// disable post item
if( !is_null(getPost('item_disable', false)) )
{
	$dels = explode(',', getPost('items_id', false));
	try{
		banners()->whereIn('id',$dels)->update(['state' => 2]);
	// if error
	} catch (\Exception $e) {
		cmseNotice($e->getMessage());
	}
	redirect($returnview);
}

// enable post item
if( !is_null(getPost('item_enable', false)) )
{
	$dels = explode(',', getPost('items_id', false));
	try{
		banners()->whereIn('id',$dels)->update(['state' => 1]);
	// if error
	} catch (\Exception $e) {
		cmseNotice($e->getMessage());
	}
	redirect($returnview);
}

?>

<table class="chart">
	<tr>
		<th>Title</th>
		<th>Type</th>
		<th>Category</th>
		<th>Impressions</th>
		<th>Clicks</th>
		<th>Created</th>
		<th>Updated</th>
		<th>State <input type="checkbox" value="" name="checkall" /></th>
	</tr>

<?php foreach($banners as $banner) { ?>
	<tr class="<?php echo ($banner->state == 2 ? 'disabled' : 'enabled'); ?>">
		<td>
			<a href="<?php echo $modlink; ?>banner&id=<?php echo $banner->id; ?>">
			<?php echo $banner->title; ?>
			</a>
		</td>
		
		<td><?php echo $banner->type; ?></td>
		<td>
			<a href="<?php echo $modlink; ?>category&id=<?php echo $banner->catid; ?>">
			<?php echo catName($banner->catid); ?>
			</a>
		</td>
		<td><?php echo $banner->impressions; ?></td>
		<td><?php echo $banner->clicks; ?></td>
		<td>
			<?php echo dateFormat($banner->created_at, 'short'); ?>
			<small class="info">
			<a href="configadmins.php?action=manage&id=<?php echo $banner->author; ?>">
			<?php echo adminName($banner->author); ?>
			</a>
			</small>
		</td>
		<td>
			<?php if( $banner->updated_at != '0000-00-00 00:00:00' ) { ?>
			<?php echo dateFormat($banner->updated_at, 'm-d-Y'); ?>
			<small class="info">
			<a href="configadmins.php?action=manage&id=<?php echo $banner->update_author; ?>">
			<?php echo adminName($banner->update_author); ?></a>
			</small>
			<?php } ?>
		</td>
		<td>
			<span>
			<input type="checkbox" name="item_check" value="<?php echo $banner->id; ?>" id="delete_item" />
			</span> <?php echo ($banner->state == 1 ? '<i class="fas fa-check-circle"></i>' : '<i class="fas fa-minus-circle"></i>'); ?>
		</td>
	</tr>
<?php } ?>
</table>