<?php
/*
* Copyright (c) 2019 Emuzement Net Inc. All Rights Reserved
* License: EULA
* Author: Alex/Kumar/Manti/Lisa
*/

if( !defined("WHMCS") ) die("This file cannot be accessed directly");

use \WHMCS\Session;

$action		= $modlink.'&view=bannerManager&task=';
$firstsave	= $action.'edit&type=banner&id=';
$saveedit	= $action.'edit&type=banner&id='.getRequest('id').'&itemsaved=1';
$savenew	= $action.'edit&type=banner';
$saveclose	= $action.'list&type=banners';

TIMEZONE;
$now 		= date('Y-m-d H:i:s');

// create images folder if not exist
if( !file_exists(IMGPATH) ) {
	if( !mkdir(IMGPATH, 0755, true) )
		die('Failed to create folders');
}


// Get categories
$cats = categories()->where('type', 'banner')->get();
$catval=[];
foreach($cats as $cat) {
	$catval[$cat->id] = $cat->title;
}

// item status selection array
$state_sel = PUBLISHSTATE;

$edit = requestKey('id');
$banner = banners()->where('id', getRequest('id'))->get()[0];

if( $edit )
{
	$title = (!empty($banner->title) ? $banner->title : '');
	$bannertype = (!empty($banner->type) ? $banner->type : '');
	$adcontent = (!empty($banner->adcontent) ? $banner->adcontent : '');
	$state = (!empty($banner->state) ? $banner->state : '');
	$catid = (!empty($banner->catid) ? $banner->catid : '');
	$attribs = json_decode($banner->attribs);
	$bannertext = (!empty($attribs->bannertext) ? $attribs->bannertext : '');
	$setbg = $attribs->setbg;
	$bannerheight = (!empty($attribs->bannerheight) ? $attribs->bannerheight : '');
	$autoplay = $attribs->autoplay;
	$endplay = $attribs->endplay;
}

if( !$edit ) {
	$created = $now;
	$update = '';
	$updateauthor ='';
}else{
	$created = $banner->created_at;
	$update = $now;
	$updateauthor = Session::get('adminid');
}

if( !is_null(getPost('saveitem', false)) || !is_null(getPost('savenew', false)) || !is_null(getPost('saveclose', false)) )
{
	if( !is_null(getPost('video')) && getPost('bannertype', false) == 'video' ) {
		$content = getPost('video');
	}else
	if( !is_null(getPost('html')) && getPost('bannertype', false) == 'html' ) {
		$content = getPost('html');
	}else{
		$content = getPost('image');
	}
	
	$collection = [
	'link' => getPost('link'), 
	'window' => getPost('window', false),
	'clicktrack' => getPost('clicktrack', false),
	'impressions' => getPost('impressions', false),
	'bannertext' => getPost('bannertext', false),
	'setbg' => getPost('setbg', false),
	'bannerheight' => getPost('bannerheight', false),
	'autoplay' => getPost('autoplay', false),
	'endplay' => getPost('endplay', false),
	'linktext' => getPost('linktext')
	];
	
	$fields = [
		'title'		=> getPost('banner_title'),
		'type'		=> getPost('bannertype'),
		'adcontent'	=> $content,
		'catid'		=> getPost('category', false),
		'state'		=> getPost('state', false),
		'attribs'	=> json_encode($collection),
		'author'	=> Session::get('adminid'),
		'update_author'	=> $updateauthor,
		'created_at'	=> $created,
		'updated_at'	=> $update,
		'access'	=> getPost('access', false),
	];

	// insert data
	if( !$edit )
	{
		// new banner
		try {
			$bid = banners()->insertGetId($fields);
		// if error
		} catch (\Exception $e) {
			cmseNotice($e->getMessage());
		}
		
		if( !is_null(getPost('saveitem', false)) && !empty($bid) ) {
			redirect($firstsave.$bid.'&itemsaved=1');
		}else
		if( !is_null(getPost('savenew', false)) ) {
			redirect($savenew);
		}else
		if( !is_null(getPost('saveclose', false)) ) {
			redirect($saveclose);
		}
	}else{
		// delete item if set to delete
		if( !is_null(getPost('stateval', false)) && getPost('stateval', false) == 3 ) {
			try {
				banners()->where('id', getRequest('id'))->delete();
				// if error
			} catch (\Exception $e) {
				cmseNotice($e->getMessage());
			}
			redirect($saveclose);
		}else{
			try{
				banners()->where('id', getRequest('id'))->update($fields);
			// if error
			} catch (\Exception $e) {
				cmseNotice($e->getMessage());
			}
			if( !is_null(getPost('saveitem', false)) ) {
				redirect($saveedit);
			}else
			if( !is_null(getPost('savenew', false)) ) {
				redirect($savenew);
			}else
			if( !is_null(getPost('saveclose', false)) ) {
				redirect($saveclose);
			}
		}
	}
}

?>

<fieldset>
<div class="flexwrap">
	<?php
	// field($type, $name, $value='', $options=[], $label='', $attribs=[], $info='')
	// title
	field('text', 'banner_title', $title, '', 'Title',
	['placeholder' => POSTS_FIELD_TITLE_HINT, 'required' => 'required']
	);
	field('select', 'category', $catid, $catval, 'Category');
	field('select', 'state', $state, PUBLISHSTATE, 'Status');
	field('select', 'bannertype', $bannertype, ['image' => 'Image', 'video' => 'Video', 'html' => 'HTML'], 'Type');
	field('select', 'access', $access, ACCESS, 'Viewer Access');
	?>
	</div>
</fieldset>
	
<fieldset id="imagetype">
<div class="flexwrap">
	<?php
	field('image', 'image', ($bannertype == 'image' ? $adcontent : ''), '', 'Image Insert', ['class' => 'inline-fields']);
	echo ($bannertype == 'image' ? '<div style="width: 200px; overflow: hidden;"><img src="'.IMAGES.$adcontent.'" /></div>' : '');
	field('select', 'setbg', $setbg, ['' => '-- Use Default --', 'cover' => 'Cover', 'contain' => 'Contain'], 'Set Image As Background');
	field('number', 'bannerheight', $bannerheight, '', 'Height');
	?>
</div>
</fieldset>
	
<fieldset id="videotype">
<div class="flexwrap">
	<?php
	field('text', 'video', ($bannertype == 'video' ? $adcontent : ''), '', 'Video URL');
	field('select', 'autoplay', $autoplay, [0 => 'No', 1 => 'Yes - Muted', 2 => 'Yes - Unmuted'], 'Autoplay Video');
	field('select', 'endplay', $endplay, [0 => 'Stop', 1 => 'Loop', 2 => 'Hide'], 'Video End');
	?>
</div>
</fieldset>
	
<fieldset id="htmltype">
	<?php
	field('textarea', 'html', ($bannertype == 'html' ? $adcontent : ''), '', 'HTML', ['class' => 'width-500']);
	?>
</fieldset>
	
<fieldset class="flexwrap">
	<?php
	
	field('text', 'link', $attribs->link, '', 'Link');
	field('text', 'linktext', $attribs->linktext, '', 'Link Label');
	field('select', 'window', $attribs->window, ['_parent' => 'Same Window', '_blank' => 'New Window', 'popup' => 'PopUp'], 'Window Target');
	field('select', 'clicktrack', $attribs->clicktrack, ['1' => 'Yes', '0' => 'No'], 'Track Clicks');
	field('select', 'impressions', $attribs->impressions, ['1' => 'Yes', '0' => 'No'], 'Track Impressions');
	?>
</fieldset>

<fieldset>
<?php field('textarea', 'bannertext', $bannertext, '', 'Banner Text', ['id' => 'wysiwyg']); ?>
</fieldset>