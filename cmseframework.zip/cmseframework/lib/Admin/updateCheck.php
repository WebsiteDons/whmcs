<?php
/*
* Copyright (c) 2019 Emuzement Net Inc. All Rights Reserved
* License: EULA
* Author: Alex/Kumar/Manti/Lisa
*/

if( !defined("WHMCS") ) die("This file cannot be accessed directly");

if( ini_get('allow_url_fopen') ) {
	$updatexml = simplexml_load_file('https://websitedons.com/updateNotice/whmcs-mod-cmse-fof.xml');
}else{
	$updatexml = simplexml_load_file('compress.zlib://https://websitedons.com/updateNotice/whmcs-mod-cmse-fof.xml');
}

$log=[];
foreach($updatexml->changelog->li as $change) {
	$log[] = '<li>'.$change.'</li>';
}

$downloadurl = (string)$updatexml->downloadurl;

$version = (string)$updatexml->version;

if( version_compare(getCmseVersion(), $version, '<') ) 
{
	echo '
	<div class="alert alert-info clearall modupdate">
		<div class="table-cell">
		<h5>An update is available</h5>
		Your installed version is '.getCmseVersion().'.<br />
		The latest stable release is '.$version.'.<br /><br />
		<a class="btn btn-primary" href="'.$downloadurl.'" target="_blank">Get the new version '.$version.' </a><br />
		Use this intaller to update the extension <br />once you have downloaded the file.
		</div>
		<div class="table-cell padleft-20">
			<h5>Change Log - '.(string)$updatexml->date.'</h5>
			<ul>'.implode('', $log).'</ul>
		</div>
	</div>
	';
}else{
	echo '<p class="alert alert-success">You have the latest version '.$version.'</p>';
}