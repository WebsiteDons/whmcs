<?php
/*
* Copyright (c) 2019 Emuzement Net Inc. All Rights Reserved
* License: EULA
* Author: Alex/Kumar/Manti/Lisa
*/

if( !defined("WHMCS") ) die("This file cannot be accessed directly");

use \WHMCS\Session;

$n = "\n";

$posts = posts()->select('id', 'title', 'created_at', 'updated_at', 'catid', 'author', 'update_author')->orderBy('created_at', 'desc')->limit(5)->get();
?>

<div class="masonry">
	<div class="dasboard">
		<table class="chart table-striped">
			<caption>Latest Posts</caption>
			<tr>
				<th>Title</th>
				<th>Date</th>
				<th>Updated</th>
				<th>Category</th>
			</tr>

			<?php foreach($posts as $post) {
			$catname = categories()->where('id', $post->catid)->value('title');
			?>
			<tr>
				<td>
					<a href="<?php echo $modlink; ?>&view=postManager&task=edit&type=post&postid=<?php echo $post->id; ?>" <?php echo cmseToolTip('edit post', ''); ?>>
					<?php echo $post->title; ?>
					</a>
				</td>
				<td>
					<?php echo dateFormat($post->created_at, 'short'); ?>
					<a href="configadmins.php?action=manage&id=<?php echo $post->update_author; ?>"<?php echo cmseToolTip('edit author', ''); ?>>
					<small class="info"><?php echo adminName($post->author); ?></small></a>
				</td>
				<td>
					<?php if( $post->updated_at != '0000-00-00 00:00:00' ) { ?>
					<?php echo dateFormat($post->updated_at, 'short'); ?>
					<a href="configadmins.php?action=manage&id=<?php echo $post->update_author; ?>">
					<small class="info"><?php echo adminName($post->update_author); ?></small></a>
					<?php } ?>
				</td>
				<td>
					<a href="<?php echo $modlink; ?>&view=postManager&task=edit&type=category&catid=<?php echo $post->catid; ?>">
					<?php echo $catname; ?>
					</a>
				</td>
			</tr>
			<?php } ?>
		</table>

		<!-- Banners -->
		<?php $banners = banners()->select('id', 'title', 'created_at', 'updated_at', 'catid', 'author', 'update_author')->orderBy('created_at', 'desc')->limit(5)->get(); ?>
		<table class="chart table-striped">
			<caption>Latest Banners</caption>
			<tr>
				<th>Title</th>
				<th>Date</th>
				<th>Updated</th>
				<th>Category</th>
			</tr>

			<?php foreach($banners as $banner) {
			$catname = categories()->where([['id', $banner->catid],['type', 'banner']])->value('title');
			?>
			<tr>
				<td>
					<a href="<?php echo $modlink; ?>&view=bannerManager&task=edit&type=banner&id=<?php echo $banner->id; ?>" <?php echo cmseToolTip('edit banner', ''); ?>>
					<?php echo $banner->title; ?>
					</a>
				</td>
				<td>
					<?php echo dateFormat($banner->created_at, 'short'); ?>
					<a href="configadmins.php?action=manage&id=<?php echo $banner->update_author; ?>" <?php echo cmseToolTip('edit author', ''); ?>>
					<small class="info"><?php echo adminName($banner->author); ?></small></a>
				</td>
				<td>
					<?php if( $banner->updated_at != '0000-00-00 00:00:00' ) { ?>
					<?php echo dateFormat($banner->updated_at, 'short'); ?>
					<a href="configadmins.php?action=manage&id=<?php echo $banner->update_author; ?>">
					<small class="info"><?php echo adminName($banner->update_author); ?></small></a>
					<?php } ?>
				</td>
				<td>
					<a href="<?php echo $modlink; ?>&view=bannerManager&task=edit&type=category&catid=<?php echo $banner->catid; ?>">
					<?php echo $catname; ?>
					</a>
				</td>
			</tr>
			<?php } ?>
		</table>



		<!-- Categories -->
		<?php $categories = categories()->select('id', 'title', 'created_at', 'updated_at', 'type', 'author', 'update_author')->orderBy('created_at', 'desc')->limit(5)->get();
		?>

		<table class="chart table-striped">
			<caption>Latest Categories</caption>
			<tr>
				<th>Title</th>
				<th>Date</th>
				<th>Updated</th>
				<th>Type</th>
			</tr>

			<?php foreach($categories as $category) {

			?>
			<tr>
				<td>
					<?php 
					if( $category->type == 'post' ) {
						$link = '&view=postManager&task=edit&type=post&postid='.$post->id;
					}else{
						$link = '&view=bannerManager&task=edit&type=category&id='.$category->id;
					} ?>
					<a href="<?php echo $modlink.$link; ?>" <?php echo cmseToolTip('edit category', ''); ?>>
					<?php echo $category->title; ?>
					</a>
				</td>
				<td>
					<?php echo dateFormat($category->created_at, 'short'); ?>
					<a href="configadmins.php?action=manage&id=<?php echo $category->update_author; ?>" <?php echo cmseToolTip('edit author', ''); ?>>
					<small class="info"><?php echo adminName($category->author); ?></small></a>
				</td>
				<td>
					<?php if( $category->updated_at != '0000-00-00 00:00:00' ) { ?>
					<?php echo dateFormat($category->updated_at, 'short'); ?>
					<a href="configadmins.php?action=manage&id=<?php echo $category->update_author; ?>">
					<small class="info"><?php echo adminName($category->update_author); ?></small></a>
					<?php } ?>
				</td>
				<td>
					<?php echo $category->type; ?>
				</td>
			</tr>
			<?php } ?>
		</table>




		<!-- Templates -->
		<?php $templates = templates()->select('id', 'name', 'parent_tpl')->where('configs', '<>', '')->limit(5)->get(); ?>
		<table class="chart table-striped">
			<caption>Configurable Templates</caption>
			<tr>
				<th>Name</th>
				<th>Parent</th>
				<th>Assigned</th>
			</tr>

			<?php foreach($templates as $template) {
			?>
			<tr>
				<td>
				<a href="<?php echo $modlink; ?>&view=templateManager&task=list&type=templates" <?php echo cmseToolTip('edit template', ''); ?>>
				<?php echo $template->name; ?>
				</a>
				</td>
				<td><?php echo (!empty($template->parent_tpl) ? $template->parent_tpl : 'is parent'); ?></td>
				<td><?php echo (in_array($template->id, tplassign()->pluck('tmpl_id')) ? 'yes' : 'no'); ?></td>
			</tr>
			<?php } ?>
		</table>



		<!-- System Info -->
		<?php
		$system = getDbo('mod_cmse_sys')->orderBy('updated_at', 'desc')->limit(10)->get();
		$purge='';
		if( fullAdmin(Session::get('adminid')) && !empty($system) ) {
			$purge = '<a class="floatright" name="purge_cmse_sys" href="'.$modlink.'&purge=1"><i class="fas fa-trash-alt"></i> Purge</a>';

			if( !is_null('purge_cmse_sys') && requestKey('purge') ) {
				getDbo('mod_cmse_sys')->truncate();
				redirect($modlink);
			}
		}
		?>
		<table class="chart table-striped">
			<caption>CMSE Framework System Changes<?php echo $purge; ?></caption>
			<tr>
				<th>Type</th>
				<th>Updated</th>
				<th>Admin</th>
			</tr>

			<?php foreach($system as $sys) {

			if( $sys->type == 'Global Configuration' )
				$val = '<a href="'.$modlink.'&view=configs">'.$sys->type.'</a>';
			if( $sys->type == 'Language' )
				$val = '<a href="'.$modlink.'&view=languageManager">'.$sys->type.'</a>';
			?>
			<tr>
				<td><?php echo $val; ?></td>
				<td><?php echo dateFormat($sys->updated_at, 'short'); ?></td>
				<td>
					<a href="configadmins.php?action=manage&id=<?php echo $sys->admin; ?>">
					<?php echo adminName($sys->admin); ?>
					</a>
				</td>
			</tr>
			<?php } ?>
		</table>

	</div>
</div>