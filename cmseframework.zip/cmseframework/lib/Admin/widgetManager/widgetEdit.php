<?php
/*
* Copyright (c) 2019 Emuzement Net Inc. All Rights Reserved
* License: EULA
* Author: Alex/Kumar/Manti/Lisa
*/

if( !defined("WHMCS") ) die("This file cannot be accessed directly");

use \WHMCS\Session;


$thisWidget = getRequest('widgettype');
$action		= $modlink.'&view=widgetManager&task=';
$firstsave	= $action.'edit&type=widget&widgettype='.$thisWidget.'&id=';
$saveedit	= $action.'edit&type=widget&widgettype='.$thisWidget.'&id='.getRequest('id').'&itemsaved=1';
$savenew	= $action.'edit&type=widget&widgettype='.$thisWidget;
$saveclose	= $action.'list&type=widgets';


/* Widget Data
-----------------------------------------------*/
$path = LIB_PATH.'/widgets/'.$thisWidget;
$filename = $path.'/'.$thisWidget;

// get .ini file and parse as constants
iniParse($path.'/language', $thisWidget);

// get widget data xml
$xml = simplexml_load_file($filename.'.xml');

// widget description field
$description='';
if( !empty($xml->description) ) {
	$description = (defined($xml->description) ? constant($xml->description) : $xml->description);
	$description = '<div class="alert alert-info">'.$description.'</div>';
}



/* Processes
---------------------------------------*/
$edit = requestKey('id');

if( $edit ) {
	$widg = widgets()->where('id', getRequest('id'))->get()[0];

	$attribs = json_decode($widg->attribs);
	$params = json_decode($widg->params);
}

// Save post to database
if( !is_null(getPost('saveitem', false)) || !is_null(getPost('savenew', false)) || !is_null(getPost('saveclose', false)) )
{
	if( !$edit ) {
		$created = sqlDate();
		$updated = '';
		$author = Session::get('adminid');
		$updateauthor = '';
	}else{
		$created = $widg->created_at;
		$updated = sqlDate();
		$author = $widg->author;
		$updateauthor = Session::get('adminid');
	}
	
	$collection = [
	'title'				=> getPost('title'),
	'show_widget_title'	=> getPost('show_widget_title', false),
	'widgetclass'		=> getPost('widgetclass', false),
	'note'				=> getPost('note')
	];

	// get each custom widget field names to insert into database
	$paramscollect = formFields($filename, '', getRequest('id'), true);

	$fields = [
		'type' 		=> getPost('widgettype', false),
		'state'		=> getPost('state', false),
		'params'	=> json_encode($paramscollect),
		'sortorder' => getPost('sortorder', false),
		'position'	=> getPost('position', false),
		'menuassign'=> json_encode([
			'assigned' => getPost('assigned', false), 
			'exclude' => getPost('exclude', false),
			'catview' => getPost('catview', false),
			'group' => getPost('group', false)
			]),
		'access'	=> json_encode(['access' => getPost('access', false), 'cg' => getPost('cg', false)]),
		'attribs'	=> json_encode($collection),
		'created_at' => $created,
		'updated_at' => $updated,
		'author'	=> $author,
		'update_author' => $updateauthor
	];

	if( !$edit )
	{
		// new post
		try{
			$wid = widgets()->insertGetId($fields);
		} catch (\Exception $e) {
			cmseNotice($e->getMessage());
		}
		
		if( !is_null(getPost('saveitem', false)) && !empty($wid) ) {
			redirect($firstsave.$wid.'&itemsaved=1');
		}else
		if( !is_null(getPost('savenew', false)) ) {
			redirect($savenew);
		}else
		if( !is_null(getPost('saveclose', false)) ) {
			redirect($saveclose);
		}
	}else{
		// delete item if set to delete
		if( !is_null(getPost('state', false)) && getPost('state', false) == 3 ) {
			try{
				widgets()->where('id', getRequest('id'))->delete();
			} catch (\Exception $e) {
				cmseNotice($e->getMessage());
			}
			redirect($saveclose);
		}else{
			// update post
			try{
				widgets()->where('id', getRequest('id'))->update($fields);
			} catch (\Exception $e) {
				cmseNotice($e->getMessage());
			}

			if( !is_null(getPost('saveitem', false)) ) {
				redirect($saveedit);
			}else
			if( !is_null(getPost('savenew', false)) ) {
				redirect($savenew);
			}else
			if( !is_null(getPost('saveclose', false)) ) {
				redirect($saveclose);
			}
		}

	}
}

// get menu items for widget assignment
$menuitems		= menus()
					->select('id', 'title')
					->where('published', 1)
					->whereIn('type', [1,2,3,4,5,6,7])
					->orderBy('menuorder', 'asc')
					->get();
$categories		= categories()->select('id', 'title')->where([['alias', '<>', 'uncategorized'],['type', 'post']])->get();
$productgroups	= groups()->where('hidden', 0)->pluck('name', 'id');

$assign			= json_decode($widg->menuassign);
$menuselected	= array_values((array)$assign->assigned);
$groupselected	= array_values((array)$assign->group);
$excludes		= array_values((array)$assign->exclude);


// get template values from xml included in template folder

if( getSetting('Template') == 'sixflix' ) {
	$tmpldata	= simplexml_load_file(CMSETPL.'/template.xml') or die('Error: Cannot create object');
}else
if( file_exists(SITETPL_PATH.'/template.xml') ) {
	$tmpldata	= simplexml_load_file(SITETPL_PATH.'/template.xml') or die('Error: Cannot create object');
}



$positions	= $tmpldata->positions->position;

// get all widget ordering to set this sorting
$widgets	= widgets()
			->select('id', 'attribs', 'sortorder')
			->where('position', $widg->position)
			->orderBy('sortorder', 'asc')
			->get();
			

?>

<div class="widget-edit">
	<input type="hidden" name="widgettype" value="<?php echo $thisWidget; ?>" />

	<div class="boxsize width_70 break">
		<div class="clearall marginbottom-20">
			<div class="inlineblock width-400">
			<input type="text" name="title" value="<?php echo $attribs->title; ?>" placeholder="*Title" required="required" />
			</div>
			<div class="inlineblock check-btn">
			<label>
				<span>
				<input type="checkbox" name="show_widget_title" value="" <?php echo (isset($attribs->show_widget_title) ? 'checked' : ''); ?> />
				</span>
				<span>Disable Title</span>
			</label>
			</div>
		</div>

<!-- LOAD WIDGET FILE -->

		<?php 
		echo $description;
		formFields($filename, 'widget', getRequest('id')); 
		?>

<!-- WIDGET FILE END -->

	</div>


	<!-- Right Column -->
	<div class="boxsize width_30 break padleft-20 sidefields">
		
		<fieldset>
			<h5><span>Viewer Access</span></h5>
			<div class="inner">
				<select name="access" class="form-control">
				<?php 
				$access = json_decode($widg->access);
				foreach(ACCESS as $key => $val) { ?>
				<option value="<?php echo $key; ?>" <?php echo ($access->access == $key ? 'selected' : ''); ?>><?php echo $val; ?></option>
				<?php } ?>
				</select>
		
				<div id="clientgroups" style="display: none;">
				<?php 
					$cg = clientgroups()->select('id', 'groupname')->get(); 
					foreach($cg as $g) { ?>
					<label class="btn btn-sm btn-default">
						<span class="check">
						<input type="checkbox" name="cg[<?php echo $g->id; ?>]" value="<?php echo $g->id; ?>" <?php echo (in_array($g->id, (array)$access->cg) ? 'checked' : ''); ?> />
						</span>
						<span><?php echo $g->groupname; ?></span>
					</label>
				<?php } ?>
				</div>
			</div>
		</fieldset>

		<fieldset>
		<div class="inner">
		<label>Position</label>
		<select name="position">
			<option value="">--NONE--</option>
			<?php foreach($positions as $key => $val) {
				$selected = (!empty($widg->position) && $widg->position == $val ? 'selected' : ''); ?>
				<option value="<?php echo $val; ?>" <?php echo $selected; ?>><?php echo $val; ?></option>
			<?php } ?>
		</select>
		</div>
		</fieldset>

		<fieldset>
		<div class="inner">
		<label>Status</label>
		<select name="state">
			<?php foreach(PUBLISHSTATE as $key => $val) {
				$selected = (!empty($widg->state) && $widg->state == $key ? 'selected' : ''); ?>
				<option value="<?php echo $key; ?>" <?php echo $selected; ?>><?php echo $val; ?></option>
			<?php } ?>
		</select>
		</div>
		</fieldset>

		<fieldset>
		<h5 class="slidetab"><span>Menu Assignment</span></h5>
		<div class="inner slidecontent">
			<small class="info">Assign to one or more menu items</small>
			<div class="vcheck">
				<label>
				<span><input type="checkbox" name="assigned[menu0]" value="All" <?php echo (isset($assign->assigned->menu0) && $assign->assigned->menu0 == 'All' ? 'checked' : '') ?> /></span>
				<span>All Items</span>
				</label>
				<?php foreach($menuitems as $menu) {
					$selected = (in_array($menu->id, $menuselected) ? 'checked' : '');
				?>
				<label>
				<span><input type="checkbox" name="assigned[menu<?php echo $menu->id; ?>]" value="<?php echo $menu->id; ?>" <?php echo $selected; ?> /></span>
				<span><?php echo $menu->title; ?></span>
				</label>
				<?php } ?>
			</div>
		
			<!-- Menu Item Exclude -->
			<h6><span>Exclude Menu Items</span></h6>
			<div class="vcheck">
				<?php foreach($menuitems as $menu) {
				$selected = (in_array($menu->id, $excludes) ? 'checked' : '');
				?>
				<label>
					<span><input type="checkbox" name="exclude[menu<?php echo $menu->id; ?>]" value="<?php echo $menu->id; ?>" <?php echo $selected; ?> /></span>
					<span><?php echo $menu->title; ?></span>
				</label>
				<?php } ?>
			</div>
			
			<!-- Category View Exclude -->
			<h6><span>Category View</span></h6>
			<?php field('select', 'catview', $assign->catview, ['' => 'select', 1 => 'Don\'t show in category view', 2 => 'Show Only in category view']); ?>
		</div>
		</fieldset>
		
		<fieldset>
		<h5 class="slidetab"><span>Product Group Assignment</span></h5>
		<div class="inner slidecontent">
			<small class="info">Assign to one or more product group</small>
			<div class="vcheck">
				<?php foreach($productgroups as $gid => $gname) {
					$selected = (in_array($gid, $groupselected) ? 'checked' : '');
				?>
				<label>
				<span><input type="checkbox" name="group[prodgroup<?php echo $gid; ?>]" value="<?php echo $gid; ?>" <?php echo $selected; ?> /></span>
				<span><?php echo $gname; ?></span>
				</label>
				<?php } ?>
			</div>
		</div>
		</fieldset>

		<!-- Sort Order -->
		<fieldset>
			<h5><span>Sort Order</span></h5>
			<div class="inner">
			<select name="sortcalc">
				<option value="">Default First</option>
				<?php foreach($widgets as $widget) {
					$attr = json_decode($widget->attribs);
					$selected = ($widget->id == $widg->id ? 'selected' : '');
					//$sortval =
					?>
					<option value="<?php echo $widget->sortorder; ?>" <?php echo $selected; ?>><?php echo $attr->title; ?></option>
				<?php } ?>
				<option value="1000000">Last</option>
			</select>
			<?php field('number', 'sortorder', $widg->sortorder, '', 'manually set value'); ?>
			</div>
		</fieldset>

		<fieldset>
		<h5><span>Add Custom Class</span></h5>
		<div class="inner">
		<small class="info">Append style classes to the module wrapper</small>
		<?php field('textarea', 'widgetclass', $attribs->widgetclass); ?>
		</div>
		</fieldset>
		
		<fieldset>
		<h5><span>Note To Self</span></h5>
		<div class="inner">
		<input type="text" name="note" value="<?php echo (isset($attribs->note) ? $attribs->note : ''); ?>" />
		</div>
		</fieldset>
	</div>
</div>