<?php
/*
* Copyright (c) 2019 Emuzement Net Inc. All Rights Reserved
* License: EULA
* Author: Alex/Kumar/Manti/Lisa
*/

if( !defined("WHMCS") ) die("This file cannot be accessed directly");

$returnview = $modlink.'&view=widgetManager&task=list&type=widgets';

// find all widgets in widgets directory
$widgetdir = new \DirectoryIterator(LIB_PATH.'/widgets/');
$widgetlist =[]; $widgname=[];

foreach ($widgetdir as $widg)
{
	$filename = $widg->getFilename();
	$path = LIB_PATH.'/widgets/'.$filename;
	
	if( $widg->isDir() && !$widg->isDot() ) 
	{
		// get .ini file and parse as constants
		iniParse($path.'/language', $filename);
		
		// get xml fields
		$widgdata = simplexml_load_file($path.'/'.$filename.'.xml');
		$widgeturl = $modlink.'&view=widgetManager&task=edit&type=widget&widgettype='.$filename;
		
		// create description tool tip
		$tooltip='';
		if( !empty($widgdata->preview) ) 
			$tooltip = cmseToolTip($widgdata->preview, $widgdata->name);
		
		$widgetlist[] = '
		<li>
			<a href="'.$widgeturl.'"'.$tooltip.'>
			<i class="fas fa-plus"></i> '.$widgdata->name.'</a>
		</li>
		';
	}
}

// delete items by checkbox
if( !is_null(getPost('item_delete', false)) )
{
	$dels = explode(',', getPost('items_id', false));
	try{
		widgets()->whereIn('id',$dels)->delete();
	} catch (\Exception $e) {
		cmseNotice($e->getMessage());
	}
	redirect($returnview);
}

// disable widget
if( !is_null(getPost('item_disable', false)) )
{
	$dels = explode(',', getPost('items_id', false));
	try{
		widgets()->whereIn('id',$dels)->update(['state' => 2]);
	} catch (\Exception $e) {
		cmseNotice($e->getMessage());
	}
	redirect($returnview);
}

// enable widget
if( !is_null(getPost('item_enable', false)) )
{
	$dels = explode(',', getPost('items_id', false));
	try{
		widgets()->whereIn('id',$dels)->update(['state' => 1]);
	} catch (\Exception $e) {
		cmseNotice($e->getMessage());
	}
	redirect($returnview);
}

?>



<div class="clearall">
	<div class="boxsize width_70 break">
		<table class="table-striped chart">
		<thead>
			<tr>
			<th>Title</th>
			<th>Position</th>
			<th>Type</th>
			<th>Order <button type="submit" name="widget_order" class="btn btn-sm btn-default" style="padding: 1px 3px; line-height: normal;">Sort</button></th>
			<th>Created</th>
			<th>Updated</th>
			<th>ID</th>
			<th>State <input type="checkbox" value="" name="checkall" /></th>
			</tr>
		</thead>
		<tbody>
		<?php

		$widgets = widgets()->orderBy('position')->get();
		$widgets = collect($widgets)->sortBy('sortorder','asc','position');
		foreach($widgets as $widget) {
			$attribs = json_decode($widget->attribs);
		?>
		<tr<?php echo ($widget->state == 2 ? ' class="disabled"' : ' class="enabled"'); ?>>
			<td>
				<a href="<?php echo $modlink; ?>&view=widgetManager&task=edit&type=widget&widgettype=<?php echo $widget->type; ?>&id=<?php echo $widget->id; ?>">
				<?php echo $attribs->title; ?></a>
				<small class="info"><?php echo $attribs->note; ?></small>
			</td>
			<td><?php echo $widget->position; ?></td>
			<td><?php echo $widget->type; ?></td>
			<td>
				<input type="number" name="widgorder-<?php echo $widget->id; ?>" value="<?php echo $widget->sortorder; ?>" style="width: 60px !important;" />
			</td>
			<td>
				<?php echo dateFormat($widget->created_at, 'short'); ?>
				<small class="info">
				<a href="configadmins.php?action=manage&id=<?php echo $widget->author; ?>">
				<?php echo adminName($widget->author); ?></a>
				</small>
			</td>
			<td>
				<?php if( $widget->updated_at != '0000-00-00 00:00:00' ) { ?>
				<?php echo dateFormat($widget->updated_at, 'short'); ?>
				<small class="info">
				<a href="configadmins.php?action=manage&id=<?php echo $widget->update_author; ?>">
				<?php echo adminName($widget->update_author); ?></a>
				</small>
				<?php } ?>
			</td>
			<td><?php echo $widget->id; ?></td>
			<td>
			<input type="checkbox" name="item_check" value="<?php echo $widget->id; ?>" /><?php echo ($widget->state == 2 ? ' <i class="fas fa-minus-circle"></i>' : ' <i class="fas fa-check-circle" title="Published"></i>'); ?>
			</td>
		</tr>
		<?php } ?>
		</tbody>
		</table>

	</div>

	<!-- Widgets List Add Widget -->
	<div class="boxsize width_30 break padleft-20 cmse-column">
		<h3>Add Widgets</h3>
		<div class="vcheck" style="max-height: 500px;">
		<ul class="bullet-list">
		<?php echo implode('', $widgetlist); ?>
		</ul>
		</div>
	</div>
</div>


<?php // set order

	if( !is_null(getPost('widget_order', false)) ) {
		foreach($widgets as $setorder) {
			try{
				widgets()->where('id', $setorder->id)->update(['sortorder' => getPost('widgorder-'.$setorder->id, false)]);
			} catch (\Exception $e) {
				cmseNotice($e->getMessage());
			}
		}
		redirect($returnview);
	}
?>


