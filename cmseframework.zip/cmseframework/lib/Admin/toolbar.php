<?php
/*
* Copyright (c) 2019 Emuzement Net Inc. All Rights Reserved
* License: EULA
* Author: Alex/Kumar/Manti/Lisa
*/

if( !defined("WHMCS") ) die("This file cannot be accessed directly");

$newlink= $catlink= $newmenugroup='';
$btn_class = 'class="btn btn-sm btn-success"';
$newicon = '<i class="fa fa-file-edit"></i> ';

if( !requestKey('view') ) 
	$pagetitle = 'Dashboard';

// global config
if( $view == 'configs' ) 
	$pagetitle = 'Global Configuration';

// installer
if( $view == 'installer' ) 
	$pagetitle = 'Extension Installer';

// language manager
if( $view == 'languageManager' )
	$pagetitle = 'Language Editor';
// template manager
if( $view == 'templateManager' ) 
{
	if( file_exists(TMPLS_DIR.'/'.getRequest('template').'/template.xml') ) {
		$manifest = true;
	}

	$pagetitle = 'Template Manager';
	if( $task == 'templateConfig' )
		$pagetitle .= ' - Configure <strong>'.ucwords(getRequest('template')).'</strong>';
	
	if( $task == 'templateAdminEdit' )
		$pagetitle .= ' - Edit custom admin css';
	
	if( $task == 'templateCopy' ) 
	{
		if( $manifest ) {
			$pagetitle .= ' - Make copy or duplicate child of <strong>'.getRequest('template').'</strong><small class="info">'.CMSE_INFO_TMPL_COPY.'</small>';
		}else
		if( !$manifest && requestKey('parent_tpl') ) {
			$pagetitle .= ' - Make duplicate of child template <strong>'.getRequest('template').'</strong>. The parent is <strong>'.getRequest('parent_tpl').'</strong>';
		}else{
			$pagetitle .= ' - Make copy of <strong>'.getRequest('template').'</strong> template files<small class="info">'.CMSE_TMPL_INFO_COPY_NO_MANIFEST.'</small>';
		}
	}
}


// posts
if( $view == 'postManager' ) 
{
	$pagetitle = 'Post Manager';
	if( $type == 'posts' ) {
		$newlink = '<a href="'.$modlink.'&view=postManager&task=edit&type=post" '.$btn_class.'>'.$newicon.'New Post</a> ';
		$catlink = '<a href="'.$modlink.'&view=postManager&task=list&type=categories" '.$btn_class.'>Categories</a>';
	}
	if( $type == 'categories' ) 
		$newlink = '<a href="'.$modlink.'&view=postManager&task=edit&type=category" '.$btn_class.'>'.$newicon.'New Category</a>';
	
	if( $type == 'post' && !requestKey('postid') )
		$pagetitle .= ' - New Post';
	if( requestKey('postid') ) {
		$post = posts()->where('id', getRequest('postid'))->select('catid', 'alias')->get()[0];
		$catalias = categories()->where([['type', 'post'], ['id', $post->catid]])->value('alias');
		$menuid='';
		$rawurl = 'index.php?component=posts&view=post&category='.$post->catid.'-'.$catalias.'&post='.getRequest('postid').'-'.$post->alias.'&menuid='.$menuid;
		
		$pagetitle .= ' - Edit Post - ID '.getRequest('postid').' - <a href="'.ROOT_URL.router($rawurl).'" target="_blank">View Post</a>';
	}
	if( $type == 'categories' )
		$pagetitle .= ' - Categories';
	if( $type == 'category' && !requestKey('catid') )
		$pagetitle .= ' - New Category';
	if( requestKey('catid') )
		$pagetitle .= ' - Edit Category';
}
// menu
if( $view == 'menuManager' ) 
{
	$pagetitle = 'Menu Manager';
	if( $type == 'menus' ) {
		$newlink = '<a href="'.$modlink.'&view=menuManager&task=edit&type=menu" '.$btn_class.'>'.$newicon.'New Menu Item</a>';
		$newmenugroup = '
		<div class="inlineblock aligntop clearall">
			<div class="boxsize">
				<input type="text" name="groupname" size="20" value="" placeholder="new menu group name" class="form-control" />
			</div>
			<div class="boxsize">
				<input type="submit" name="save_menugroup" value="Create Menu Group" '.$btn_class.' />
			</div>
		</div>';
	}
	if( $type == 'menu' && !requestKey('menuid') ) 
		$pagetitle .= ' - Add Menu Item';
	if( requestKey('menuid') )
		$pagetitle .= ' - Edit Menu';
}
// widgets
if( $view == 'widgetManager' ) 
{
	$widgetname = ucwords(str_replace('_', ' ', getRequest('widgettype')));
	$pagetitle = 'Widget Manager';
	if( requestKey('id') )
		$pagetitle .= ' - Edit '.$widgetname.' - #widget-'.getRequest('id');
	if( $type == 'widget' && !requestKey('id') )
		$pagetitle .= ' - New '.$widgetname;
}
// banners
if( $view == 'bannerManager' ) 
{
	$pagetitle = 'Banner Manager';
	
	if( $type == 'banners' ) {
		$newlink = '<a href="'.$modlink.'&view=bannerManager&task=edit&type=banner" '.$btn_class.'>'.$newicon.'New Banner</a> ';
		$catlink = '<a href="'.$modlink.'&view=bannerManager&task=list&type=categories" '.$btn_class.'>Categories</a>';
	}
	if( $type == 'categories' ) {
		$newlink = '<a href="'.$modlink.'&view=bannerManager&task=edit&type=category" '.$btn_class.'>'.$newicon.'New Category</a>';
		$pagetitle .= ' Categories';
	}
	if( !requestKey('id') && $type == 'banner' )
		$pagetitle .= ' - Add New Banner';
	if( requestKey('id') && $type == 'banner' )
		$pagetitle .= ' - Edit Banner';
	if( !requestKey('id') && $type == 'category' )
		$pagetitle .= ' - Add New Category';
	if( requestKey('id') && $type == 'category' )
		$pagetitle .= ' - Edit Category';
}


?>

<div class="toolbar clearall marginbottom-10">
	<div class="clearall marginbottom-10">
		<span class="<?php echo ($view == 'postManager' ? 'active' : ''); ?>">
			<a href="<?php echo $modlink; ?>&view=postManager&task=list&type=posts" class="btn btn-primary btn-sm">
				<i class="fas fa-file-edit"></i>
				<?php echo CMSE_BTNLBL_NEWPOST; ?>
			</a>
		</span>

		<span class="<?php echo ($view == 'menuManager' ? 'active' : ''); ?>">
			<a href="<?php echo $modlink; ?>&view=menuManager&task=list&type=menus" class="btn btn-primary btn-sm">
				<i class="fas fa-bars"></i>
				<?php echo CMSE_BTNLBL_MENUS; ?>
			</a>
		</span>

		<span class="<?php echo ($view == 'widgetManager' ? 'active' : ''); ?>">
			<a href="<?php echo $modlink; ?>&view=widgetManager&task=list&type=widgets" class="btn btn-primary btn-sm">
				<i class="fas fa-cog"></i>
				<?php echo CMSE_BTNLBL_WIDGETS; ?>
			</a>
		</span>

		<span class="<?php echo ($view == 'bannerManager' ? 'active' : ''); ?>">
			<a href="<?php echo $modlink; ?>&view=bannerManager&task=list&type=banners" class="btn btn-primary btn-sm">
				<i class="fas fa-bars"></i>
				<?php echo CMSE_BTNLBL_BANNERMGR; ?>
			</a>
		</span>
		
		<?php if( $view == 'templateManager' ) { ?>
		<span class="<?php echo ($task == 'templateAdminEdit' ? 'active' : ''); ?>">
			<a href="<?php echo $modlink; ?>&view=templateManager&task=templateAdminEdit" class="btn btn-primary btn-sm">
				<i class="fas fa-file-edit"></i>
				<?php echo 'Admin Template'; ?>
			</a>
		</span>
		<?php } ?>



	<!-- Delete, Enable, Disable -->
		<?php if( $task == 'list' && $view != 'templateManager' ) { ?>
		<input type="hidden" name="items_id" id="items_id" value="" />
		<span class="btn-delete floatright">
			<button type="submit" name="item_delete" class="btn btn-danger btn-sm item_delete">
				<i class="fas fa-times-circle"></i>
				<?php echo CMSE_BTNLBL_DELETE; ?>
			</button>
		</span>
		<span class="btn-delete floatright">
			<button type="submit" name="item_disable" class="btn btn-secondary btn-sm item_delete">
				<i class="fas fa-minus-circle"></i>
				<?php echo 'Disable'; ?>
			</button>
		</span>
		<span class="btn-delete floatright">
			<button type="submit" name="item_enable" class="btn btn-success btn-sm item_delete">
				<i class="fas fa-check"></i>
				<?php echo 'Enable'; ?>
			</button>
		</span>
		<?php } ?>
	</div>
	
	<!-- Sub Nav -->
	<div class="subnav">
		<h2><i class="fas fa-angle-double-down"></i> <?php echo $pagetitle; ?></h2>
		<?php echo $newlink . $catlink . $newmenugroup; ?>
	
	
		<!-- Filter -->
		<?php 
		if( $view == 'postManager' && $task == 'list' && $type == 'posts' ) { 
		$cats = categories()->select('id', 'title')->where('type', 'post')->get();
		?>
		<fieldset class="inlineblock alignmiddle">
			<div class="inlineblock alignmiddle">
				<select name="filter_post" class="form-control">
					<option value="">-- Filter By Category --</option>
					<?php foreach($cats as $cat) { ?>
					<option value="<?php echo $cat->id; ?>" <?php echo (isset($_COOKIE['filter_catid']) && $cat->id == $_COOKIE['filter_catid'] ? 'selected' :''); ?>><?php echo $cat->title; ?></option>
					<?php } ?>
				</select>
			</div>
			<div class="inlineblock alignmiddle">
				<button type="submit" name="clear_filter" class="btn btn-sm btn-default">Clear</button>
			</div>
			<input type="hidden" name="filter_value" value="" />
		</fieldset>
		<?php } ?>
	</div>

</div>



<?php 
if( requestKey('task') && $task == 'edit' ) { ?>
<fieldset class="savebtn-bar">
	<?php
	field('button', 'saveitem', 'Save', '', '', ['fieldclass' => 'btn-success btn-sm']);
	field('button', 'savenew', 'Save and New', '', '', ['fieldclass' => 'btn-info btn-sm']);
	field('button', 'saveclose', 'Save and Close', '', '', ['fieldclass' => 'btn-primary btn-sm']);
	field('hidden', 'stateval', '', '', '', ['id' => 'stateval']);
	?>
</fieldset>
<?php } ?>
<div class="clearall marginbottom-10"></div>

<?php if( $view == 'configs' ) { ?>
<fieldset>
	<input type="submit" name="save_config" class="btn btn-info btn-sm" value="Save Configuration" />
</fieldset>
<?php } ?>