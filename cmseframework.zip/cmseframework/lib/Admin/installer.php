<?php
/*
* Copyright (c) 2019 Emuzement Net Inc. All Rights Reserved
* License: EULA
* Author: Alex/Kumar/Manti/Lisa
*/

if( !defined("WHMCS") ) die("This file cannot be accessed directly");


if( !is_null(getPost('install', false)) )
{
	$tmp = ROOTDIR.'/modules/addons/'.MODNAME.'/_copyfiles/tmp';

	// upload zip file
	getFileUpload('get_filename', $tmp.'/', 20000, 'Uploaded successfully');
	// extract and delete zip file
	zipex($tmp.'/'.getPost('install_ext', false), 'Extracted '.getPost('install_ext', false).' successfully');

	// get folder name
	$folder = getFolders($tmp)[0];

	// install cmse widget or whmcs addon
	if( file_exists($tmp.'/'.$folder.'/'.$folder.'.xml') )
	{
		// get installer file
		$manifest = simplexml_load_file($tmp.'/'.$folder.'/'.$folder.'.xml');
		$type = (string)$manifest->attributes()->type;
		
		if( !isset($manifest->files) ) {
			echo '<p class="alert alert-warning">The file list declaration is missing. The installation has been aborted. Please check the manifest file</p>';
			return;
		}
		
		
		// remove any file or folder which is not declared
		$allfiles = array_merge(getFolders($tmp.'/'.$folder), getFilez($tmp.'/'.$folder));

		// scan for non declared files and folders and delete before installation is processed
		foreach($allfiles as $afile) {
			if( !in_array($afile, (array)$manifest->files->file) ) {
				echo '<p class="alert alert-danger">Filename <strong>'.$afile.'</strong> - exists in the extension folder but is not declared in the file manifest and has been deleted for security.</p>';
				deleteFolders($tmp.'/'.$folder.'/'.$afile);
			}
		}

		// check folder for declared files and folders and 
		// abort process if a file is declared but not included in package
		echo '<ul style="padding: 10px; border: 1px solid #eeeeee; border-radius: 4px; margin-bottom: 10px;">';
		foreach($manifest->files->file as $file) 
		{
			if( file_exists($tmp.'/'.$folder.'/'.$file) ) {
				echo '<li style="color: #03447a; font-weight: 900;">'.$file.' is valid</li>';
			}else{
				echo '<p>Filename '.$file.' is declared but not included in the package.</p>';
				$abort = true;
			}
		}
		echo '</ul>';
			

		// cmse widget
		if( $type == 'widget' ) 
		{
			if( !$abort ) {
			copyAll($tmp.'/'.$folder, LIB_PATH.'/widgets/'.$folder);
				echo '<p class="alert alert-info"><strong>CMSE widget '.$folder.' successfully installed!</strong></p>';
			}else{
				echo '<p class="alert alert-warning">Installation aborted due to missing files. Please check the manifest file and the extension package.</p>';
				deleteFolders($tmp.'/'.$folder);
			}
		}
		// whmcs addon update
		if( $type == 'whmcsaddon' ) 
		{
			if( !$abort ) {
				copyAll($tmp.'/'.$folder, ROOT_PATH.'modules/addons/'.$folder);
				if( in_array($folder, getDbo('tbladdonmodules')->pluck('module')) ) {
					echo '<p class="alert alert-info"><strong>Addon '.$folder.' successfully updated!</strong></p>';
				}else{
					echo '<p class="alert alert-info"><strong>Addon '.$folder.' successfully installed!</strong> <a class="btn btn-sm btn-primary" href="'.ROOT_URL.'admin/configaddonmods.php">Enable The Addon</a></p>';
				}
			}else{
				echo '<p class="alert alert-warning">Installation aborted due to missing files. Please check the manifest file and the extension package.</p>';
				deleteFolders($tmp.'/'.$folder);
			}
		}

		// delete the entire tmp folder after process to ensure no file or directory remain
		deleteFolders($tmp);
		// recreate tmp folder now guaranteed empty
		mkdir($tmp);
	}else
	// install cmse component template or whmcs frontend template
	if( file_exists($tmp.'/'.$folder.'/template.xml') )
	{
		$manifest = simplexml_load_file($tmp.'/'.$folder.'/template.xml');

		// cmse framework component template
		if( (string)$manifest->attributes()->type == 'template' ) {
			copyAll($tmp.'/'.$folder, MODPATH.'/templates/'.$folder);
			echo '<p class="alert alert-info"><strong>CMSE template '.$folder.' successfully installed!</strong></p>';
		}
		// whmcs frontend template
		if( (string)$manifest->attributes()->type == 'whmcstemplate' ) {
			copyAll($tmp.'/'.$folder, ROOT_PATH.'templates/'.$folder);
			echo '<p class="alert alert-info"><strong>WHMCS template '.$folder.' successfully installed!</strong></p>';
		}

		// delete the entire tmp folder after process to ensure no file or directory remain
		deleteFolders($tmp);
		// recreate tmp folder now guaranteed empty
		mkdir($tmp);

	}else{
		// incorrect packaging, hack files or simply that some shit is wrong so dump all
		echo '<p class="alert alert-warning">Missing XML manifest or the package is not compatible. Installation aborted</p>';
		// delete the entire tmp folder after process to ensure no file or directory remain
		deleteFolders($tmp);
		// recreate tmp folder now guaranteed empty
		mkdir($tmp);
	}
}

if( requestKey('do') && getRequest('do') == 'update' ) {
	include LIB_PATH.'/Admin/updateCheck.php';
}

?>

<p><?php echo CMSE_INFO_INSTALLER; ?></p>
<input type="file" name="get_filename" accept="application/zip" aria-invalid="false" />
<input type="hidden" name="install_ext" value="" />
<input type="submit" name="install" value="<?php echo CMSE_BTN_INSTALL_EXT; ?>" class="btn btn-info btn-sm" />