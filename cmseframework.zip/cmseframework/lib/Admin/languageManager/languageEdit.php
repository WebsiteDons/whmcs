<?php
/*
* Copyright (c) 2019 Emuzement Net Inc. All Rights Reserved
* License: EULA
* Author: Alex/Kumar/Manti/Lisa
*/

if( !defined("WHMCS") ) die("This file cannot be accessed directly");

use \WHMCS\Session;

TIMEZONE;
$now = date('Y-m-d H:i:s');


// create an overrides folder if it does not exist
if( !file_exists(ROOT_PATH.'lang/overrides') ) {
	mkdir(ROOT_PATH.'lang/overrides');
}

//$default = getSetting('Language');
$n = "\n";
$default = ROOT_PATH.'lang/overrides/'.getSetting('Language').'.php';

// get language file and convert to array for field insert
$lang = file_get_contents(ROOT_PATH.'lang/'.getSetting('Language').'.php');
$lang = explode('$_LANG', $lang);
$lang = array_slice($lang,2);
$lang = implode('', $lang);
$lang = explode(PHP_EOL, $lang);
$lang = str_replace(['[',']',';'], ['','',''], $lang);
foreach($lang as $langs) {
	$l[] = explode(' = ', $langs);
}
foreach($l as $g) {
	$t[$g[0]] = $g[1];
}


if( !file_exists($default) ) {
	$lang = fopen($default, 'w');

	fwrite($lang, "<?php\n");
	fclose($lang);
}

/*
$eng = file_get_contents(ROOT_PATH.'lang/english.php');
$eng = explode(PHP_EOL, $eng);
*/

// write single lines to the override file
if( getPost('save_language', false) )
{
	$constant	= '$_LANG[\''.html_entity_decode($_POST['language_constant'], ENT_QUOTES, 'UTF-8').'\']';
	$value		= '"'.html_entity_decode($_POST['language_value'], ENT_QUOTES, 'UTF-8').'";';
	$entry		= $n.$constant.'='.$value;

	file_put_contents($default, $entry, FILE_APPEND);
	
	// record updates in mod_cmse_sys table
	getDbo('mod_cmse_sys')->insertGetId(['type' => 'Language', 'updated_at' => $now, 'admin' => Session::get('adminid')]);

	redirect($modlink.'&view=languageManager&itemsaved=1');
}

// edit language override file 
if( Session::get('adminid') == 1 ) {
if( !is_null(getPost('save_override', false)) ) 
{
	file_put_contents($default, html_entity_decode(getPost('update_override', false), ENT_QUOTES, 'UTF-8'), LOCK_EX);
	redirect($modlink.'&view=languageManager&itemsaved=1');
}
}

// update globalconfig json object with cmse_text
if( !is_null(getPost('save_cmsetext')) )
{
	$tx = globalconfig()->where([['module', MODNAME],['setting', 'configs']])->value('value');
	$tx = json_decode($tx);
	$tx->cmse_texts = getPost('cmse_texts');
	
	try{
	globalconfig()
	->where([
	['module', MODNAME],
	['setting', 'configs']
	])
	->update(['value' => json_encode($tx)]);
	} catch (\Exception $e) {
		cmseNotice($e->getMessage());
	}
	
	redirect($modlink.'&view=languageManager&itemsaved=1');
}


//debug( json_decode($er));
?>

<h3>Language Editor - Default language is <?php echo getSetting('Language'); ?></h3>
<p>A language override folder exists and <strong><?php echo getSetting('Language'); ?>.php</strong> override file exists. Each entry will be added on a new line of the file</p>
<fieldset class="langfields">
	<div style="clear: both; margin-bottom: 20px;">
	<label>Select Value</label>
	<select name="language_value_select" class="wide-select">
		<option value="">--Select--</option>
		<?php foreach($t as $key => $val) { ?>
			<option value="<?php echo str_replace('\'', '', $key); ?>"><?php echo str_replace('"', '', $val); ?></option>
		<?php }
		?>
	</select>
	</div>
	
	<span class="inputfield constant">
		<label>Constant</label>
		<input type="text" name="language_constant" value="" class="monospace" placeholder="affiliatesactivate" />
	</span>
	<span><br />=</span>
	<span class="inputfield">
		<label>Value</label>
		<textarea name="language_value" class="monospace" placeholder="Activate Affiliate Account"></textarea>
	</span>
	
</fieldset>

<fieldset>
<input type="submit" name="save_language" value="Save Language Constant" class="btn btn-info btn-sm" />
</fieldset>

<hr />

<!-- Text Management -->
<fieldset class="groupslide">
	<h5 class="slidetab"><span class="title">Language Override File Editor</span></h5>
	<div class="slidecontent">
		<small class="info">This is the file where all the above changes are stored. This editor provides a means to manage the file and perform bulk editing.</small>
		<textarea class="autosize monospace" name="update_override"><?php echo file_get_contents($default); ?></textarea>
	
		<button type="submit" name="save_override" class="btn btn-sm btn-primary">Update Override</button>
	</div>
</fieldset>

<fieldset class="groupslide">
	<h5 class="slidetab"><span class="title">CMSE Texts Management</span></h5>
	<div class="slidecontent">
		<small class="info">Manage texts associated with CMSE Framework. This is the exact data as in the global configuration text section.</small>
		<textarea class="autosize monospace" name="cmse_texts"><?php echo getConfigVal('cmse_texts'); ?></textarea>
	
		<button type="submit" name="save_cmsetext" class="btn btn-sm btn-primary">Save CMSE Texts</button>
	</div>
</fieldset>