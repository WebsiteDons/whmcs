<?php
/*
* Copyright (c) 2019 Emuzement Net Inc. All Rights Reserved
* License: EULA
* Author: Alex/Kumar/Manti/Lisa
*/

if( !defined("WHMCS") ) die("This file cannot be accessed directly");

use \WHMCS\Session;

$returnview = $modlink.'&view=templateManager&task=list';

// make file copy of an existing child template
if( !is_null(getPost('make_tpl_child_copy', false)) ) 
{
	$config = templates()->where('slug', getRequest('template'))->value('configs');
	$tplname = cleanChars(getPost('tpl_name'));
	
	try{
	templates()->insertGetId([
	'name' => $tplname, 
	'slug' => $tplname, 
	'configs' => $config, 
	'parent_tpl' => getRequest('parent_tpl'),
	'created_at' => sqlDate(),
	'author'	=> Session::get('adminid'),
	]);
	} catch (\Exception $e) {
		cmseNotice($e->getMessage());
	}
	redirect($returnview);
}else

// make database instance parent template
if( !is_null(getPost('make_tpl_child', false)) ) 
{
	$tplname = cleanChars(getPost('tpl_name'));
	
	try{
	templates()->insertGetId([
	'name' => $tplname, 
	'slug' => $tplname, 
	'configs' => '{}', 
	'parent_tpl' => getRequest('template'),
	'created_at' => sqlDate(),
	'author'	=> Session::get('adminid'),
	]);
	} catch (\Exception $e) {
		cmseNotice($e->getMessage());
	}
	
	redirect($returnview);
}else

// make file copy of parent template
if( !is_null(getPost('make_tpl_copy', false)) ) 
{
	$tplname = cleanChars(getPost('tpl_name'));
	$tplpath = SITETPLS_DIR.'/'.$tplname;
	
	// return notice if the folder exists and stop the process
	if( file_exists($tplpath) ) {
		redirect($modlink.'&view=templateManager&task=templateCopy&template='.getRequest('template').'&tplexist=true');
		return;
	}
	
	if( getRequest('template') === 'sixflix' ) {
		copyAll(CMSETPL, $tplpath);
	}else{
		copyAll(SITETPLS_DIR.'/'.getRequest('template'), $tplpath);
	}
	
	// edit xml values
	// change name field in xml to that which was entered
	if( file_exists($tplpath.'/template.xml') ) 
	{
		$xmlfile = $tplpath.'/template.xml';
		$xml = file_get_contents($xmlfile);
		$newname = preg_replace(
		[
		'#<name>(.*?)</name>#i', 
		'#<folder>(.*?)</folder>#i', 
		'#core=\"true\"#i',
		'#path=\"(.*?)\"#i'
		], 
		[
		'<name>'.$tplname.'</name>', 
		'<folder>'.$tplname.'</folder>', 
		'core="false"',
		'path="templates/'.$tplname.'/css/themes/"'
		], 
		$xml
		);

		file_put_contents($xmlfile, $newname);
		
		if( file_exists($tplpath.'/_templateConfigs.php') ) 
		{
			$tplconfig = $tplpath.'/_templateConfigs.php';
			$tpconfig = file_get_contents($tplconfig);
			$configedit = preg_replace('#'.getRequest('template').'\b#i', $tplname, $tpconfig);
			file_put_contents($tplconfig, $configedit);
		}
	}else{
		// create config files in templates which never had
		$xmlfile = $tplpath.'/template.xml';
		$tplconfig = $tplpath.'/_templateConfigs.php';
		
		copyAll(CMSETPL.'/css/themes', $tplpath.'/css/themes');
		
		copy(CMSETPL.'/template.xml', $xmlfile);
		copy(CMSETPL.'/_templateConfigs.php', $tplconfig);
		
		$xml = file_get_contents($xmlfile);
		$xmledit = preg_replace(
		[
		'#sixflix\b#i', 
		'#cmsenergizer#i', 
		'#core=\"true\"#i',
		'#path=\"(.*?)\"#i'
		], 
		[
		$tplname, 
		$tplname, 
		'core="false"',
		'path="templates/'.$tplname.'/css/themes/"'
		], 
		$xml
		);
		file_put_contents($xmlfile, $xmledit);
		
		$tpconfig = file_get_contents($tplconfig);
		$configedit = preg_replace('#sixflix\b#i', $tplname, $tpconfig);
		file_put_contents($tplconfig, $configedit);
	}
	
	redirect($returnview);
}
?>


<div class="inlineblock">
<?php field('text', 'tpl_name', '', '', '', ['placeholder' => 'mytheme', 'required' => 'required']); ?>
</div>
<fieldset class="inlineblock">
	<?php if( requestKey('parent_tpl') ) { ?>
	<button type="submit" name="make_tpl_child_copy" class="btn btn-sm btn-primary">Duplicate Child</button>
	<?php }else{ ?>
	<button type="submit" name="make_tpl_copy" class="btn btn-sm btn-primary">Make Copy</button>
	<?php if( $manifest ) { ?>
	<button type="submit" name="make_tpl_child" class="btn btn-sm btn-info">Make Child</button>
	<?php } ?>
	<?php } ?>
</fieldset>
<?php 
	if( getRequest('tplexist') )
		echo '<p class="alert alert-warning">A template with the name <strong>'.getRequest('template').'</strong> already exists. Use a different name</p>'; 
	?>