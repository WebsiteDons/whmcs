<?php
/*
* Copyright (c) 2019 Emuzement Net Inc. All Rights Reserved
* License: EULA
* Author: Alex/Kumar/Manti/Lisa
*/

if( !defined("WHMCS") ) die("This file cannot be accessed directly");

$parent='';
if( requestKey('parent') && !is_null(getRequest('parent')) )
	$parent = '&parent='.getRequest('parent');

$modlink = $modlink.'&view=templateManager&task=templateConfig&template='.getRequest('template').'&id='.getRequest('id').$parent;


if( getRequest('template') === 'sixflix' || getRequest('parent') === 'sixflix' ) {
	$xmlfields = CMSETPL.'/template';
	$themepath = CMSETPL.'/css/themes';
}else{
	$xmlfields = SITETPLS_DIR.'/'.getRequest('template').'/template';
	$themepath = SITETPLS_DIR.'/'.getRequest('template').'/css/themes';
}

$configs = formFields($xmlfields, '', getRequest('id'), true);

if( !is_null(getPost('save_template_configs', false)) ) 
{
	try{
	templates()->where('id', getRequest('id'))
	->update([
	'configs' => json_encode($configs),
	'updated_at' => sqlDate(),
	'update_author' => \WHMCS\Session::get('adminid')
	]);
	} catch (\Exception $e) {
		cmseNotice($e->getMessage());
	}
	redirect($modlink.'&itemsaved=1');
}


	
if( !is_null(getPost('copycss', false)) ) 
{
	if( file_exists($themepath.'/'.getPost('csscopy_filename').'.css') ) {
		echo '<p class="alert alert-warning">the file name already exists. Process aborted.</p>';
	}else{
		if( !copy($themepath.'/'.getPost('themes', false), $themepath.'/'.getPost('csscopy_filename').'.css') )
			echo 'could not copy file';
		
		redirect($modlink.'&itemsaved=1');
	}
}

// get editable css files
$nonedit = ['sixflix.css', 'reform.css', 'blog.css'];
$cssfiles = getFiles($themepath.'/', 'css');
$cssfiles = array_diff($cssfiles, $nonedit);

// file selector page reload
echo '
<script>
jQuery(function($) {
	var url = "'.$modlink.'&cssedit=";
	$("select#select_edit").change(function() {
		window.location = url+$(this).val();
	});
});
</script>
';

// get content of file. return notice if is core file
if( requestKey('cssedit') ) {
	if( in_array(getRequest('cssedit'), $nonedit) ) {
		$editfile = 'this core file is not editable. Create a copy to edit';
	}else{
		$editfile = file_get_contents($themepath.'/'.getRequest('cssedit'));
	}
}

// save the content to the selected file
if( !is_null(getPost('savefile_edit', false)) ) {
	file_put_contents($themepath.'/'.getRequest('cssedit'), html_entity_decode(getPost('file_editor', false), ENT_QUOTES, 'UTF-8'));
	redirect($modlink.'&cssedit='.getRequest('cssedit'));
}

// create new file
if( !is_null(getPost('newcsscreate', false)) ) {
	cmseMakeFile($themepath.'/'.getPost('newcssfile').'.css');
	redirect($modlink);
}

// delete file
if( !is_null(getPost('css_delete', false)) ) {
	unlink($themepath.'/'.getPost('select_delete', false));
	redirect($modlink);
}



?>


<fieldset>
<button type="submit" name="save_template_configs" class="btn btn-sm btn-info">Save Configuration</button>
</fieldset>

<!-- Fields -->
<?php 
formFields($xmlfields, 'template', getRequest('id')); 
?>

<!-- File Editor -->
<div class="groupslide">
	<h4 class="slideta"><span class="title">Create / Edit Css Files</span></h4>

		<div class="flex wrap marginbottom-20">
			<?php if( !empty($cssfiles) ) { ?>
			<div>
				<h6>Select file to edit</h6>
				<div class="flex">
					<select id="select_edit" class="form-control">
					<option value="">-- Select File --</option>
					<?php foreach($cssfiles as $css) { 
					$selected = ($css == getRequest('cssedit') ? ' selected' : '');
					?>
						<option value="<?php echo $css; ?>" <?php echo $selected; ?>><?php echo $css; ?></option>
					<?php } ?>
					</select>
				
					<?php 
					// show editor textarea when file query is set and has value
					$editorField='';
					if( !empty(getRequest('cssedit')) ) 
					{ 
						$editorField = '
						<textarea name="file_editor" id="file_editor">'.htmlentities($editfile).'</textarea>
						'.cmseCodeEditor('file_editor', 'editor-theme-changer');
					?>
					<div>
						<button type="submit" name="savefile_edit" class="btn btn-sm btn-primary">Save Edit File</button>
					</div>
					<?php } ?>
				</div>
			</div>
			
			<div class="marginleft-20" style="margin-right: 20px;">
				<h6>Select file to delete</h6>
				<div class="flex">
					<select id="select_delete" name="select_delete" class="form-control">
					<option value="">-- Select File --</option>
					<?php foreach($cssfiles as $cssd) { 
					?>
						<option value="<?php echo $cssd; ?>"><?php echo $cssd; ?></option>
					<?php } ?>
					</select>
					<div>
						<button type="submit" name="css_delete" class="btn btn-sm btn-warning">Delete CSS File</button>
					</div>
				</div>
			</div>
			<?php } ?>
			
			<div>
				<h6>Create new CSS file</h6>
				<div class="flex">
					<input type="text" name="newcssfile" class="form-control" placeholder="mynewstyle" />
					<button type="submit" name="newcsscreate" class="btn btn-sm btn-info">Create CSS File</button>
				</div>
			</div>
		</div>

		<?php echo $editorField; ?>

</div>
<!-- column order illustration -->
<style>
#colimg {background-image: url("<?php echo MODURL; ?>/_copyfiles/templates/sixflix/img/column-order.png");}
#colimg {
	width: 100px;
	height: 59px;
}
#colimg.col-213 {
	background-position: 0px 0px;
}
#colimg.col-123 {
	background-position: 0px -59px;
}
#colimg.col-132 {
	background-position: 0px -118px;
}
#colimg.col-231 {
	background-position: 0px -177px;
}
#colimg.col-321 {
	background-position: 0px -236px;
}
#colimg.col-312 {
	background-position: 0px -295px;
}
</style>