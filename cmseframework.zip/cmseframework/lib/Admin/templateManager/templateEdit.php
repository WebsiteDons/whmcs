<?php
/*
* Copyright (c) 2019 Emuzement Net Inc. All Rights Reserved
* License: EULA
* Author: Alex/Kumar/Manti/Lisa
*/

if( !defined("WHMCS") ) die("This file cannot be accessed directly");

$link = $modlink.'&view=templateManager&task=';

$folders = getFolders(SITETPLS_DIR.'/');
$tmpl = (getRequest('template') != '' ? getRequest('template') : getInnerString(getRequest('templatefile'), 'templates/','/'));


$editfile= $currentfile='';
if( requestKey('templatefile') ) {
	$currentfile = getRequest('templatefile');
	$editfile = file_get_contents(getRequest('templatefile'));
}

// save the data to the opened file
if( !is_null(getPost('save_template', false)) ) {
	file_put_contents($currentfile, html_entity_decode(getPost('template_code', false), ENT_QUOTES, 'UTF-8'));
	redirect($link.'templateEdit&template='.$tmpl.'&templatefile='.$currentfile);
}


?>

<h3>
Template Editor - Editing - <span class="tplname"><?php echo $tmpl; ?></span>
<span class="tplfile"><?php echo $currentfile; ?></span>
</h3>

<fieldset>
	<input type="submit" name="save_template" value="Save Template" class="btn btn-info btn-sm" />
</fieldset>

<fieldset>
<textarea id="codemirror-textarea" name="template_code"><?php echo htmlentities($editfile); ?></textarea>
</fieldset>

<?php echo cmseCodeEditor('codemirror-textarea'); ?>