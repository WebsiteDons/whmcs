<?php
/*
* Copyright (c) 2019 Emuzement Net Inc. All Rights Reserved
* License: EULA
* Author: Alex/Kumar/Manti/Lisa
*/

if( !defined("WHMCS") ) die("This file cannot be accessed directly");

$action = $modlink.'&view=templateManager&task=';
$thispage = $action.'list';
$tplcopy = $action.'templateCopy&template=';
$tplconfig = $action.'templateConfig&template=';

$templates = getFolders(SITETPLS_DIR);
$childtpls = templates()->select('id', 'slug', 'parent_tpl')->where('parent_tpl', '<>', '')->get();

$child =[];
foreach($childtpls as $childtpl) {
	$child[$childtpl->slug] = $childtpl->parent_tpl;
}

$templates = array_merge($templates, $child);

?>


<table class="striped chart">
	<thead>
		<tr>
		<th>Name</th>
		<th>Configure</th>
		<th>Edit Code</th>
		<th>Copy</th>
		<th>Information</th>
		<th>Status</th>
		<th>Delete</th>
		</tr>
	</thead>
	<tbody>
	
	<?php 
	foreach($templates as $key => $template) 
	{
		$version= $site= $moredata='';
		$author='<small>not set</small>';  
		$install='<small>not installable</small>';
		$isconfig = '<small>not configurable</small>';
		//$hasParent = (!is_null(templates()->where('parent_tpl', '<>', '')->get()[0]) ? true : false);
		$parent_tpl='';
		if( !is_int($key) ) {
			$hasParent = true;
			$parent_tpl = '<small style="display: block;">parent: '.$template.'</small>';
		}
		
		if( file_exists(SITETPLS_DIR.'/'.$template.'/template.xml') ) 
		{
			if( $template === 'sixflix' ) {
				$tpldata = simplexml_load_file(CMSETPL.'/template.xml');
			}else{
				$tpldata = simplexml_load_file(SITETPLS_DIR.'/'.$template.'/template.xml');
			}
			
			if( !is_int($key) ) {
				$slug = cleanChars($key);
			}else{
				$slug = cleanChars($tpldata->name);
			}
			
			$core = (string)$tpldata->attributes()['core'];
			
			
			$tpldb = templates()->where('slug', $slug)->get()[0];
			
			if( empty($tpldb->slug) ) {
				$install = '<button type="submit" name="install_template_'.$template.'" class="btn btn-sm btn-primary">Install</button>';
				if( !is_null(getPost('install_template_'.$template, false)) ) {
					try{
					templates()->insertGetId([
					'name' => $template, 
					'slug' => $slug, 
					'configs' => '{}',
					'created_at' => sqlDate(),
					'author' => \WHMCS\Session::get('adminid')
					]);
					} catch (\Exception $e) {
						cmseNotice($e->getMessage());
					}
					redirect($thispage);
				}
			}else{
				// template is not uninstallable
				if( $template === 'sixflix' && is_int($key) ) {
					$install = '<small>installed</small>';
				}else
				
				// get assigned template data
				if( in_array($tpldb->id, tplassign()->pluck('tmpl_id')) ) 
				{
					$tbl = 'mod_cmse_tplassign';
					$pre = 'mod_cmse_';
					$modlink = $modlink.'&view=';
					
					$catassigns = tplassign()
					->join($pre.'categories', $tbl.'.resource', '=', $pre.'categories.id')
					->select($tbl.'.type AS cattype', $pre.'categories.title AS cattitle', $pre.'categories.id AS catid')
					->where($tbl.'.type', 'category')
					->get();
					
					$groupassigns = tplassign()
					->join('tblproductgroups', $tbl.'.resource', '=', 'tblproductgroups.id')
					->select($tbl.'.type AS grouptype', 'tblproductgroups.name AS grouptitle', 'tblproductgroups.id AS groupid')
					->where($tbl.'.type', 'productgroup')
					->get();
					
					$menuassigns = tplassign()
					->join($pre.'menus', $tbl.'.resource', '=', $pre.'menus.id')
					->select($tbl.'.type AS menutype', $pre.'menus.title AS menutitle', $pre.'menus.id AS menuid')
					->where($tbl.'.type', 'menu')
					->get();
					
					$assigned_tpls = array_merge($catassigns, $groupassigns, $menuassigns);
					
					$assigned=[];
					foreach($assigned_tpls as $assigned_tpl) 
					{
						$assigned[] = 
						(
						!empty($catassigns) ? 
						'<li>
						<a href="'.$modlink.'postManager&task=edit&type=category&catid='.$assigned_tpl->catid.'">'.$assigned_tpl->cattitle.'</a>
						<small class="info">'.$assigned_tpl->cattype.'</small>
						</li>' : ''
						).
						
						(
						!empty($groupassigns) ? 
						'<li>
						<a href="configproducts.php?action=editgroup&ids='.$assigned_tpl->groupid.'">'.$assigned_tpl->grouptitle.'</a>
						<small class="info">'.$assigned_tpl->grouptype.'</small>
						</li>' : ''
						).
						
						(
						!empty($menuassigns) ? 
						'<li>
						<a href="'.$modlink.'menuManager&task=edit&type=menu&menuid='.$assigned_tpl->menuid.'">'.$assigned_tpl->menutitle.'</a>
						<small class="info">'.$assigned_tpl->menutype.'</small>
						</li>' : '' 
						)
						;
					}
					
					$install = 'Assigned<ul>'.implode('', $assigned).'</ul>';
				}else
					
				// template can be uninstalled
				{
					$template = (!is_int($key) ? $key : $template);
						
					$install = '<button type="submit" name="uninstall_template_'.$template.'" class="btn btn-sm btn-warning">UnInstall</button>';
					if( !is_null(getPost('uninstall_template_'.$template, false)) ) {
						try{
							templates()->where('name', $template)->delete();
						} catch (\Exception $e) {
							cmseNotice($e->getMessage());
						}
						redirect($thispage);
					}
				}
				
				if( isset($tpldata->fields) ) {
					if( !is_int($key) ) {
						$isconfig = '<a href="'.$tplconfig.$key.'&id='.$tpldb->id.'&parent='.$tpldb->parent_tpl.'">Configure</a>';
					}else{
						$isconfig = '<a href="'.$tplconfig.$template.'&id='.$tpldb->id.'">Configure</a>';
					}
				}
			}
			
			
			
			$author = $tpldata->author;
			$version = '<small>version '.$tpldata->version.'</small> | ';
			$site = '<small><a href="'.$tpldata->authorUrl.'" target="_blank">Website</a></small>';
			$created = $tpldata->creationDate;
			$copyright = $tpldata->copyright;
			$license = $tpldata->license;
			
			$moredata = ' | 
			<small><a href="javascript:void(0);" class="showmore'.$template.'">More</a></small>
			<div class="moredata data'.$template.'" style="display: none;">
			<small>Created: '.$created.'</small>
			<small>copyright: '.$copyright.'</small>
			<small>license: '.$license.'</small>
			</div>
			
			<script>
			jQuery(function($) {
				$(".showmore'.$template.'").click(function(){
					$(".data'.$template.'").slideToggle("slow");
				});
			});
			</script>
			';
		}else
		if( $template === 'six') {
			$author = '<div>WHMCS Limited</div><small>version: 6.0</small>';
		}
		
		// delete template
		if( !is_null(getPost('delete_template_'.$template, false)) ) {
			deleteFolders(SITETPLS_DIR.'/'.$template);
			if( isset($tpldb->name) ) {
				try{
					templates()->where('name', $template)->delete();
				} catch (\Exception $e) {
					cmseNotice($e->getMessage());
				}
			}
			
			redirect($thispage);
		}

		$isdefault = (getSetting('Template') == $template ? ' <small>(default)</small>' : '');
		$editcode = $modlink.'&view=templateManager&task=templateEdit&template='.$template;
		
		$noteditable = (
			$template === 'six' || 
			$core === 'true' ||
			$slug === $key ? 
			'<small>Not Editable</small>' : 
			'<a href="'.$editcode.'"><i class="fas fa-edit"></i> Edit</a>'
		);
		
		$delete = (
			getSetting('Template') == $template || 
			$template === 'six' || 
			$template === 'sixflix' ||
			$slug == $tpldb->slug
			? '' : 
			'<button type="submit" name="delete_template_'.$template.'" class="btn btn-sm btn-danger">Delete</button>
		');
		
	?>
	
		<?php if( $template !== 'orderforms' ) { ?>
		<tr>
		<td><?php echo (!is_int($key) ? $key : ucfirst($template).' '.$isdefault); ?><?php echo $parent_tpl; ?></td>
		<td><?php echo $isconfig; ?></td>
		<td><?php echo $noteditable; ?></td>
		<td><a href="<?php echo $tplcopy.(!is_int($key) ? $key.'&parent='.$template : $template); ?>">Make Copy</a></td>
		<td>
			<div><?php echo $author; ?></div>
			<?php echo $version . $site . $moredata; ?>
		</td>
		<td><?php echo $install; ?></td>
		<td><?php echo $delete; ?></td>
		</tr>
		<?php } ?>
	<?php } ?>
	</tbody>
</table>
		
		