<?php
/*
* Copyright (c) 2019 Emuzement Net Inc. All Rights Reserved
* License: EULA
* Author: Alex/Kumar/Manti/Lisa
*/

if( !defined("WHMCS") ) die("This file cannot be accessed directly");

$redirect = $modlink.'&view=templateManager&task=templateAdminEdit';
$themepath = LIB_PATH.'/Admin/templateManager/admincss';

$datafile = $themepath.'/data.txt';
$logofile = $themepath.'/logo.txt';

// get the selected theme to set option to selected
$themeset = file_get_contents($datafile);
$logoimg = file_get_contents($logofile);

// css theme files
$cssfiles = getFiles($themepath.'/', 'css');
foreach($cssfiles as $themefile) {
	$themes[$themefile] = $themefile;
}

$themeselect = array_merge(['' => '--default--'], $themes);

// write to data.txt
if( !is_null(getPost('save_data', false)) ) {
	file_put_contents($datafile, getPost('csstheme', false));
	redirect($redirect);
}

// write to logo.txt
if( !is_null(getPost('save_logo', false)) ) {
	file_put_contents($logofile, getPost('logoimg', false));
	redirect($redirect);
}

// css edit
$cssfile='';
if( requestKey('cssedit') ) {
	$css_file = $themepath.'/'.getRequest('cssedit');
	$cssfile = file_get_contents($themepath.'/'.getRequest('cssedit'));
}

// file selector page reload
	echo '
	<script>
	jQuery(function($) {
		var url = "'.$redirect.'&cssedit=";
		$("select[name=select_edit]").change(function() {
			window.location = url+$(this).val();
		});
	});
	</script>
	';

// save the content to the selected file
if( !is_null(getPost('save_css', false)) ) {
	file_put_contents($css_file, html_entity_decode(getPost('css_editor', false), ENT_QUOTES, 'UTF-8'));
	redirect($redirect.'&cssedit='.getRequest('cssedit'));
}

// create new file
if( !is_null(getPost('newcsscreate', false)) ) {
	cmseMakeFile($themepath.'/'.getPost('newcssfile').'.css');
	redirect($redirect);
}

// delete file
if( !is_null(getPost('css_delete', false)) ) {
	unlink($themepath.'/'.getPost('select_delete', false));
	redirect($redirect);
}
?>



<div class="marginbottom-20 flex wrap">
	<div>
		<h6>Select CSS Theme</h6>
		<div class="flex">
		<div><?php field('select', 'csstheme', $themeset, $themeselect, '', ['raw']); ?></div>
		<div><button type="submit" name="save_data" class="btn btn-sm btn-primary">Save Theme</button></div>
		</div>
	</div>
	
	<div>
		<h6>Replace Logo</h6>
		<div class="flex">
		<?php field('image', 'logoimg', $logoimg, '', '', ['raw']); ?>
		<div><button type="submit" name="save_logo" class="btn btn-sm btn-primary">Save Logo</button></div>
		</div>
	</div>
</div>

<div class="marginbottom-20">
	
	<div class="flex">
		<div>
			<h6>Edit CSS files</h6>
			<?php field('select', 'select_edit', 'choose', $themes, '', ['raw']); ?>
		</div>
		
		<div>
			<h6>Create new CSS file</h6>
			<div class="flex">
				<input type="text" name="newcssfile" class="form-control" placeholder="mynewstyle" />
				<button type="submit" name="newcsscreate" class="btn btn-sm btn-info">Create</button>
			</div>
		</div>
		
		<div>
			<h6>Delete files</h6>
			<div class="flex">
			<?php field('select', 'select_delete', 'choose', $themes, '', ['raw']); ?>
			<div><button type="submit" name="css_delete" class="btn btn-sm btn-info">Delete</button></div>
			</div>
		</div>
	</div>
	
	<textarea name="css_editor" id="css_editor"><?php echo htmlentities($cssfile); ?></textarea>
	<?php echo cmseCodeEditor('css_editor', 'editor-theme-changer'); ?>
</div>

<div>
	<button type="submit" name="save_css" class="btn btn-sm btn-primary">Save Css File</button>
</div>