<?php
/*
* Copyright (c) 2019 Emuzement Net Inc. All Rights Reserved
* License: EULA
* Author: Alex/Kumar/Manti/Lisa
*/

include dirname(__DIR__,6).'/init.php';
if( !defined("WHMCS") ) die("This file cannot be accessed directly");


include_once ROOTDIR.'/modules/addons/cmseframework/functions.php';

function rerouter($url) 
{
	$parts = parse_url(ROOT_URL.$url);
	parse_str($parts['query'], $q);
	
	$component	= $q['component'];
	$view		= $q['view'];
	$category	= $q['category'];
	$post		= $q['post'];
	$menuid		= $q['menuid'];
	$prodgroup	= $q['gid'];
	$prodid		= $q['pid'];
	

	if( isset($component) ) 
	{
		if( $view == 'post' && isset($post) && !isset($category) && isset($menuid) ) {
			$num = (int)$post;
			$route = str_replace($num.'-', '', $post);
		}else
			// posts without menu id uses category alias in url
		if( $view == 'post' && isset($post) && isset($category) ) {
			$num = (int)$post;
			$nums = (int)$category;
			$route = str_replace($nums.'-', '', $category).'/'.str_replace($num.'-', '', $post);
		}else
		// posts category view
		if( $view == 'category' && isset($category) ) {
			$num = (int)$category;
			$route = str_replace($num.'-', '', $category);
		}else
		if( $view == 'categories' ) {
			$num = (int)$menuid;
			$route = str_replace($num.'-', '', $menuid);
		}else
		
		// product detail view
		if( $view == 'productdetail' && isset($prodgroup) && isset($prodid) ) {
			$route = preg_replace('#\d+\-#', '', strtolower($prodgroup)).'/'.preg_replace('#\d+\-#', '', $prodid);
		}else
		
		if( isset($view) && $view == 'productgroup' && isset($prodgroup) ) {
			$num = (int)$prodgroup;
			$route = str_replace($num.'-', '', $prodgroup);
		}else
		if( isset($view) && $view == 'productgroups' ) {
			$num = (int)$menuid;
			$route = str_replace($num.'-', '', $menuid);
			
			if( pathinfo(currenturl())['filename'] == 'cart' && !requestKey('a') ) {
				redirect(str_replace($num.'-', '', $menuid), 301);
			}
		}

	}else{
		// default urls
		$route = $url;
	}
	
	return cmseUri(true).$route;
}

// WHMCS core pages
$whmcs = [
	['title' => '--WHMCS CORE PAGES--', 'value' => ''],
	['title' => 'Home', 'value' => cmseUri(true).'index.php'],
	['title' => 'Cart', 'value' => cmseUri(true).'cart.php'],
	['title' => 'View Cart', 'value' => cmseUri(true).'cart.php?a=view'],
	['title' => 'Domain Registration', 'value' => cmseUri(true).'cart.php?a=add&domain=register'],
	['title' => 'Transfer Domain', 'value' => cmseUri(true).'cart.php?a=add&domain=transfer'],
	['title' => 'Domain Search', 'value' => cmseUri(true).'domainchecker.php'],
	['title' => 'Contact Us', 'value' => cmseUri(true).'contact.php'],
	
	['title' => 'Download', 'value' => cmseUri(true).'index.php?rp=/download'],
	['title' => 'Announcements', 'value' => cmseUri(true).'index.php?rp=/announcements'],
	['title' => 'Knowledgebase', 'value' => cmseUri(true).'index.php?rp=/knowledgebase'],
	['title' => 'RSS Feed', 'value' => cmseUri(true).'index.php?rp=/announcements/rss'],
	['title' => 'Old Announcements', 'value' => cmseUri(true).'index.php?rp=/announcements/view/older'],
	['title' => 'Server Status', 'value' => cmseUri(true).'serverstatus.php'],
	
	['title' => 'Register', 'value' => cmseUri(true).'register.php'],
	['title' => 'Client Area', 'value' => cmseUri(true).'clientarea.php'],
	['title' => 'Password Recovery', 'value' => cmseUri(true).'pwreset.php'],
	['title' => 'Submit Ticket', 'value' => cmseUri(true).'submitticket.php'],
	['title' => 'My Tickets', 'value' => cmseUri(true).'supporttickets.php'],
	['title' => 'Affiliates', 'value' => cmseUri(true).'affiliates.php'],
	['title' => 'Admin Return', 'value' => cmseUri(true).'logout.php?returntoadmin=1'],
	['title' => 'Logout', 'value' => cmseUri(true).'logout.php'],
];

$menuitems = menus()->where('published', 1)->orderBy('menugroup')->pluck('title', 'url');

$menus = [];
foreach($menuitems as $url => $title) {
	$menus[] = ['title' => $title, 'value' => rerouter($url)];
}

$menus = array_merge($menus, $whmcs);

echo json_encode($menus);

?>