<?php 

$plugs = '
autoresize 
searchreplace 
autolink 
directionality 
visualblocks 
visualchars 
fullscreen 
image 
responsivefilemanager 
link 
media 
template 
code 
codesample 
table 
charmap 
hr 
pagebreak 
nonbreaking 
anchor 
insertdatetime 
advlist 
lists 
textcolor 
wordcount 
imagetools 
contextmenu 
colorpicker 
textpattern 
help 
cmseshortcode 
importcss 
stickytoolbar 
paste
';

$minimal = '
fullscreen,
bold,
italic,
bullist,
numlist,
outdent,
indent,
blockquote,
link,
unlink,
justifyleft,
justifycenter,
justifyright,
justifyfull,
hr,
responsivefilemanager,
cmseshortcode,
code,
removeformat
';

$toolbarloaded = '
fullscreen,formatselect,fontselect,fontsizeselect,|,
bold,italic,strikethrough,underline,forecolor,backcolor,|,
link,unlink,|,
justifyleft,justifycenter,justifyright,justifyfull,|,
search,replace,|,
bullist,numlist,",
"outdent,indent,blockquote,|,
undo,redo,|,
cut,copy,paste,pastetext,pasteword,|,
table,|,hr,|,sub,sup,|,charmap,media,|,print,|,ltr,rtl,|,image,responsivefilemanager,removeformat,cmseshortcode,importcss,code,cmse_links_button"
	],
';

$menubaronly = 'toolbar: [],';