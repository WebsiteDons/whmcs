<?php
/*
* Copyright (c) 2019 Emuzement Net Inc. All Rights Reserved
* License: EULA
* Author: Alex/Kumar/Manti/Lisa
*/

include dirname(__DIR__,6).'/init.php';

if( !defined("WHMCS") ) die("This file cannot be accessed directly");

$base = \WHMCS\Utility\Environment\WebHelper::getBaseUrl();
$admindir = \WHMCS\Admin\AdminServiceProvider::getAdminRouteBase();
$cmse = $base.'/modules/addons/cmseframework';


?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="{$charset}">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>CMSE Framework Shortcodes Insert</title>

    <link href="//fonts.googleapis.com/css?family=Open+Sans:300,400,600" rel="stylesheet">
    <link href="<?php echo $base.$admindir; ?>/templates/blend/css/all.min.css" rel="stylesheet" />
	<link href="<?php echo $cmse; ?>/assets/cmseadmin.css" rel="stylesheet" type="text/css" />
    <link href="<?php echo $base; ?>/assets/css/fontawesome-all.min.css" rel="stylesheet" />
	<link href="<?php echo $cmse; ?>/lib/vendor/chosen/chosen.min.css" rel="stylesheet" type="text/css" />
	
	<script type="text/javascript">
		var liburl = "<?php echo LIB_URL; ?>";
		var txtfield = ".wysiwyg";
	</script>
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
	<script type="text/javascript" src="<?php echo $cmse; ?>/assets/ddaccordion.js"></script>
	<script type="text/javascript" src="<?php echo $base; ?>/assets/js/tinymce/tinymce.min.js"></script>
	<script src="<?php echo $cmse; ?>/assets/tinymce.js"></script>
	<script src="<?php echo $cmse; ?>/lib/vendor/chosen/chosen.jquery.min.js"></script>
	<script src="<?php echo $cmse; ?>/assets/cmseadmin.js"></script>


	<style>
	body {background: #ffffff; margin: 20px;}
	</style>
</head>

<body>

<script>
cmseslides("slidetab","slidecontent", 0, persist=false);
function insertCMSEshortcode() 
{
	// preset formats
	if( inputVal('preset',1) ) {
		var shortcode = inputVal('preset',1);
	}else
		// cmse objects
	if( inputVal('mediaobj',1) ) {
		var shortcode = inputVal('mediaobj',1);
	}else
		// google map
	if( inputVal('gmap',1) ) {
		var shortcode = '[googlemap=\"'+inputVal('gmap',1)+'\"]';
	}else
		// download field
	if( inputVal('download',1) ) {
		var shortcode = '[download=\"'+inputVal('download',1)+'\"]';
	}else
		// post insert
	if( inputVal('posts',1) ) {
		var shortcode = '[post=\"'+inputVal('posts',1)+'\"]';
	}else
		// product insert
	if( inputVal('products',1) ) {
		var shortcode = '[product=\"'+inputVal('products',1)+'\"]';
	}else
		// widget insert
	if( inputVal('widgets',1) ) {
		var widgettitle = (inputVal('widgettitle',1) == 1 ? ' title=\"off\"' : '');
		var shortcode = '[widget=\"'+inputVal('widgets',1)+'\"'+widgettitle+']';
	}else
		// contact form
	if( inputVal('contact',1) ) {
		var contactselect = (inputVal('contactselect',1) != '' ? ' '+inputVal('contactselect',1) : '');
		var contactlabel = (inputVal('contactlabel',1) != '' ? ' labels=\"0\"' : '');
		var shortcode = '<p>[contactform=\"'+inputVal('contact',1).replace(/@/g, ':')+'\"'+contactselect+contactlabel+']</p>';
	}else
		// slide and tab
	if( inputVal('slidetab',1) ) {
		if( inputVal('tabtype',1) == 'tab' ) {
			var responsive = (inputVal('tabresponse',1) != '' ? ' switch="'+inputVal('tabresponse',1)+'"' : '');
			var shortcode = '<p>[tabs'+responsive+']</p><p>[tab '+inputVal('slidetab',1)+']</p><p>content</p><p>[/tab]</p><p>[tab The Title]</p><p>content here</p><p>[/tab]</p><p>[/tabs]</p>';
		}else
		if( inputVal('tabtype',1) == 'slide' ) {
			var shortcode = '<p>[slides]</p><p>[slide '+inputVal('slidetab',1)+']</p><p>content</p><p>[/slide]</p><p>[slide Title]</p><p>content</p><p>[/slide]</p><p>[/slides]</p>';
		}
	}else
		// countdown
	if( inputVal('counter',1) ) {
		var countermsg = (inputVal('countermsg',1) != '' ? ' msg=\"'+inputVal('countermsg',1)+'\"' : '');
		var counterclass = (inputVal('counterclass',1) != '' ? ' class=\"'+inputVal('counterclass',1)+'\"' : '');
		var shortcode = '[countdown date=\"'+inputVal('counter',1)+'\"'+counterclass+countermsg+']';
	}else
		// popup window
	if( inputVal('poptype',1) ) {
		var delay = (inputVal('popdelay',1) ? ' delay=\"'+inputVal('popdelay',1)+'\"' : '');
		var once = (inputVal('poponce',1) ? ' once=\"'+inputVal('poponce',1)+'\"' : '');
		var expire = (inputVal('popexpire',1) ? ' exp=\"'+inputVal('popexpire',1)+'\"' : '');
		var popclass = (inputVal('popclass',1) ? ' class=\"'+inputVal('popclass',1)+'\"' : '');
		var poptype = ' poptype=\"'+inputVal('poptype',1)+'\"';
		
		var shortcode = '<p>[popwin'+delay+once+expire+popclass+poptype+']</p>'+inputVal('poptext',1)+'<p>[/popwin]</p>';
	}
	
	//Insert and close window
	parent.tinymce.activeEditor.insertContent(shortcode);
	parent.tinyMCE.activeEditor.windowManager.close();
	return false;
}
</script>

<?php
$preset = [
	'<p>[div class=&quot;boxsize width_70 break&quot;]</p>content here<p>[/div]</p><p>[div class=&quot;boxsize width_30 break padleft-20&quot;]</p>content here<p>[/div]</p>' => '2 Columns 70 - 30',
	'<p>[div class=&quot;boxsize width_30 break&quot;]</p>content here<p>[/div]</p><p>[div class=&quot;boxsize width_70 break padleft-20&quot;]</p>content here<p>[/div]</p>' => '2 Columns 30 - 70',
	'<p>[div class=&quot;boxsize width_60 break&quot;]</p>content here<p>[/div]</p><p>[div class=&quot;boxsize width_40 break padleft-20&quot;]</p>content here<p>[/div]</p>' => '2 Columns 60 - 40',
	'<p>[div class=&quot;boxsize width_40 break&quot;]</p>content here<p>[/div]</p><p>[div class=&quot;boxsize width_60 break padleft-20&quot;]</p>content here<p>[/div]</p>' => '2 Columns 40 - 60',
	'<p>[div class=&quot;boxsize width_50 break padright-10&quot;]</p>content here<p>[/div]</p><p>[div class=&quot;boxsize width_50 break padleft-10&quot;]</p>content here<p>[/div]</p>' => '2 Columns 50 - 50',
	'<p>[div class=&quot;boxsize width_33 break&quot;]</p>content here<p>[/div]</p><p>[div class=&quot;boxsize width_33 break padleft-20&quot;]</p>content here<p>[/div]</p><p>[div class=&quot;boxsize width_33 break padleft-20&quot;]</p>content here<p>[/div]</p>' => '3 Columns 33 - 33 - 33',
	'<p>[div class=&quot;boxsize width_25 break&quot;]</p>content here<p>[/div]</p><p>[div class=&quot;boxsize width_25 break padleft-20&quot;]</p>content here<p>[/div]</p><p>[div class=&quot;boxsize width_25 break padleft-20&quot;]</p>content here<p>[/div]</p><p>[div class=&quot;boxsize width_25 break padleft-20&quot;]</p>content here<p>[/div]</p>' => '4 Columns 25 - 25 - 25 - 25',
	'<p>[div class=&quot;trans-whitebg-layer&quot;]</p><p>[div class=&quot;inner&quot;]</p>content here<p>[/div]</p><p>[/div]</p>' => 'Transparent White BG',
	'<p>[div class=&quot;trans-blackbg-layer&quot;]</p><p>[div class=&quot;inner&quot;]</p>content here<p>[/div]</p><p>[/div]</p>' => 'Transparent Black BG',
	];
	
$mediaobj = [
	'[videoplayer]' => 'Video Player',
	'[audioplayer]' => 'Audio Player',
	//'[photogallery]' => 'Photogallery',
	//'[sections]' => 'Content Sections',
	'[slideshow]' => 'Slide Show',
	//'[download]' => 'File Download',
	];
	
// get posts
$posts = posts()->where('published', 1)->pluck('title', 'id');
// get products
$prods = products()->where([['hidden', 0],['retired', 0]])->pluck('name', 'id');
// widgets
$widgetlist = widgets()->where('state', 1)->select('id','attribs')->get();
$widgets=[];
foreach($widgetlist as $widget) {
	$widgets[$widget->id] = json_decode($widget->attribs)->title;
}

?>

<form class="cmseform">
	<?php 
	// format
	fieldset(['start' => 1, 'slide' => 1, 'setlabel' => 'Formatting', 'info' => CMSE_TINYMCE_SHORTCODE_FORMATCODE, 'innerclass' => 'flexwrap']);
	field('select', 'preset', 'choose', $preset, 'Preset Format', ['id' => 'preset']);
	//field('text', 'css', '', '', 'Element Custom Style', ['id' => 'css', 'noflex' => 1]);
	fieldset(['end' => 1]);
	
	// media objects
	fieldset(['start' => 1, 'slide' => 1, 'setlabel' => 'Media Objects and Forms']);
	field('select', 'mediaobj', 'choose', $mediaobj, 'Media Objects', ['id' => 'mediaobj', 'class' => 'inlinefield-3']);
	field('text', 'gmap', '', '', 'Google Map', ['id' => 'gmap', 'placeholder' => '50 main st hartford ct', 'class' => 'inlinefield-3']);
	field('text', 'download', '', '', 'Download File', ['id' => 'download', 'class' => 'inlinefield-3', 'placeholder' => 'downloads/file.zip']);
	
	field('sep', 'separator');
	field('text', 'contact', '', '', 'Contact Form', ['id' => 'contact', 'placeholder' => 'info@domain.com', 'class' => 'inlinefield-3']);
	field('text', 'contactselect', '', '', 'Selector Options', ['id' => 'contactselect', 'placeholder' => 'department=&quot;Billing,Support&quot;', 'class' => 'inlinefield-3']);
	field('select', 'contactlabel', '', ['' => 'Show Labels', 'false' => 'No labels'], 'Field Labels', ['id' => 'contactlabel', 'class' => 'inlinefield-3']);
	
	field('sep', 'separator');
	field('text', 'counter', '', '', 'Countdown Clock Date', ['id' => 'counter', 'placeholder' => '05/23/2019', 'class' => 'inlinefield-3']);
	field('text', 'counterclass', '', '', 'Countdown Style Class', ['id' => 'counterclass', 'placeholder' => 'my-class otheclass', 'class' => 'inlinefield-3']);
	field('text', 'countermsg', '', '', 'Countdown End Message', ['id' => 'countermsg', 'placeholder' => 'The day is here!', 'class' => 'inlinefield-3']);
	fieldset(['end' => 1]);
	
	// related
	fieldset(['start' => 1, 'slide' => 1, 'setlabel' => 'Insert Related Posts, Products or Widgets', 'info' => CMSE_TINYMCE_SHORTCODE_RELITEM]);
	field('select', 'posts', 'choose', $posts, 'Posts', ['id' => 'posts', 'size' => 1, 'class' => 'inlinefield-3']);
	field('select', 'products', 'choose', $prods, 'Products', ['id' => 'products', 'size' => 1, 'class' => 'inlinefield-3']);
	field('sep', 'separator');
	field('select', 'widgets', 'choose', $widgets, 'Widgets', ['id' => 'widgets', 'size' => 1, 'class' => 'inlinefield-3']);
	field('select', 'widgettitle', '', [1 => 'Yes', 0 => 'No'], 'Disable Title',['id' => 'widgettitle', 'class' => 'inlinefield-3']);
	fieldset(['end' => 1]);
	
	// slide and tab
	fieldset(['start' => 1, 'slide' => 1, 'setlabel' => 'Tab and Slide', 'innerclass' => 'flexwrap', 'info' => CMSE_TINYMCE_SHORTCODE_TABSLIDE]);
	field('select', 'tabtype', '', ['slide' => 'Slide', 'tab' => 'Tab'], 'Type', ['id' => 'tabtype']);
	field('select', 'tabresponse', '', ['' => '-- Never --', 1024 => '1024', 980 => '980', 800 => '800', 480 => '480'], 'Screen Width', ['id' => 'tabresponse', 'showon' => 'tabtype:tab']);
	field('text', 'slidetab', '', '', 'Title', ['id' => 'slidetab']);
	fieldset(['end' => 1]);
	
	// popup window
	fieldset(['start' => 1, 'slide' => 1, 'setlabel' => 'Pop Up Window', 'info' => CMSE_TINYMCE_SHORTCODE_POPUP]);
	field('select', 'poptype', 'choose', ['mouseexit' => 'Exit Intent', 'onload' => 'Page Load'], 'Type', ['id' => 'poptype', 'class' => 'inlinefield-4']);
	field('number', 'popdelay', '', '', 'Delay', ['id' => 'popdelay', 'class' => 'inlinefield-4']);
	field('select', 'poponce', 'choose', ['true' => 'True', 'false' => 'False'], 'Show Once', ['id' => 'poponce', 'class' => 'inlinefield-4']);
	field('number', 'popexpire', '', '', 'Cookie Expiration', ['id' => 'popexpire', 'class' => 'inlinefield-4']);
	field('text', 'popclass', '', '', 'Class', ['id' => 'popclass']);
	field('textarea', 'poptext', '', '', 'Content', ['id' => 'poptext']);
	fieldset(['end' => 1]);
	?>
	

<script>
/*get the url src only from the iframe embed string entered*/
function getsrc(id) {
	var fld = document.getElementById(id);
	var src = fld.value;
	if( src.indexOf('<iframe') != -1 ) {
		fld.value = getInnerstring(src, 'src="', '"');
	}
}
</script>


<!-- end fields -->

<br style="clear: both;" />
	<button type="button" name="insertShortcode" onclick="insertCMSEshortcode()" class="btn btn-sm btn-info mce-close">Insert</button>
</form>

</body>
</html>