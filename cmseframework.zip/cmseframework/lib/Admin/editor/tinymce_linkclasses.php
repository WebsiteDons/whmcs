<?php
/*
* Copyright (c) 2019 Emuzement Net Inc. All Rights Reserved
* License: EULA
* Author: Alex/Kumar/Manti/Lisa
*/

include dirname(__DIR__,6).'/init.php';
if( !defined("WHMCS") ) die("This file cannot be accessed directly");

include_once ROOTDIR.'/modules/addons/cmseframework/functions.php';

$list = [
	['title' => 'None', 'value' => ''],
	['title' => 'Button', 'value' => 'btn'],
	['title' => 'Button Small', 'value' => 'btn-sm'],
	['title' => 'Large Button', 'value' => 'btn-lg'],
	['title' => 'Block Button', 'value' => 'btn-block'],
	['title' => 'Button Success', 'value' => 'btn-success'],
	['title' => 'Button Info', 'value' => 'btn-info'],
	['title' => 'Button Default', 'value' => 'btn-default'],
];

echo json_encode($list);

?>