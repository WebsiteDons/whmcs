<?php
/*
* Copyright (c) 2019 Emuzement Net Inc. All Rights Reserved
* License: EULA
* Author: Alex/Kumar/Manti/Lisa
*/

if( !defined("WHMCS") ) die("This file cannot be accessed directly");

use \WHMCS\Database\Capsule;
use \WHMCS\Session;

TIMEZONE;
$now = date('Y-m-d H:i:s');


// Save category to database
if( !is_null(getPost('save_config')) )
{
	$collection = [
		'admin_restrict'			=> getPost('admin_restrict', false),
		'permissions'				=> getPost('permissions', false),
		'imagesfolder'				=> getPost('imagesfolder'),
		'maxupload'					=> getPost('maxupload', false),
		'listslimit'				=> getPost('listslimit', false),
		'local_timezone'			=> getPost('local_timezone', false),
		
		'prod_wysiwyg'				=> getPost('prod_wysiwyg', false),
		'targetattrib'				=> getPost('targetattrib', false),
		'product_detail'			=> getPost('product_detail', false),

		'sitename_title'			=> getPost('sitename_title', false),
		'sitename_title_pos'		=> getPost('sitename_title_pos', false),
		'sitename_title_sep'		=> getPost('sitename_title_sep'),
		'meta_keywords'				=> getPost('meta_keywords'),
		'meta_description'			=> getPost('meta_description'),
		'headtags'					=> getPost('headtags'),
		'favicon'					=> getPost('favicon'),
		
		'ogmeta'					=> getPost('og_meta', false),
		'socialapi'					=> getPost('socialapi', false),
		'fbpage'					=> getPost('fbpage'),
		'fbappid'					=> getPost('fbappid'),
		'sharebtn'					=> getPost('sharebtn', false),
		'default_social_img'		=> getPost('default_social_img'),
		'head_scripts'				=> getPost('head_scripts', false),
		'foot_scripts'				=> getPost('foot_scripts', false),
		'allowedfiles'				=> getPost('allowedfiles', false),
		'editable'					=> getPost('editable', false),
		
		// All Categories View
		'allcatpreset'				=> getPost('allcatpreset', false),
		'catcolumns'				=> getPost('catcolumns'),
		'catimgmask'				=> getPost('catimgmask'),
		'cattextlimit'				=> getPost('cattextlimit'),
		'allcat_layout'				=> getPost('allcat_layout'),
		
		// Category View
		'catpreset'					=> getPost('catpreset', false),
		'postcolumns'				=> getPost('postcolumns'),
		'postimgmask'				=> getPost('postimgmask'),
		'posttextlimit'				=> getPost('posttextlimit'),
		'itemsperpage'				=> getPost('itemsperpage'),
		'catlayout'					=> getPost('catlayout'),
		'catpostlayout'				=> getPost('catpostlayout'),
		
		// Post View
		'postpreset'				=> getPost('postpreset', false),
		'layout'					=> getPost('layout'),
		
		// Product Group View
		'grouppreset'				=> getPost('grouppreset', false),
		'prodcolumns'				=> getPost('prodcolumns'),
		'prodimgmask'				=> getPost('prodimgmask'),
		'prodtextlimit'				=> getPost('prodtextlimit'),
		'group_detailslayout'		=> getPost('group_detailslayout'),
		'group_layout'				=> getPost('group_layout'),
		
		// Product Detail View
		'productpreset'				=> getPost('productpreset', false),
		'product_layout'			=> getPost('product_layout'),
		'cart_layout'				=> getPost('cart_layout'),
		
		// cmse texts
		'cmse_texts'				=> getPost('cmse_texts')
	];

	// update category
	try{
	globalconfig()
	->where([['module', MODNAME],['setting', 'configs']])
	->update(['value' => json_encode($collection)]);
	} catch (\Exception $e) {
		cmseNotice($e->getMessage());
	}

	// install TinyMCE image manager plugin
	if( !file_exists(ROOT_PATH.'assets/js/tinymce/plugins/responsivefilemanager') ) {
		copyAll(MODPATH.'/_copyfiles/responsivefilemanager', ROOT_PATH.'assets/js/tinymce/plugins/responsivefilemanager');
	}
	
	
	// record updates in mod_cmse_sys table
	try{
	getDbo('mod_cmse_sys')
	->insertGetId(['type' => 'Global Configuration', 'updated_at' => $now, 'admin' => Session::get('adminid')]);
	} catch (\Exception $e) {
		cmseNotice($e->getMessage());
	}

	redirect($modlink.'&view=configs&itemsaved=1');

}

// Social share API
$socialapi = [
'fb' => 'Facebook',
'twit' => 'Twitter',
'ig' => 'Instagram',
'gplus' => 'Google+',
'pin' => 'Pinterest'
];

// Social share buttons
$sharebtn = [
'fb' => 'Facebook',
'twit' => 'Twitter',
'gplus' => 'Google+',
'ig' => 'Instagram',
'pin' => 'Pinterest',
'tum' => 'Tumblr',
'red' => 'Reddit',
'xing' => 'Xing',
'eml' => 'Email'
];

// file upload
$allowedfiles = [
'html' => 'HTML',
'xhtml' => 'XHTML',
'phtml' => 'PHTML',
'css' => 'CSS',
'scss' => 'SCSS',
'js' => 'JS',
'txt' => 'TXT',
'php' => 'PHP',
'doc' => 'DOC',
'docx' => 'DOCX',
'xls' => 'XLS',
'xlsx' => 'XLSX',
'pdf' => 'PDF',
'csv' => 'CSV',
'log' => 'LOG',
'rtf' => 'RTF',
'xml' => 'XML',
'yaml' => 'YAML',
'psd' => 'PSD',
'sql' => 'SQL',
'ppt' => 'PPT',
'pptx' => 'PPTX',
'odt' => 'ODT',
'ott' => 'OTT',
'ots' => 'OTS',
];

$editable = [
'txt', 'log', 'xml', 'html', 'css', 'htm', 'js'
];


// Load Preset Format
$matches = layoutPreset();

$permissions = [
'configs' => 'Configuration',
'languageManager' => 'Language Manager',
'templateManager' => 'Template Manager',
'installer' => 'Installer',
'post' => 'Posts Manager',
'menuManager' => 'Menu Manager',
'widgetManager' => 'Widget Manager',
'bannerManager' => 'Banner Manager'
];

$admins = getDbo('tbladmins')->where('disabled', 0)->pluck('username', 'id');


?>


	<div>
	<div class="boxsize width_50 break">
	
		<!-- Admin Permissions -->
		<fieldset class="groupslide check-btn">
			<h5 class="slidetab"><span class="title">Administrator Permissions</span></h5>
			<div class="slidecontent">
			
			<h6><?php echo CMSE_CONFIG_LBL_ADMIN_RESTRICT; ?></h6>
			<small class="info"><?php echo CMSE_CONFIG_INFO_ADMIN_RESTRICT; ?></small>
				<select name="admin_restrict[]" size="1" multiple>
				<?php foreach($admins as $key => $val) { 
					$selected = [];
					foreach(modConfigs()->admin_restrict as $isadmin) {
						$selected[] = ($key == $isadmin ? ' selected' : '');
					}
				?>
					<option value="<?php echo $key; ?>"<?php echo implode('', $selected); ?>><?php echo $val; ?></option>
				<?php } ?>
				</select>
			<hr />
			
			<h6>Restricted Areas</h6>
				<small class="info">The areas you select will be acceessible only by the above selected administrators.</small>
				<select name="permissions[]" size="1" multiple>
				<?php foreach($permissions as $key => $val) { 
					$selected = [];
					foreach(modConfigs()->permissions as $perm) {
						$selected[] = ($key == $perm ? ' selected' : '');
					}
				?>
					<option value="<?php echo $key; ?>"<?php echo implode('', $selected); ?>><?php echo $val; ?></option>
				<?php } ?>
				</select>
				<hr />
				
			</div>
		</fieldset>
			
		<!-- General -->
		<fieldset class="groupslide check-btn">
			<h5 class="slidetab"><span class="title">General Setup</span></h5>
			<div class="slidecontent">
			
			<div class="flex">
				<div class="width_50">
				<h6><?php echo CMSE_CONFIG_LBL_IMG_DIR; ?></h6>
				<small class="info"><?php echo CMSE_CONFIG_IMG_DIR; ?></small>
					<span>
					<input type="text" name="imagesfolder" value="<?php echo getConfigVal('imagesfolder'); ?>" class="form-control" placeholder="images" />
					</span>
				</div>
				
				<div class="width_50 padleft-20">
				<h6><?php echo CMSE_CONFIG_LBL_MAX_UPL; ?></h6>
				<small class="info"><?php echo CMSE_CONFIG_DESC_MAX_UPL; ?></small>
					<span>
					<input type="number" name="maxupload" value="<?php echo getConfigVal('maxupload', '', 800); ?>" class="form-control" placeholder="800" />
					</span>
				</div>
			</div>
			<hr />
			
			<h6>Install TinyMCE Image Manager Plugin</h6>
			<small class="info"><?php echo CMSE_INSTALL_IMAGEMANAGER; ?></small>
			<label>
				<span>
				<input type="checkbox" name="install_imgmanager" value="1" <?php echo (file_exists(ROOT_PATH.'assets/js/tinymce/plugins/responsivefilemanager') ? 'checked' : ''); ?> />
				</span>
				<span class="install"></span>
			</label>
			<hr />
			
			<h6>Use WYSIWYG In Product Description</h6>
			<small class="info"><?php echo CMSE_PRODUCT_DESC_WYSIWYG; ?></small>
			<label>
				<span>
				<input type="checkbox" name="prod_wysiwyg" value="1" <?php echo getConfigVal('prod_wysiwyg', true); ?> />
				</span>
				<span class="enable"></span>
			</label>
			<hr />
			
			<h6>Enable Product Detail Page</h6>
				<small class="info"><?php echo CMSE_PRODUCT_IMAGE_ENABLED; ?></small>
				<label>
					<span>
					<input type="checkbox" name="product_detail" value="1" <?php echo getConfigVal('product_detail', true); ?> />
					</span>
					<span class="enable"></span>
				</label>
				<hr />
			
			
			<h6><?php echo CMSE_CONFIG_LBL_TIMEZONE; ?></h6>
			<small class="info"><?php echo CMSE_CONFIG_DESC_TIMEZONE; echo date_default_timezone_get(); ?></small>
			<select name="local_timezone" size="1" data-placeholder="Set local timezone">
			<?php include 'resource/tz.php';
			foreach($tz as $key => $val) {
				$selected = getConfigVal('local_timezone', '', 'America/New_York', $val);
			?>
			<option value="<?php echo $val; ?>" <?php echo $selected; ?>><?php echo $val; ?></option>
			<?php } ?>
			</select>
			<hr />
			
			<h6>Lists Limit</h6>
			<small class="info">Set the limit for list results per page in the admin area to define when the pagination is in use</small>
			<span>
			<input type="number" name="listslimit" value="<?php echo getConfigVal('listslimit'); ?>" class="form-control" />
			</span>
			<hr />
			
			<h6>Add target attribute to Login As Client link to open in new window</h6>
			<label>
				<span>
				<input type="checkbox" name="targetattrib" value="1" <?php echo getConfigVal('targetattrib', true); ?> />
				</span>
				<span class="enable"></span>
			</label>
			
			</div>
		</fieldset>
	
		
		
		<!-- Custom Head Tags -->
		<fieldset class="groupslide check-btn">
			<h5 class="slidetab"><span class="title">Custom Head Tags</span></h5>
			<div class="slidecontent">
				<h6>Browser Title</h6>
				<small class="info">This replaces the core browser title method. Show company name in title. Set the position for the company name in accordance with the page title. Enter a separator character in the text field</small>
				<label>
					<span>
					<input type="checkbox" name="sitename_title" value="1" <?php echo getConfigVal('sitename_title', true); ?> />
					</span>
					<span class="enable"></span>
				</label>

				<label>
					<span>
					<input type="checkbox" name="sitename_title_pos" value="1" <?php echo getConfigVal('sitename_title_pos', true); ?> />
					</span>
					<span class="title-position"></span>
				</label>
				
				<div class="inlineblock">
				<input type="text" name="sitename_title_sep" value="<?php echo getConfigVal('sitename_title_sep'); ?>" placeholder="separator" class="form-control monospace" /> 
				</div>
				<hr />
				
				<small class="info">Fill meta values for any page which has no description or keywords set</small>
				<div class="flex">
					<div class="width_50">
						<h6>Meta Keywords</h6>
						<textarea name="meta_keywords"><?php echo getConfigVal('meta_keywords'); ?></textarea>
					</div>
					<div class="width_50 padleft-20">
						<h6>Meta Description</h6>
						<textarea name="meta_description"><?php echo getConfigVal('meta_description'); ?></textarea>
					</div>
				</div>
				<hr />
				
				<small class="info">Tags within the &lt;head&gt;. Add one tag per new line. Only self closing tags.</small>
				<textarea class="autosize form-control monospace" name="headtags" placeholder='link rel="apple-touch-icon" href="/apple-touch-icon.png"'><?php echo getConfigVal('headtags'); ?></textarea>
				<hr />
				
				<h6>FavIcon</h6>
				<small class="info">The icon which is displayed in the browser bar. The url is relative to WHMCS root. File types: .ICO, .PNG (recommended), .GIF</small>
				<input type="text" name="favicon" size="40" value="<?php echo getConfigVal('favicon'); ?>" placeholder="images/assets/favicon.png" class="form-control monospace" />
			</div>
		</fieldset>
		
		<!-- Social Media Sharing -->
		<fieldset class="groupslide check-btn">
			<h5 class="slidetab"><span class="title">Social Media Sharing</span></h5>
			<div class="slidecontent">
				<h6>Enable Open Graph Meta Tags</h6>
				<small class="info"><?php echo CMSE_SOCIALSHARE_META_TAGS; ?></small>
				<label>
					<span>
					<input type="checkbox" name="og_meta[og]" value="1" <?php echo getConfigVal('ogmeta,og', true); ?> />
					</span>
					<span class="enable"></span>
				</label>
				<hr />
				
				<div class="flex">
					<div class="width_50">
						<h6>Social Network API Libraries</h6>
						<small class="info">Library scripts to allow page sharing, feeds etc</small>
						<select name="socialapi[]" size="1" multiple>
						<?php foreach($socialapi as $key => $val) { 
							$selected = [];
							foreach(modConfigs()->socialapi as $ssapi) {
								$selected[] = ($key == $ssapi ? ' selected' : '');
							}
						?>
							<option value="<?php echo $key; ?>"<?php echo implode('', $selected); ?>><?php echo $val; ?></option>
						<?php } ?>
						</select>
					</div>
					
					<div class="width_50 padleft-20">
						<h6>Social Network Share</h6>
						<small class="info">Enable social share buttons</small>
						<select name="sharebtn[]" size="1" multiple>
						<?php foreach($sharebtn as $key => $val) { 
							$selected = [];
							foreach(modConfigs()->sharebtn as $ssbtn) {
								$selected[] = ($key == $ssbtn ? ' selected' : '');
							}
						?>
							<option value="<?php echo $key; ?>"<?php echo implode('', $selected); ?>><?php echo $val; ?></option>
						<?php } ?>
						</select>
					</div>
				</div>
				<hr />

				<fieldset class="inlineblock width_50">
				<h6>Facebook Page Name</h6>
				<input type="text" name="fbpage" value="<?php echo getConfigVal('fbpage'); ?>" class="form-control" placeholder="ex: mygreatpage" />
				</fieldset>

				<fieldset class="inlineblock width_50">
				<h6>Facebook App ID</h6>
				<input type="text" name="fbappid" value="<?php echo getConfigVal('fbappid'); ?>" class="form-control" placeholder="ex: 95546396754" />
				</fieldset>
				<hr />

				
				
				
				<h6>Default Social Share Image</h6>
				<small class="info">This image will be used as the poster when pages are shared at social media. 
				If an image is assiged to a post or product page, that will be used instead. Relative or absolute URL accepted.</small>
				<input type="text" name="default_social_img" value="<?php echo getConfigVal('default_social_img'); ?>" class="form-control" placeholder="images/default.jpg" />
			</div>
		</fieldset>
		
		<!-- Custom Scripts -->
		<?php 
		if( fullAdmin(Session::get('adminid')) && Session::get('adminid') == 1 ) { ?>
		<fieldset class="groupslide">
			<h5 class="slidetab"><span class="title">Custom Scripting</span></h5>
			<div class="slidecontent">
			<small class="info">Insert custom Javascript or CSS in the head tags or at the end of the HTML document. EG: visitor tracking, Google adwords or adsense etc.</small>
				<h6>Head Scripts</h6>
				<textarea name="head_scripts" class="autosize form-control monospace" placeholder="<?php echo CMSE_CONFIG_HINT_HEAD_SCRIPT; ?>"><?php echo getConfigVal('head_scripts'); ?></textarea>
				<h6>Foot Scripts</h6>
				<textarea name="foot_scripts" class="autosize form-control monospace"><?php echo getConfigVal('foot_scripts'); ?></textarea>
			</div>
		</fieldset>
		
		<fieldset class="groupslide">
			<h5 class="slidetab"><span class="title">Image Manager</span></h5>
			<div class="slidecontent">
			<small class="info"></small>
				<h6>Allowed File Upload</h6>
				<select name="allowedfiles[]" size="1" multiple>
				<?php foreach($allowedfiles as $key => $val) { 
					$selected = [];
					foreach(modConfigs()->allowedfiles as $allowed) {
						$selected[] = ($key == $allowed ? ' selected' : '');
					}
				?>
					<option value="<?php echo $key; ?>"<?php echo implode('', $selected); ?>><?php echo $val; ?></option>
				<?php } ?>
				</select>
				<hr />
				
				<h6>Allowed Editable Files</h6>
				<select name="editable[]" size="1" multiple>
				<?php foreach($editable as $val) { 
					$selected = [];
					foreach(modConfigs()->editable as $allowedit) {
						$selected[] = ($val == $allowedit ? ' selected' : '');
					}
				?>
					<option value="<?php echo $val; ?>"<?php echo implode('', $selected); ?>><?php echo strtoupper($val); ?></option>
				<?php } ?>
				</select>
			</div>
		</fieldset>
		
		<?php } ?>
	</div>


	<!-- Right Column -->
	<div class="boxsize width_50 padleft-20 break">

		<!-- Post Categories Layout -->
		<fieldset class="groupslide">
			<h5 class="slidetab"><span class="title">Post Categories View Layout</span></h5>
			<div class="slidecontent">
				<div class="tablecells">
					<div>
					<h6>Preset Formats</h6>
					<select name="allcatpreset">
						<?php 
						foreach($matches as $match) { 
							//include strings beginning with any 
							if( !preg_match(chr(1).'^allcat'.chr(1), $match[1]) ) 
								continue;
							
							$selected = getConfigVal('allcatpreset', '', '', $match[1]);
						?>
						<option value="<?php echo $match[1]; ?>"><?php echo $match[1]; ?></option>
						<?php } ?>
					</select>
					</div>
					<div>
						<h6>Columns</h6>
						<input type="number" name="catcolumns" min="1" value="<?php echo getConfigVal('catcolumns'); ?>" />
					</div>
					<div>
						<h6>Image Height</h6>
						<input type="number" name="catimgmask" min="0" value="<?php echo getConfigVal('catimgmask'); ?>" />
					</div>
					<div>
						<h6>Text Limit</h6>
						<input type="number" name="cattextlimit" min="0" value="<?php echo getConfigVal('cattextlimit'); ?>" />
					</div>
				</div>
				<hr />
				<h6>Layout</h6>
				<textarea class="autosize monospace" name="allcat_layout"><?php echo getConfigVal('allcat_layout'); ?></textarea>
				
			</div>
		</fieldset>
		
		<!-- Post Category View Layout -->
		<fieldset class="groupslide">
			<h5 class="slidetab"><span class="title">Posts Category View Layout</span></h5>
			<div class="slidecontent">
				<small class="info">Arrange the place holders to display category objects</small>
				
				<div class="tablecells">
					<div>
						<h6>Preset Formats</h6>
						<select name="catpreset">
							<?php 
							foreach($matches as $match) { 
								//include strings beginning with any 
								if( !preg_match(chr(1).'^cat-items'.chr(1), $match[1]) ) 
									continue;
								
								$selected = getConfigVal('catpreset', '', '', $match[1]);
							?>
							<option value="<?php echo $match[1]; ?>"<?php echo $selected; ?>><?php echo $match[1]; ?></option>
							<?php } ?>
						</select>
					</div>
				
					<div>
						<label>Columns</label>
						<input type="number" name="postcolumns" min="1" value="<?php echo getConfigVal('postcolumns'); ?>" />
					</div>
					<div>
						<label>Items Per Page</label>
						<input type="number" name="itemsperpage" min="0" value="<?php echo getConfigVal('itemsperpage'); ?>" />
					</div>
				</div>
				<hr />
				
				<h6>Layout</h6>
				<textarea class="monospace" name="catlayout" rows="1" placeholder="eg: [image][title][text]"><?php echo getConfigVal('catlayout'); ?></textarea>
				<hr />
				
				<h4>Items Layout In Category View</h4>
				<div class="tablecells">
					<div>
						<label>Item Image Height</label>
						<input type="number" name="postimgmask" min="0" value="<?php echo getConfigVal('postimgmask'); ?>" />
					</div>
					<div>
						<label>Text Limit</label>
						<input type="number" name="posttextlimit" min="0" value="<?php echo getConfigVal('posttextlimit'); ?>" />
					</div>
				</div>
				<textarea class="autosize monospace" name="catpostlayout" placeholder="eg: [image][title][text]"><?php echo getConfigVal('catpostlayout'); ?></textarea>
			</div>
		</fieldset>

		<fieldset class="groupslide">
			<h5 class="slidetab"><span class="title">Post View Layout</span></h5>
			<div class="slidecontent">
				<small class="info">Arrange the place holders to display content objects</small>
				
				<h6>Preset Formats</h6>
				<select name="postpreset">
					<?php 
					foreach($matches as $match) { 
						//include strings beginning with any 
						if( !preg_match(chr(1).'^post'.chr(1), $match[1]) ) 
							continue;
						
						$selected = getConfigVal('postpreset', '', '', $match[1]);
					?>
					<option value="<?php echo $match[1]; ?>"<?php echo $selected; ?>><?php echo $match[1]; ?></option>
					<?php } ?>
				</select>
				<hr />
				<textarea class="autosize monospace" name="layout"><?php echo getConfigVal('layout'); ?></textarea>
			</div>
		</fieldset>

		<!-- WHMCS Product Group Layout -->
		<fieldset class="groupslide">
			<h5 class="slidetab"><span class="title">WHMCS Product Caregory View Layout</span></h5>
			<div class="slidecontent">
				<small class="info">Arrange the place holders to display content objects</small>
				
				<div class="tablecells">
					<div>
					<label>Preset Formats</label>
					<select name="grouppreset">
						<?php 
						foreach($matches as $match) { 
							//include strings beginning with any 
							if( !preg_match(chr(1).'^group'.chr(1), $match[1]) ) 
								continue;
							
							$selected = getConfigVal('grouppreset', '', '', $match[1]);
						?>
						<option value="<?php echo $match[1]; ?>"<?php echo $selected; ?>><?php echo $match[1]; ?></option>
						<?php } ?>
					</select>
					</div>
					<div>
						<label>Columns</label>
						<input type="number" name="prodcolumns" min="1" value="<?php echo getConfigVal('prodcolumns'); ?>" />
					</div>
					<div>
						<label>Item Image Height</label>
						<input type="number" name="prodimgmask" min="0" value="<?php echo getConfigVal('prodimgmask'); ?>" />
					</div>
					<div>
						<label>Text Limit</label>
						<input type="number" name="prodtextlimit" min="0" value="<?php echo getConfigVal('prodtextlimit'); ?>" />
					</div>
				</div>
				<hr />
				
				<h6>Group Details Layout</h6>
				<textarea class="autosize monospace" name="group_detailslayout"><?php echo getConfigVal('group_detailslayout'); ?></textarea>
				<hr />
				
				<h6>Each Item Layout In Group View</h6>
				<textarea class="autosize monospace" name="group_layout"><?php echo getConfigVal('group_layout'); ?></textarea>
			</div>
		</fieldset>
		
		<!-- WHMCS Product Detail Layout -->
		<fieldset class="groupslide">
			<h5 class="slidetab"><span class="title">WHMCS Product Detail Layout</span></h5>
			<div class="slidecontent">
			<h6>Preset Formats</h6>
				<select name="productpreset">
					<?php 
					foreach($matches as $match) { 
						//include strings beginning with any 
						if( !preg_match(chr(1).'^product'.chr(1), $match[1]) ) 
							continue;
						
						$selected = getConfigVal('productpreset', '', '', $match[1]);
					?>
					<option value="<?php echo $match[1]; ?>"<?php echo $selected; ?>><?php echo $match[1]; ?></option>
					<?php } ?>
				</select>
				<hr />
				<small class="info">Arrange the place holders to display content objects</small>
				<textarea class="autosize monospace" name="product_layout"><?php echo getConfigVal('product_layout'); ?></textarea>
				<hr />
				
				<h6>Cart View</h6>
				<textarea class="autosize monospace" name="cart_layout"><?php echo getConfigVal('cart_layout'); ?></textarea>
			
			</div>
		</fieldset>
		
		<!-- Text MAnagement -->
		<fieldset class="groupslide">
			<h5 class="slidetab"><span class="title">CMSE CF Language Management</span></h5>
			<div class="slidecontent">
				<small class="info">Manage texts associated with CMSE Framework.</small>
				<textarea class="autosize monospace" name="cmse_texts"><?php echo getConfigVal('cmse_texts'); ?></textarea>
			</div>
		</fieldset>
		<!-- /Layoyt Groups -->
		
	</div>
	
	<div class="clearall"></div>
	</div>
