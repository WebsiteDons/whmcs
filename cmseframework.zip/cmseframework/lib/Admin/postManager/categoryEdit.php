<?php
/*
* Copyright (c) 2019 Emuzement Net Inc. All Rights Reserved
* License: EULA
* Author: Alex/Kumar/Manti/Lisa
*/

if( !defined("WHMCS") ) die("This file cannot be accessed directly");

use \WHMCS\Session;

$action		= $modlink.'&view=postManager&task=';
$firstsave	= $action.'edit&type=category&catid=';
$saveedit	= $action.'edit&type=category&catid='.getRequest('catid').'&itemsaved=1';
$savenew	= $action.'edit&type=category';
$saveclose	= $action.'list&type=categories';

$formats = ['list' => 'List', 'grid' => 'Grid', 'lead' => 'Lead', 'leadside' => 'Lead Side Panel'];
$cols = 1;
$imgmask='';
$textlimit='';

TIMEZONE;
$now 		= date('Y-m-d H:i:s');


// Get category values if exist
$edit = getRequest('catid', 'ifset');
$cat_title= $cat_alias= $catimg= $catimage= '';
if( $edit )
{
	$cid		= (int)getRequest('catid');
	// get category data
	$cat_title	= catData($cid)->title;
	$cat_alias	= catData($cid)->alias;
	$cat_desc	= catData($cid)->description;
	$state		= catData($cid)->state;
	$sortorder	= catData($cid)->sortorder;

	$catconfig	= json_decode(catData($cid)->configs);
	$cols = $catconfig->itemscolumns;
	$imgmask = $catconfig->imgmask;
	$textlimit = $catconfig->textlimit;
	$itemcount = $catconfig->itemcount;
	$showinlist = $catconfig->showinlist;
	$metadesc = $catconfig->metadesc;
	$metakeys = $catconfig->metakeys;
	$widetitle = $catconfig->widetitle;

	if( $catconfig->catimage != '' ) {
		$catimg = $catconfig->catimage;
		$catimage = '<img src="'.IMAGES.$catconfig->catimage.'" />';
	}

	$pagetitle	= 'Edit Category';
	
	// get template assigned
	$tmplset = tplassign()
		->where([['type', 'category'],['resource', getRequest('catid')]])
		->select('id', 'tmpl_id', 'resource')
		->get()[0];
}

if( !$edit ) {
	$created = $now;
	$update = '';
	$updateauthor='';
}else{
	$created = catData($cid)->created_at;
	$update = $now;
	$updateauthor = Session::get('adminid');
}

// Save category to database
if( !is_null(getPost('saveitem', false)) || !is_null(getPost('savenew', false)) || !is_null(getPost('saveclose', false)) )
{
	// set JSON for category configuration
	$collection = [
	'metadesc'			=> strip_tags(getPost('metadesc')),
	'metakeys'			=> strip_tags(getPost('metakeys')),
	'customcss' 		=> getPost('custom_css'),
	'customjs' 			=> getPost('custom_js'),
	'allcat_layout' 	=> getPost('allcat_layout'),
	'cat_layout' 		=> getPost('cat_layout'),
	'cat_items_layout'	=> getPost('cat_items_layout'),
	'textlimit'			=> getPost('textlimit'),
	'item_layout'		=> getPost('item_layout'),
	'catimage'			=> getPost('catimage', false),
	'itemscolumns'		=> getPost('itemscolumns'),
	'itemsformat'		=> getPost('itemsformat', false),
	'imgmask'			=> getPost('imgmask'),
	'showinlist'		=> getPost('showinlist', false),
	'itemcount'			=> getPost('itemcount'),
	'css_class'			=> getPost('css_class'),
	'catpreset'			=> getPost('catpreset', false),
	'widetitle'			=> getPost('widetitle', false),
	'wideimage'			=> getPost('wideimage', false)
	];
	
	$viewaccess = [
	'access'		=> getPost('access', false), 
	'cg'			=> getPost('cg', false), 
	'no_access_msg' => getPost('no_access_msg')
	];
	
	// write alias from title if field is empty
	if( empty(getPost('cat_alias')) ) {
		$alias = makeAlias('cat_title');
	}else{
		$alias = cleanChars(getPost('cat_alias'), '', '', true);
	}

	$fields = [
	'title'			=> getPost('cat_title'),
	'alias'			=> $alias,
	'description'	=> getPost('cat_description', false),
	'configs'		=> json_encode($collection),
	'access'		=> json_encode($viewaccess),
	'state'			=> getPost('state', false),
	'sortorder'		=> getPost('sortorder'),
	'type'			=> 'post',
	'created_at'	=> $created,
	'updated_at'	=> $update,
	'author'		=> Session::get('adminid'),
	'update_author'	=> $updateauthor
	];
	
	

	if( !$edit )
	{
		// save category
		try{
			$cid = categories()->insertGetId($fields);
		} catch (\Exception $e) {
			cmseNotice($e->getMessage());
		}
		
		// save template assignment if set
		if( getPost('assign_template', false) != '' ) 
		{
			$tmpl = [
			'tmpl_id' => getPost('assign_template', false),
			'resource' => $cid,
			'type' => 'category',
			'created_at' => setDate()
			];
			try{
				tplassign()->insertGetId($tmpl);
			} catch (\Exception $e) {
				cmseNotice($e->getMessage());
			}
		}
		
		if( !is_null(getPost('saveitem', false)) && !empty($cid) ) {
			redirect($firstsave.$cid.'&itemsaved=1');
		}else
		if( !is_null(getPost('savenew', false)) ) {
			redirect($savenew);
		}else
		if( !is_null(getPost('saveclose', false)) ) {
			redirect($saveclose);
		}
	}else{
		// update category
		try{
			categories()->where('id', (int)getRequest('catid', false))->update($fields);
		} catch (\Exception $e) {
			cmseNotice($e->getMessage());
		}
		
		// update template assignment if set or changed
		if( getPost('assign_template', false) != '' ) 
		{
			if( isset($tmplset->resource) && $tmplset->resource == getRequest('catid') ) 
			{
				if( $tmplset->tmpl_id != getPost('assign_template', false) ) 
				{
					$tmpl = [
					'tmpl_id' => getPost('assign_template', false),
					'updated_at' => setDate()
					];
					try{
						tplassign()->where('id', $tmplset->id)->update($tmpl);
					} catch (\Exception $e) {
						cmseNotice($e->getMessage());
					}
				}
			}else{
				$tmpl = [
				'tmpl_id' => getPost('assign_template', false),
				'resource' => (int)getRequest('catid', false),
				'type' => 'category',
				'created_at' => setDate()
				];
				try{
					tplassign()->insertGetId($tmpl);
				} catch (\Exception $e) {
					cmseNotice($e->getMessage());
				}
			}
		}else
		// delete the row when set to default template
		if( $tmplset->resource == getRequest('catid') ) {
			try{
				tplassign()->where([['resource', getRequest('catid')],['type', 'category']])->delete();
			} catch (\Exception $e) {
				cmseNotice($e->getMessage());
			}
		}
		
		// redirect
		if( !is_null(getPost('saveitem', false)) ) {
			redirect($saveedit);
		}else
		if( !is_null(getPost('savenew', false)) ) {
			redirect($savenew);
		}else
		if( !is_null(getPost('saveclose', false)) ) {
			redirect($saveclose);
		}
	}
}

// get layout preset
$matches = layoutPreset();

// field($type, $name, $value='', $options=[], $label='', $attribs=[], $info='')
?>

<h2><?php echo $pagetitle; ?></h2>

	<div class="clearall">
		<div class="clearall">
			<div class="boxsize width_70 break">
				<fieldset class="flex wrap">
				<?php 
				field('text', 'cat_title', $cat_title, '', '', ['placeholder' => '*Title', 'required' => 'required', 'class' => 'inlineblock width_50 aligntop']); 
				field('text', 'cat_alias', $cat_alias, '', '', ['class' => 'aliasfield', 'fieldclass' => 'tint', 'placeholder' => POSTS_FIELD_ALIAS_HINT]);
				?>
				</fieldset>
				<fieldset class="flex wrap">
				<?php
				field('textarea', 'metadesc', $metadesc, '', 'Meta Description', ['class' => '']);
				field('textarea', 'metakeys', $metakeys, '', 'Meta Keywords', ['class' => '']);
				?>
				</fieldset>

				<fieldset style="padding-right: 5px;">
					<textarea name="cat_description" id="wysiwyg" placeholder="category description"><?php echo $cat_desc; ?></textarea>
				</fieldset>
				
				<!-- Bottom Fields -->
			<fieldset class="groupslide">
				<h5 class="slidetab"><span class="title">Category View Layout</span></h5>
				<div class="slidecontent">
				<small class="info"><?php echo CMSE_POST_CAT_INFO_CAT_LAYOUT; ?></small>
				<h4>Layout Of Category Title, Image and Description</h4>
				<div class="tablecells">
					<div>
					<h6>Preset Formats</h6>
						<select name="catpreset">
						<option value="">-- Use Default --</option>
							<?php 
							foreach($matches as $match) { 
								//include strings beginning with any 
								if( !preg_match(chr(1).'^cat-items'.chr(1), $match[1]) ) 
									continue;
								
								$selected = ($match[1] == $catconfig->catpreset ? ' selected' : '');
							?>
							<option value="<?php echo $match[1]; ?>"<?php echo $selected; ?>><?php echo $match[1]; ?></option>
							<?php } ?>
						</select>
					</div>
					
					<div>
						<h6>Columns</h6>
						<input type="number" name="itemscolumns" min="1" value="<?php echo $cols; ?>" />
					</div>
					<div>
						<h6>Item Count</h6>
						<input type="number" name="itemcount" min="1" value="<?php echo $itemcount; ?>" />
					</div>
					<?php field('select', 'widetitle', $widetitle, ['' => '-- Use Default --', 1 => 'Yes', 2 => 'As Layer'], 'Wide Title'); ?>
				</div>
				<hr />
				
				<textarea name="cat_layout" rows="1" class="monospace"><?php echo $catconfig->cat_layout; ?></textarea>
				
				<h4>Layout Of Each Item In Category View</h4>
				<div class="tablecells">
					<div>
						<h6>Image Height</h6>
						<input type="number" name="imgmask" min="0" value="<?php echo $imgmask; ?>" />
					</div>
					<div>
						<h6>Text Limit</h6>
						<input type="number" name="textlimit" min="0" value="<?php echo $textlimit; ?>" />
					</div>
				</div>
				<hr />

				<textarea name="cat_items_layout" class="autosize"><?php echo $catconfig->cat_items_layout; ?></textarea>
				</div>
			</fieldset>

				<fieldset class="groupslide">
					<h5 class="slidetab"><span class="title">Item View Layout</span></h5>
					<div class="slidecontent">
						<div class="tablecells">
						<div>
							<small class="info"><?php echo CMSE_POST_CAT_INFO_POST_LAYOUT; ?></small>
							<h6>Preset Formats</h6>
							<select name="postpreset">
								<option value="">-- Use Default --</option>
								<?php 
								foreach($matches as $match) { 
									//include strings beginning with any 
									if( !preg_match(chr(1).'^post'.chr(1), $match[1]) ) 
										continue;
								?>
								<option value="<?php echo $match[1]; ?>"><?php echo $match[1]; ?></option>
								<?php } ?>
							</select>
						</div>
						</div>
						<hr />
						
						<textarea name="item_layout" class="autosize monospace"><?php echo $catconfig->item_layout; ?></textarea>
					</div>
				</fieldset>

				<fieldset class="groupslide">
					<h5 class="slidetab"><span class="title">Custom CSS</span></h5>
					<div class="slidecontent">
						<textarea name="custom_css" class="autosize" placeholder=".post-item {background: #ffcc00;}"><?php echo $catconfig->customcss; ?></textarea>
					</div>
				</fieldset>

				<fieldset class="groupslide">
					<h5 class="slidecontent"><span class="title">Custom JavaScript</span></h5>
					<div class="slidecontent">
						<textarea name="custom_js" class="autosize" placeholder="jQuery(function($) {stuff to execute});"><?php echo $catconfig->customjs; ?></textarea>
					</div>
				</fieldset>
			</div>
			
			<!-- Right Column -->
			<div class="boxsize width_30 break padleft-20 sidefields">
				<fieldset>
					<h5><span>Viewer Access</span></h5>
					<div class="inner">
					<?php field('select', 'state', $state, PUBLISHSTATE, 'Status'); ?>
					</div>
				</fieldset>
				
				<fieldset>
					<h5><span>Viewer Access</span></h5>
					<div class="inner">
					<select name="access" class="form-control">
					<?php 
					$access = json_decode(catData($cid)->access);
					foreach(ACCESS as $key => $val) { ?>
					<option value="<?php echo $key; ?>" <?php echo ($access->access == $key ? 'selected' : ''); ?>><?php echo $val; ?></option>
					<?php } ?>
					</select>
					
					<div id="clientgroups" style="display: none;">
					<?php 
						$cg = clientgroups()->select('id', 'groupname')->get(); 
						foreach($cg as $g) { ?>
						<label class="btn btn-sm btn-default">
							<span class="check">
							<input type="checkbox" name="cg[<?php echo $g->id; ?>]" value="<?php echo $g->id; ?>" <?php echo (in_array($g->id, (array)$access->cg) ? 'checked' : ''); ?> />
							</span>
							<span><?php echo $g->groupname; ?></span>
						</label>
					<?php } ?>
					</div>
					
					<div id="noAccessMsg" style="display: none;">
					<label>No Access Message</label>
					<textarea name="no_access_msg"><?php echo (isset($access->no_access_msg) ? $access->no_access_msg : 'You do not have the right to view this resource. Please login'); ?></textarea>
					</div>
					
					</div>
				</fieldset>
				
				<fieldset class="check-btn">
					<label>
					<span>
					<input type="checkbox" name="showinlist" value="" <?php echo (isset($catconfig->showinlist) ? 'checked' : ''); ?> />
					</span>
					<span>Don't show in all categories list</span>
					</label>
				</fieldset>
				
				<fieldset>
					<h5><span>Image</span></h5>
					<div class="inner">
						<div class="input-group-append pad-v-10">
						<?php echo imageManager('catimage', $catimg); ?>
						<div><?php echo $catimage; ?></div>
						<div class="check-btn">
							<label>
								<span>
								<input type="checkbox" name="wideimage" value="1" <?php echo (isset($catconfig->wideimage) ? 'checked' : ''); ?> />
								</span>
								<span>Set Wide Image</span>
							</label>
						</div>
					</div>
				</fieldset>
				
				<fieldset>
					<h5><span>Assign Template</span></h5>
					<div class="inner">
						<small class="info">Assign a template to the category. All the posts in this category will use the template</small>
						<select name="assign_template" class="form-control">
							<option value="">--Use Default--</option>
							<?php foreach(templates()->get() as $template) { 
							$selected = ($template->id == $tmplset->tmpl_id ? ' selected' : '');
							?>
								<option value="<?php echo $template->id; ?>"<?php echo $selected; ?>><?php echo ucfirst($template->name); ?></option>
							<?php } ?>
						</select>
					</div>
				</fieldset>
				
				<fieldset>
					<h5><span>Miscellaneous</span></h5>
					<div class="inner">
						<?php field('number', 'sortorder', $sortorder, '', 'Sort Order'); ?>
						<h6>Style Class</h6>
						<small class="info">The style class is appended to the body tag if supported by the template</small>

						<input type="text" name="css_class" class="form-control" value="<?php echo (!empty($catconfig->css_class) ? $catconfig->css_class : ''); ?>" />
					</div>
				</fieldset>
			</div>
		</div>
		
	</div>
