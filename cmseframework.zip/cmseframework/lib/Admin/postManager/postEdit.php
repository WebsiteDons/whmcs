<?php
/*
* Copyright (c) 2019 Emuzement Net Inc. All Rights Reserved
* License: EULA
* Author: Alex/Kumar/Manti/Lisa
*/

if( !defined("WHMCS") ) die("This file cannot be accessed directly");

use \WHMCS\Session;

$action		= $modlink.'&view=postManager&task=';
$firstsave	= $action.'edit&type=post&postid=';
$saveedit	= $action.'edit&type=post&postid='.getRequest('postid').'&itemsaved=1';
$savenew	= $action.'edit&type=post';
$saveclose	= $action.'list&type=posts';

TIMEZONE;
$now 		= date('Y-m-d H:i:s');


// create images folder if not exist
if( !file_exists(IMGPATH) ) {
	if( !mkdir(IMGPATH, 0755, true) )
		die('Failed to create folders');
}


// Get categories
$cats = categories()->where([['state', 1],['type', 'post']])->pluck('title', 'id');


// item status selection array
$state_sel = PUBLISHSTATE;

$edit = requestKey('postid');
$post_content = $post_title= $post_alias= $postimg= $postimage= $wideimg= $wideimage= $metadesc= $metakeys= $state='';

if( $edit )
{
	$post_value = posts()->where('id', getRequest('postid'))->get()[0];

	$catid = (!empty($post_value->catid) ? $post_value->catid : '');

	$post_content = $post_value->post_content;
	$post_title = $post_value->title;
	$post_alias = cleanalias($post_value->alias);

	if( $post_value->post_image != '' ) {
		$postimg = $post_value->post_image;
		$postimage = '<img src="'.IMAGES.$postimg.'" /><input type="text" name="postimg_caption" value="" placeholder="Image Caption" />';
	}

	$metadesc = $post_value->metadesc;
	$metakeys = $post_value->metakeys;
	$state = $post_value->published;
	$currentcat = $post_value->catid;

	// attribs field
	$attribs = json_decode($post_value->attribs);
	$access = json_decode($post_value->access)->access;

	// wide image
	if( $attribs->wide_image != '' ) {
		$wideimg = $attribs->wide_image;
		$wideimage = '<img src="'.IMAGES.$wideimg.'" />';
	}
	$wideimg_caption = (isset($attribs->wide_imagecaption) ? $attribs->wide_imagecaption : '');

	// if menu item exists for the post
	$menuval = menus()->where('src_id', $post_value->id)->get()[0];
}



// Save post to database
if( !is_null(getPost('saveitem', false)) || !is_null(getPost('savenew', false)) || !is_null(getPost('saveclose', false)) )
{
	$catname = categories()->where('id', getPost('cats', false))->value('title');

	if( !$edit ) {
		$pubdate = $now;
		$update = '';
		$updateauthor = '';
	}else{
		$pubdate = posts()->where('id', getRequest('postid'))->value('created_at');
		$update = $now;
		$updateauthor = Session::get('adminid');
	}


	$collection = [
	'img'				=> getPost('img', false),
	'video'				=> getPost('video', false),
	'audio'				=> getPost('audio', false),
	'slide'				=> getPost('slide', false),
	'smpost'			=> getPost('smpost', false),
	'slideattrib'		=> getPost('slideattrib', false),
	'singlepost_layout' => getPost('singlepost_layout'),
	'preset_layout'		=> getPost('postpreset', false),
	'wide_image'		=> getPost('wide_image', false),
	'wide_imagecaption'	=> getPost('wide_imagecaption', false),
	'pageclass'			=> getPost('pageclass'),
	'customcss'			=> strip_tags(getPost('customcss', false))
	];

	$viewaccess = [
	'access'		=> getPost('access', false),
	'cg'			=> getPost('cg', false),
	'no_access_msg' => getPost('no_access_msg')
	];
	
	// write alias from title if field is empty
	if( empty(getPost('title_alias')) ) {
		$alias = makeAlias('post_title');
	}else{
		$alias = cleanChars(getPost('title_alias'), '', '', true);
	}

	$fields = [
		'title' 		=> getPost('post_title'),
		'alias' 		=> $alias,
		'post_content'	=> getPost('post_text', false),
		'post_image' 	=> getPost('post_image', false),
		'created_at' 	=> $pubdate,
		'updated_at'	=> $update,
		'catid' 		=> getPost('cats', false),
		'category' 		=> $catname,
		'published' 	=> getPost('state', false),
		'sortorder'		=> getPost('sortorder'),
		'metadesc' 		=> getPost('metadesc'),
		'metakeys' 		=> getPost('metakeys'),
		'attribs'		=> json_encode($collection),
		'access'		=> json_encode($viewaccess),
		'author'		=> Session::get('adminid'),
		'update_author'	=> $updateauthor
	];

	// add post to menu
	if( getPost('menu_title', false) != '' )
	{
		$menucollection = [
		'browser_title' => getPost('browser_title'),
		'menuclass'	=> getPost('menuclass'),
		'menuicon'	=> getPost('menuicon')
		];
		$menufields = [
			'title' 	=> getPost('menu_title'),
			'alias' 	=> makeAlias('menu_title'),
			'published' => 1,
			'menugroup' => getPost('menu_group', false),
			'parent' 	=> getPost('menuparent', false),
			'url' 		=> 'index.php?component=posts&view=post&category=',
			'type' 		=> 3,
			'menuorder'	=> getPost('menuorder'),
			'homepage'	=> (!is_null(getPost('homepage', false)) ? getPost('homepage', false) : 0),
			'attribs'	=> json_encode($menucollection),
			'access'	=> '{}'
		];
	}

	if( !$edit )
	{
		// new post
		try{
			$pid = posts()->insertGetId($fields);
		} catch (\Exception $e) {
			cmseNotice($e->getMessage());
		}

		// create menu item if menu title field has value
		if( getPost('menu_title', false) != '' )
		{
			try{
				$mid = menus()->insertGetId($menufields);
			} catch (\Exception $e) {
				cmseNotice($e->getMessage());
			}
			// get new saved post data
			$postvar = posts()->select('id', 'alias', 'catid')->where('id', $pid)->get()[0];
			// get alias of assigned category
			$catalias = categories()->where('id', $postvar->catid)->value('alias');
			// constant url string
			$murl = 'index.php?component=posts&view=post&category=';
			// append row id increment to extracted url and update the row
			try{
			menus()
			->where('id', $mid)
			->update([
			'url' => $murl.$postvar->catid.'-'.$catalias.'&post='.$postvar->id.'-'.$postvar->alias.'&menuid='.$mid,
			'src_id' => $pid
			]);
			} catch (\Exception $e) {
				cmseNotice($e->getMessage());
			}
		}

		if( !is_null(getPost('saveitem', false)) && !empty($pid) ) {
			redirect($firstsave.$pid.'&itemsaved=1');
		}else
		if( !is_null(getPost('savenew', false)) ) {
			redirect($savenew);
		}else
		if( !is_null(getPost('saveclose', false)) ) {
			redirect($saveclose);
		}
	}else{
		// delete item if set to delete
		if( !is_null(getPost('stateval', false)) && getPost('stateval', false) == 3 ) {
			try{
				posts()->where('id', getRequest('postid'))->delete();
			} catch (\Exception $e) {
				cmseNotice($e->getMessage());
			}
			redirect($modlink);
		}else{
			// update post
			$catname = categories()->where('id', getPost('cats', false))->value('title');
			try{
				posts()->where('id', getRequest('postid'))->update($fields);
			} catch (\Exception $e) {
				cmseNotice($e->getMessage());
			}
			// update menu item of this post if set
			if( getPost('menu_title', false) != '' ) {
				//menus()->where('src_id', getRequest('postid'))->update($menufields);
			}

			if( !is_null(getPost('saveitem', false)) ) {
				redirect($saveedit);
			}else
			if( !is_null(getPost('savenew', false)) ) {
				redirect($savenew);
			}else
			if( !is_null(getPost('saveclose', false)) ) {
				redirect($saveclose);
			}
		}

	}
}

$matches = layoutPreset();
?>



	<fieldset class="flex">
		<?php
		field('text', 'post_title', $post_title, '', '', ['class' => 'titlefield', 'placeholder' => POSTS_FIELD_TITLE_HINT, 'required' => 'required']);
		field('text', 'title_alias', $post_alias, '', '', ['class' => 'aliasfield', 'fieldclass' => 'tint', 'placeholder' => POSTS_FIELD_ALIAS_HINT]);
		?>
	</fieldset>

	<div class="clearall">
		<div class="boxsize width_70 break">

			<fieldset>
			<?php field('textarea', 'post_text', $post_content, '', '', ['rows' => '10', 'id' => 'wysiwyg', 'data-toolbar' => 'minimal']); ?>
			</fieldset>

			<!-- Repeatable Fields -->
			<?php
			include 'repeatfieldsVideo.php';
			include 'repeatfieldsAudio.php';
			include 'repeatfieldsSlides.php';
			include 'repeatfieldsSocial.php';
			?>

			<script>
			jQuery(function($) {
				$('.repeat').each(function() {
					$(this).repeatable_fields();
				});
			});
			</script>
			
			<fieldset class="groupslide">
				<h5 class="slidetab"><span class="title">Meta Data</span></h5>
				<div class="slidecontent">
					<div class="flexwrap">
						<?php
						field('textarea', 'metadesc', $metadesc, '', 'Meta Description', ['cols' => '20']);
						field('textarea', 'metakeys', $metakeys, '', 'Meta Keys', ['cols' => '20']);
						?>
					</div>
				</div>
			</fieldset>

			<fieldset class="groupslide">
				<h5 class="slidetab"><span class="title">Custom CSS</span></h5>
				<div class="slidecontent">
				<?php field('textarea', 'customcss', $attribs->customcss, '', 'Custom CSS'); ?>
				</div>
			</fieldset>
		</div>

		<!-- Right Column -->
		<div class="boxsize width_30 padleft-20 break sidefields">
			<fieldset>
			<?php 
				field('select', 'cats', $catid, $cats, 'Category');
				field('select', 'state', $state, PUBLISHSTATE, 'Status');
				?>
			</fieldset>
			<fieldset>
				<h5 class="slidetab"><span>Viewer Access</span></h5>
				<div class="inner slidecontent">
					<?php field('select', 'access', $access, ACCESS); ?>

					<div id="clientgroups" style="display: none;">
					<?php
						$cg = clientgroups()->select('id', 'groupname')->get();
						foreach($cg as $g) { ?>
						<label class="btn btn-sm btn-default">
							<span class="check">
							<input type="checkbox" name="cg[<?php echo $g->id; ?>]" value="<?php echo $g->id; ?>" <?php echo (in_array($g->id, (array)$access->cg) ? 'checked' : ''); ?> />
							</span>
							<span><?php echo $g->groupname; ?></span>
						</label>
					<?php } ?>
					</div>

					<div id="noAccessMsg" style="display: none;">
					<label>No Access Message</label>
					<?php field('textarea', 'no_access_msg', $access->no_access_msg); ?>
					</div>
				</div>
			</fieldset>


			<!-- Post Image -->
			<fieldset>
				<h5 class="slidetab"><span>Post Image</span></h5>
				<div class="inner slidecontent">
					<?php
					echo imageManager('post_image', $postimg);
					echo $postimage;
					?>
					<div class="listed check-btn">
						<label>
							<span>
								<input type="checkbox" name="img[off]" value="1" <?php echo ($attribs->img->off == 1 ? 'checked' : ''); ?> />
							</span>
							<span>Don't show image in post</span>
						</label>
						<label>
							<span>
								<input type="checkbox" name="img[enlarge]" value="1" <?php echo ($attribs->img->enlarge == 1 ? 'checked' : ''); ?> />
							</span>
							<span>Add click to enlarge</span>
						</label>
					</div>
					<h6>Wide Page Lead Image</h6>
					<?php
					echo imageManager('wide_image', $wideimg, 'wideimgname', 'wideimg');
					echo $wideimage;
					field('textarea', 'wide_imagecaption', $wideimg_caption, '', 'Caption');
					?>
				</div>
			</fieldset>


			<!-- Add To Menu -->
			<?php
			$menus = menus()->select('id', 'title', 'menuorder')->where('published', 1)->get();
			$hasmenu = (isset($menuval->title) ? ' hasmenu' : '');
			?>
			<fieldset class="addmenu<?php echo $hasmenu; ?>">
				<h5 class="slidetab"><span>Add Post To Menu</span></h5>
				<div class="inner check-btn slidecontent">
					<h6>Menu Title</h6>
					<small>Leave empty to avoid entry</small>
					<input type="text" name="menu_title" value="<?php echo (isset($menuval->title) ? $menuval->title : ''); ?>" class="form-control" />

					<h6>Parent</h6>
					<select name="menuparent" size="1">
					<option value="">--NONE--</option>
					<?php
					$order=[];
					foreach($menus as $menu) {
						$order[] = $menu->menuorder;
						$selected = (isset($menuval->parent) && $menuval->parent != 0 && $menuval->parent == $menu->id ? 'selected' : '');
						?>
						<option value="<?php echo $menu->id; ?>" <?php echo $selected; ?>><?php echo $menu->title; ?></option>
					<?php } ?>
					</select>

					<h6>Menu Group</h6>
					<select name="menu_group" size="1">
					<?php
					foreach(menugroups()->get() as $menugroup) {
						$selected = (isset($menuval->menugroup) && $menuval->menugroup == $menugroup->id ? 'selected' : '');
					?>
						<option value="<?php echo $menugroup->id; ?>" <?php echo $selected; ?>><?php echo $menugroup->groupname; ?></option>
					<?php } ?>
					</select>

					<?php $menuattrib = json_decode($menuval->attribs); ?>
					<h6>Order</h6>
					<input type="number" name="menuorder" value="<?php echo (isset($menuval->menuorder) ? $menuval->menuorder : (max($order)+1)); ?>" class="form-control" />
					<h6>Browser Title</h6>
					<input type="text" name="browser_title" value="<?php echo (isset($menuval->attribs) ? $menuattrib->browser_title : ''); ?>" class="form-control" />
					<h6>Menu Class</h6>
					<input type="text" name="menuclass" value="<?php echo (isset($menuval->attribs) ? $menuattrib->menuclass : ''); ?>" placeholder="eg: class1 class2" class="form-control" />
					<h6>Icon</h6>
					<input type="text" name="menuicon" value="<?php echo (isset($menuval->attribs) ? $menuattrib->menuicon : ''); ?>" placeholder="fas fa-cog" class="form-control" />
				</div>
			</fieldset>

			<!-- Layout Override -->
			<fieldset>
				<h5 class="slidetab"><span>Sort, Format, Classes</span></h5>
				<div class="inner slidecontent">
					<h6>Sort Order</h6>
					<?php field('number', 'sortorder', $post_value->sortorder); ?>

					<h6>Post Layout Preset Formats</h6>
					<small class="info"><?php echo CMSE_POST_INFO_POST_LAYOUT; ?></small>

					<select name="postpreset">
						<option value="">-- Use Default --</option>
						<?php
						foreach($matches as $match) {
							//include strings beginning with any
							if( !preg_match(chr(1).'^post'.chr(1), $match[1]) )
								continue;

							$selected = ($match[1] == $attribs->preset_layout ? ' selected' : '');
						?>
						<option value="<?php echo $match[1]; ?>"<?php echo $selected; ?>><?php echo $match[1]; ?></option>
						<?php } ?>
					</select>

					<?php
					field(
					'textarea',
					'singlepost_layout',
					$attribs->singlepost_layout,
					'',
					'',
					['fieldclass' => 'autosize', 'placeholder' => '[image][title][text][videoplayer]']
					); ?>
					<hr />

					<?php
					field('text', 'pageclass', $attribs->pageclass, '', 'CSS Class');
					?>
				</div>
			</fieldset>

		</div>
	</div>
