<?php
/*
* Copyright (c) 2019 Emuzement Net Inc. All Rights Reserved
* License: EULA
* Author: Alex/Kumar/Manti/Lisa
*/

if( !defined("WHMCS") ) die("This file cannot be accessed directly");

use \WHMCS\Session;

// set time zone
TIMEZONE;

$returnview = $modlink.'&view=postManager&task=list&type=posts';

// clear filter cookie
if( !is_null(getPost('clear_filter', false)) ) {
	setcookie('filter_catid');
	redirect($returnview);
}
// set filter cookie
if( !is_null(getPost('filter_value', false)) ) {
	setcookie('filter_catid', getPost('filter_value', false));
	redirect($returnview);
}
// filter posts by category
if( isset($_COOKIE['filter_catid']) ) {
	$total = posts()->where('catid', $_COOKIE['filter_catid'])->orderBy('id', 'desc')->get();
}else{
	$total = posts()->orderBy('id', 'desc')->get();
}


// set pagination values
$limit = getConfigVal('listslimit');
$p = (int)getRequest('listpage');
$offset = (($p - 1) * $limit);

if( $limit > count($total) ) {
	$posts = $total;
}else{
	if( isset($_COOKIE['filter_catid']) ) {
		$posts = posts()->where('catid', $_COOKIE['filter_catid'])->orderBy('id', 'desc')->offset($offset)->limit($limit)->get();
	}else{
		$posts = posts()->orderBy('id', 'desc')->offset($offset)->limit($limit)->get();
	}
	$pagination = '<div class="pad-20">'.pagingLinks(count($total), $limit).'</div>';
}

// delete items by checkbox
if( !is_null(getPost('item_delete', false)) )
{
	$dels = explode(',', getPost('items_id', false));
	try{
		posts()->whereIn('id',$dels)->delete();
	} catch (\Exception $e) {
		cmseNotice($e->getMessage());
	}
	redirect($returnview);
}

// disable post item
if( !is_null(getPost('item_disable', false)) )
{
	$dels = explode(',', getPost('items_id', false));
	try{
		posts()->whereIn('id',$dels)->update(['published' => 2]);
	} catch (\Exception $e) {
		cmseNotice($e->getMessage());
	}
	redirect($returnview);
}

// enable post item
if( !is_null(getPost('item_enable', false)) )
{
	$dels = explode(',', getPost('items_id', false));
	try{
		posts()->whereIn('id',$dels)->update(['published' => 1]);
	} catch (\Exception $e) {
		cmseNotice($e->getMessage());
	}
	redirect($returnview);
}

?>





<table class="chart">
<tr>
	<th>Title</th>
	<th>Created</th>
	<th>Updated</th>
	<th>Order</th>
	<th>ID</th>
	<th>Access</th>
	<th>State <input type="checkbox" value="" name="checkall" /></th>
</tr>

<?php
foreach($posts as $post)
{
	$catname = categories()->where([['id', $post->catid],['type', 'post']])->value('title');
	$access = ACCESS;
	$access = $access[json_decode($post->access)->access];
?>
	<tr class="<?php echo ($post->published == 2 ? 'disabled' : 'enabled'); ?>">
		<td>
			<a href="<?php echo $modlink; ?>&view=postManager&task=edit&type=post&postid=<?php echo $post->id; ?>" <?php echo cmseToolTip('edit post', ''); ?>>
			<?php echo $post->title; ?>
			</a><br />
			<small>Cat: <a href="<?php echo $modlink; ?>&view=postManager&task=edit&type=category&catid=<?php echo $post->catid; ?>" title="Edit Category"><?php echo $catname; ?></a></small>
		</td>
		<td>
			<?php echo dateFormat($post->created_at, 'short'); ?>
			<small class="info">
			<a href="configadmins.php?action=manage&id=<?php echo $post->author; ?>">
			<?php echo adminName($post->author); ?></a>
			</small>
		</td>
		<td>
			<?php if( $post->updated_at != '0000-00-00 00:00:00' ) { ?>
			<?php echo dateFormat($post->updated_at, 'short'); ?>
			<small class="info">
			<a href="configadmins.php?action=manage&id=<?php echo $post->update_author; ?>">
			<?php echo adminName($post->update_author); ?></a>
			</small>
			<?php } ?>
		</td>
		<td><?php echo $post->sortorder; ?></td>
		<td><?php echo $post->id; ?></td>
		<td><?php echo $access; ?></td>
		<td>
			<span>
			<input type="checkbox" name="item_check" value="<?php echo $post->id; ?>" id="delete_item" />
			</span> <?php echo ($post->published == 1 ? '<i class="fas fa-check-circle"></i>' : '<i class="fas fa-minus-circle"></i>'); ?>
		</td>
	</tr>
<?php
}
?>

</table>

<?php echo $pagination; ?>