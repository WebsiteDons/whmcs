<?php
/*
* Copyright (c) 2019 Emuzement Net Inc. All Rights Reserved
* License: EULA
* Author: Alex/Kumar/Manti/Lisa
*/

if( !defined("WHMCS") ) die("This file cannot be accessed directly");

$cats = categories()->where('type', 'post')->orderBy('id', 'desc')->get();
$posts = posts()->select('catid')->get();

// pagination
pagingLinks(8, 5);

$p =[];
foreach($posts as $post) {
	$p[] = $post->catid;
}

// redirect after save
$returnview = $modlink.'&view=postManager&task=list&type=categories';

// disable delete button if category has post items
foreach($cats as $catid) 
{
	if( !in_array($catid->id, $p) ) {
		// delete categories
		if( !is_null(getPost('item_delete', false)) ) 
		{
			$dels = explode(',', getPost('items_id', false));
			categories()->whereIn('id', $dels)->delete();
			redirect($returnview);
		}
	}
}


// disable post item
if( !is_null(getPost('item_disable', false)) ) 
{
	$dels = explode(',', getPost('items_id', false));
	try{
		categories()->whereIn('id', $dels)->update(['state' => 2]);
	} catch (\Exception $e) {
		cmseNotice($e->getMessage());
	}
	redirect($returnview);
}

// enable post item
if( !is_null(getPost('item_enable', false)) ) 
{
	$dels = explode(',', getPost('items_id', false));
	try{
		categories()->whereIn('id', $dels)->update(['state' => 1]);
	} catch (\Exception $e) {
		cmseNotice($e->getMessage());
	}
	redirect($returnview);
}
?>


<div class="clearall">
	<div class="boxsize width_50 break">
		<table class="chart">
		<tr>
			<th>Title</th>
			<th>Items</th>
			<th>Created</th>
			<th>Updated</th>
			<th>ID</th>
			<th>Order</th>
			<th>State</th>
		</tr>

		<?php foreach($cats as $cat) 
		{
		?>
			<tr class="<?php echo ($cat->state == 2 ? 'disabled' : 'enabled'); ?>">
				<td><a href="<?php echo $modlink; ?>&view=postManager&task=edit&type=category&catid=<?php echo $cat->id; ?>"><?php echo $cat->title; ?></a></td>
				<td><?php echo count(posts()->where('catid', $cat->id)->get()); ?></td>
				<td>
					<?php echo dateFormat($cat->created_at, 'short'); ?>
					<small class="info">
					<a href="configadmins.php?action=manage&id=<?php echo $cat->author; ?>">
					<?php echo adminName($cat->author); ?></a>
					</small>
				</td>
				<td>
					<?php if( $cat->updated_at != '0000-00-00 00:00:00' ) { ?>
					<?php echo dateFormat($cat->updated_at, 'short'); ?>
					<small class="info">
					<a href="configadmins.php?action=manage&id=<?php echo $cat->update_author; ?>">
					<?php echo adminName($cat->update_author); ?></a>
					</small>
					<?php } ?>
				</td>
				<td><?php echo $cat->id; ?></td>
				<td><?php echo $cat->sortorder; ?></td>
				<td>
					<span>
					<input type="checkbox" name="item_check" value="<?php echo $cat->id; ?>" id="cat_id_to_delete" />
					</span> <?php echo ($cat->state == 1 ? '<i class="fas fa-check-circle" title="Published"></i>' : '<i class="fas fa-minus-circle" title="Unpublished"></i>'); ?>
				</td>
			</tr>
		<?php 	
		} ?>

		</table>
	</div>
</div>
