<?php
/*
* Copyright (c) 2019 Emuzement Net Inc. All Rights Reserved
* License: EULA
* Author: Alex/Kumar/Manti/Lisa
*/

if( !defined("WHMCS") ) die("This file cannot be accessed directly");

$modlink = $vars['modulelink'];

?>

<fieldset class="groupslide">
	<h5 class="slidetab">
		<span class="title">Videos</span>
	</h5>

	<div class="slidecontent repeat">
	<small class="info">Add video(s) to the post by adding the URL</small>
	<div class="wrapper">
		<div><span class="btn btn-success btn-sm add"><i class="fas fa-plus-square"></i></span></div>
		<div class="container">

			<div class="template row">
				<input type="hidden" class="move-steps" value="1" />

				<fieldset class="clearall hidden-overflow">
				<div class="boxsize width-350">
				<label>URL</label>
				<input type="text" name="video[{{row-count-placeholder}}][url]" placeholder="https://www.youtube.com/watch?v=Tb_Wn6K0uVs" class="form-control" />
				</div>
				<div class="boxsize width-120 padleft-5">
				<label>Title</label>
				<input type="text" name="video[{{row-count-placeholder}}][title]" class="form-control" />
				</div>
				<div class="boxsize width-120 padleft-5">
				<label>Image</label>
				<input type="text" name="video[{{row-count-placeholder}}][image]" class="form-control" />
				</div>

				<div class="boxsize">
				<label style="display: block;">action</label>
				<span class="btn btn-primary btn-sm move" title="drag to reorder"><i class="fas fa-arrows-alt-v"></i></span>
				<span class="btn btn-warning btn-sm remove" title="delete"><i class="fas fa-times-circle"></i></span>
				</div>
				</fieldset>

			</div>


		<!-- Returned Active Fields -->
		<?php if( isset($attribs->video) ) {
		foreach($attribs->video as $key => $val) {

		?>

			<div class="row">
				<input type="hidden" class="move-steps" value="1" />

				<fieldset class="clearall hidden-overflow">
				<div class="boxsize width-350">
				<label>URL</label>
				<input type="text" name="video[<?php echo $key; ?>][url]" value="<?php echo $val->url; ?>" class="form-control" />
				</div>
				<div class="boxsize width-120 padleft-5">
				<label>Title</label>
				<input type="text" name="video[<?php echo $key; ?>][title]" value="<?php echo $val->title; ?>" class="form-control" />
				</div>
				<div class="boxsize width-120 padleft-5">
				<label>Image</label>
				<input type="text" name="video[<?php echo $key; ?>][image]" value="<?php echo $val->image; ?>" class="form-control" />
				</div>

				<div class="boxsize">
				<label style="display: block;">action</label>
				<span class="btn btn-primary btn-sm move" title="drag to reorder"><i class="fas fa-arrows-alt-v"></i></span>
				<span class="btn btn-warning btn-sm remove" title="delete"><i class="fas fa-times-circle"></i></span>
				</div>
				</fieldset>

			</div>
		<?php } }?>
		</div>
		</div>
	</div>
</fieldset>