<?php
/*
* Copyright (c) 2019 Emuzement Net Inc. All Rights Reserved
* License: EULA
* Author: Alex/Kumar/Manti/Lisa
*/

if( !defined("WHMCS") ) die("This file cannot be accessed directly");

$modlink = $vars['modulelink'];
$slide = $attribs->slideattrib;

?>

<fieldset class="groupslide">
	<h5 class="slidetab">
		<span class="title">Slideshow</span>
	</h5>
	<div class="slidecontent repeat">
	<small class="info">Add a slidshow with text, image to the post.</small>
	<div class="inlineblock aligntop">
	<label>Height</label>
	<input type="number" name="slideattrib[slideheight]" value="<?php echo $slide->slideheight; ?>" class="form-control" />
	</div>
	
	<div class="inlineblock aligntop">
	<label>Delay Time</label>
	<input type="number" name="slideattrib[slidedelay]" value="<?php echo $slide->slidedelay; ?>" class="form-control" />
	</div>
	
	<div class="inlineblock aligntop">
	<label>Show Navigation</label>
	<select name="slideattrib[thumbs]" class="form-control">
		<option value="">No</option>
		<option value="1">Side</option>
		<option value="2">Bottom</option>
	</select>
	</div>
	
	<div class="wrapper">
		<div class="margintop-20">
		<span class="btn btn-success btn-sm add"><i class="fas fa-plus-square"></i></span>
		</div>
		<div class="container">

			<div class="template row">
				<input type="hidden" class="move-steps" value="1" />

				<fieldset class="clearall hidden-overflow margintop-20">
				<div style="max-width: 700px;">
				<div style="text-align: right">
				<label>Delete</label>
				<span class="btn btn-warning btn-sm remove" title="delete"><i class="fas fa-times-circle"></i></span>
				</div>
				<textarea name="slide[{{row-count-placeholder}}][html]"></textarea>
				</div>

				</fieldset>

			</div>


		<!-- Returned Active Fields -->
		<?php if( isset($attribs->slide) ) {
		foreach($attribs->slide as $key => $val) {

		?>

			<div class="row">
				<input type="hidden" class="move-steps" value="1" />

				<fieldset class="clearall hidden-overflow margintop-20">
				<div style="max-width: 700px;">
				<div style="text-align: right">
				<span class="btn btn-success btn-sm add"><i class="fas fa-plus-square"></i></span>
				<span class="btn btn-warning btn-sm remove" title="delete"><i class="fas fa-times-circle"></i></span>
				</div>
				<textarea name="slide[<?php echo $key; ?>][html]" class="autosize wysiwyg"><?php echo $val->html; ?></textarea>
				</div>

				</fieldset>

			</div>
		<?php } }?>
		</div>
		</div>
	</div>
</fieldset>