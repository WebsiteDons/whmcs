<?php
/*
* Copyright (c) 2019 Emuzement Net Inc. All Rights Reserved
* License: EULA
* Author: Alex/Kumar/Manti/Lisa
*/

if( !defined("WHMCS") ) die("This file cannot be accessed directly");

$modlink = $vars['modulelink'];

?>

<fieldset class="groupslide">
	<h5 class="slidetab">
		<span class="title">Social Media Alternative</span>
	</h5>

	<div class="slidecontent repeat">
	<small class="info">Add multiple images and titles to override those set for the post and serve randomly to social networks</small>
	<div class="wrapper">
		<div><span class="btn btn-success btn-sm add"><i class="fas fa-plus-square"></i></span></div>
		<div class="container">

			<div class="template row">
				<input type="hidden" class="move-steps" value="1" />

				<fieldset class="clearall hidden-overflow">
				<div class="boxsize width-220">
				<label>Title</label>
				<input type="text" name="smpost[{{row-count-placeholder}}][title]" class="form-control" />
				</div>
				<div class="boxsize width-220 padleft-5">
				<label>Description</label>
				<input type="text" name="smpost[{{row-count-placeholder}}][desc]" class="form-control" />
				</div>
				<div class="boxsize width-220 padleft-5">
				<label>Image</label>
				<input type="text" name="smpost[{{row-count-placeholder}}][image]" class="form-control" />
				<?php $smimg='';
				//echo imageManager('smpost[{{row-count-placeholder}}][image]', $smimg, 'smpostimg', 'smpost_img'); ?>
				</div>

				<div class="boxsize">
				<label style="display: block;">action</label>
				<span class="btn btn-warning btn-sm remove" title="delete"><i class="fas fa-times-circle"></i></span>
				</div>
				</fieldset>

			</div>


		<!-- Returned Active Fields -->
		<?php if( isset($attribs->smpost) ) {
		foreach($attribs->smpost as $key => $val) {

		?>

			<div class="row">
				<input type="hidden" class="move-steps" value="1" />

				<fieldset class="clearall hidden-overflow">
				<div class="boxsize width-220">
				<label>Title</label>
				<input type="text" name="smpost[<?php echo $key; ?>][title]" value="<?php echo $val->title; ?>" class="form-control" />
				</div>
				<div class="boxsize width-220 padleft-5">
				<label>Description</label>
				<input type="text" name="smpost[<?php echo $key; ?>][desc]" value="<?php echo $val->desc; ?>" class="form-control" />
				</div>
				<div class="boxsize width-220 padleft-5">
				<label>Image</label>
				<!-- input type="text" name="smpost[<?php //echo $key; ?>][image]" value="<?php //echo $val->image; ?>" class="form-control" / -->
				<?php echo imageManager('smpost['.$key.'][image]', $val->image, 'smpostimg'.$key, 'smpost_img'.$key); ?>
				</div>

				<div class="boxsize">
				<label style="display: block;">action</label>
				<span class="btn btn-warning btn-sm remove" title="delete"><i class="fas fa-times-circle"></i></span>
				</div>
				</fieldset>

			</div>
		<?php } }?>
		</div>
		</div>
	</div>
</fieldset>