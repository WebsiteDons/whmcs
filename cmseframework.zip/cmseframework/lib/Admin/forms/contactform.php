<?php
/*
* Copyright (c) 2019 Emuzement Net Inc. All Rights Reserved
* License: EULA
* Author: Alex/Kumar/Manti/Lisa
*/

if( !defined("WHMCS") ) die("This file cannot be accessed directly");

use \WHMCS\Utility\Captcha;

$captcha = new Captcha;


if( !is_null(getPost('sendmsg', false)) ) 
{
	$fromname = getPost('fromname');
	$fromemail = getPost('fromemail');
	$fromphone = getPost('phone');
	$subject = getPost('subject').$subjectAppend;
	
	$message = 
	$selection
	.str_replace("\n", '<br /><br />', getPost('message')).'
	<br /><br />---<br />
	'.$fromname.'<br />
	'.$fromphone.'<br />
	Sent from page at '.currenturl().'<br />
	Sender IP: '.getRemoteIp()
	;
	
	// headers
	$headers = "MIME-Version: 1.0" . "\r\n";
	$headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
	$headers .= 'From: '.$fromemail;
	
	$recipient = str_replace(':', '@', $contact[1]);
	
	try{
		mail($recipient, $subject, $message, $headers);
	} catch (\Exception $e) {
		cmseNotice($e->getMessage());
	}
	
}

?>
<form action="" method="post" class="form-vertical">
	<div class="form-group">
		<?php if( !$nolabel ) { ?><label><?php echo text('supportticketsclientname'); ?></label><?php } ?>
		<div class="control">
			<input type="text" name="fromname" value="" required="required" placeholder="<?php echo text('supportticketsclientname'); ?>" />
		</div>
	</div>
	<div class="form-group">
		<?php if( !$nolabel ) { ?><label><?php echo text('supportticketsclientemail'); ?></label><?php } ?>
		<div class="control">
			<input type="email" name="fromemail" value="" required="required" placeholder="<?php echo text('supportticketsclientemail'); ?>" />
		</div>
	</div>
	<div class="form-group">
		<?php if( !$nolabel ) { ?><label>Phone</label><?php } ?>
		<div class="control">
			<input type="text" name="phone" value="" placeholder="Phone" />
		</div>
	</div>
	
	<?php echo $selectfield; ?>
	
	<div class="form-group">
		<?php if( !$nolabel ) { ?><label><?php echo text('supportticketsticketsubject'); ?></label><?php } ?>
		<div class="control">
			<input type="text" name="subject" value="" required="required" placeholder="<?php echo text('supportticketsticketsubject'); ?>" />
		</div>
	</div>
	<div class="form-group">
		<div class="control">
			<textarea name="message" required="required"></textarea>
		</div>
	</div>
	
	<?php //Captcha 
	if( $captcha->isEnabled() ) { 
	
	if( $captcha == 'recaptcha' ) { ?>
	<div id="google-recaptcha-domainchecker" class="form-group recaptcha-container center-block"></div>
	
	<?php }elseif( !in_array($captcha, ['invisible', 'recaptcha']) ) { ?>
	
	<div class="form-group">
		<label><?php echo text('captchaverify'); ?></label>
		<div class="table">
			<div class="tablecell alignmiddle">
				<img id="inputCaptchaImage" src="<?php echo ROOT_URL; ?>includes/verifyimage.php" align="middle" />
			</div>
			<div class="control tablecell alignmiddle">
				<input id="inputCaptcha" type="text" name="code" maxlength="5" required="required" />
			</div>
		</div>
	</div>
	<?php } } ?>

	<div class="form-group">
	<input type="submit" name="sendmsg" class="btn btn-primary btn-block" value="<?php echo text('contactsend'); ?>" />
	</div>
</form>
