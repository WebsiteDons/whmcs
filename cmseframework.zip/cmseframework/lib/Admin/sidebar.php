<?php
/*
* Copyright (c) 2019 Emuzement Net Inc. All Rights Reserved
* License: EULA
* Author: Alex/Kumar/Manti/Lisa
*/

if( !defined("WHMCS") ) die("This file cannot be accessed directly");
$modlink = 'addonmodules.php?module='.MODNAME;
$view = getRequest('view');
$task = getRequest('task');
?>

<div class="sidebar">
	<div class="<?php echo (!requestKey('view') ? 'active' : ''); ?>">
	<a href="<?php echo $modlink; ?>"><i class="fas fa-box-open"></i><?php echo CMSE_BTNLBL_DASHBOARD; ?></a></div>
	
	<div class="<?php echo ($view == 'configs' ? 'active' : ''); ?>">
	<a href="<?php echo $modlink; ?>&view=configs"><i class="fas fa-wrench"></i><?php echo CMSE_BTNLBL_GLOBALCONFIG; ?></a></div>
	
	<a href="<?php echo ROOT_URL; ?>" target="_blank"><i class="fas fa-external-link-alt"></i><?php echo CMSE_BTN_VIEW_SITE; ?></a>
	
	<div class="<?php echo ($view == 'installer' ? 'active' : ''); ?>">
	<a href="<?php echo $modlink; ?>&view=installer"><i class="fas fa-plug"></i><?php echo CMSE_BTN_INSTALL_EXT; ?></a></div>

	<div class="<?php echo ($view == 'installer' && requestKey('do') ? 'active' : ''); ?>">
	<a href="<?php echo $modlink; ?>&view=installer&do=update"><i class="fas fa-sync-alt"></i><?php echo CMSE_BTN_UPDATE_CHECK; ?></a></div>

	<div class="<?php echo ($view == 'languageManager' ? 'active' : ''); ?>">
	<a href="<?php echo $modlink; ?>&view=languageManager"><i class="fas fa-file-alt"></i><?php echo CMSE_BTN_LANG_EDIT; ?></a></div>
	
	<div class="<?php echo ($view == 'templateManager' ? 'active' : ''); ?>">
	<a href="<?php echo $modlink; ?>&view=templateManager&task=list&type=templates"><i class="fas fa-edit"></i><?php echo CMSE_BTN_TPL_MANAGE; ?></a></div>

	<div>
	<a href="configproducts.php"><i class="fas fa-splotch"></i>Product Manager</a>
	</div>


	<?php	
	//get folders of selected template and create file tree
	if( $task == 'templateEdit' && getRequest('template') != '' ) { 

	?>

		<script type="text/javascript">
			function openFile(file) {
				window.location (file);
			}
			jQuery(function($) {

				$("#template-tree").fileTree({
					root: "<?php echo ROOT_PATH; ?>templates/<?php echo getRequest('template'); ?>/",
					script: "<?php echo ROOT_URL; ?>modules/addons/<?php echo MODNAME; ?>/assets/jqueryFileTree.php",
				},
				function(file) {
					openFile(file);
				});

			});
		</script>

		<div class="sublink">
			<h5><i class="fas fa-arrow-alt-circle-down"></i> <?php echo getRequest('template'); ?></h5>
			<div id="template-tree" class="template-tree"></div>

		</div>
	<?php } ?>

	<form method="post" action="systemcleanup.php">
	<input type="hidden" name="action" value="emptytemplatecache">
	<button id="system-empty-template-cache" type="submit" class="btnlink">
		<i class="fas fa-broom"></i> Empty Template Cache
	</button>
	<?php 
	/*TODO: use empty dir method instead of through whmcs
	deleFiles(getSmarty()->getCompileDir()); 
	*/
	?>
	</form>

</div>