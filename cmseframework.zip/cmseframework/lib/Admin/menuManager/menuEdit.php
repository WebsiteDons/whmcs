<?php
/*
* Copyright (c) 2019 Emuzement Net Inc. All Rights Reserved
* License: EULA
* Author: Alex/Kumar/Manti/Lisa
*/

if( !defined("WHMCS") ) die("This file cannot be accessed directly");

use \WHMCS\Database\Capsule;
use \WHMCS\Session;

// set time zone
TIMEZONE;
$now 		= date('Y-m-d H:i:s');

$action		= $modlink.'&view=menuManager&task=';
$firstsave	= $action.'edit&type=menu&menuid=';
$saveedit	= $action.'edit&type=menu&menuid='.getRequest('menuid').'&itemsaved=1';
$savenew	= $action.'edit&type=menu';
$saveclose	= $action.'list&type=menus';

$categories = categories()->get();

// Get menu values if exist
if( requestKey('menuid') && !is_null(getRequest('menuid')) )
	$edit = true;

if( $edit )
{
	$menu_value = menus()->where('id', getRequest('menuid'))->get()[0];
	$attribs = json_decode($menu_value->attribs);

	// get template assigned
	$tmplset = tplassign()
		->where([['type', 'menu'],['resource', getRequest('menuid')]])
		->select('id', 'tmpl_id', 'resource', 'type')
		->get()[0];
}

// get menu groups
$menugroups = menugroups()->get();

//get menu items
$menuitems = menus()->get();

// save or edit menu item
if( !is_null(getPost('saveitem', false)) || !is_null(getPost('savenew', false)) || !is_null(getPost('saveclose', false)) )
{
	if( !$edit ) {
		$created = $now;
		$updated = '';
		$author = Session::get('adminid');
		$updateauthor = '';
	}else{
		$created = $menu_value->created_at;
		$updated = $now;
		$author = '';
		$updateauthor = Session::get('adminid');
	}
	
	$collection = [
	'browser_title'		=> getPost('browser_title'),
	'menuclass'			=> getPost('menuclass'),
	'menuicon'			=> getPost('menuicon'),
	'meta_keywords'		=> getPost('meta_keywords'),
	'meta_description'	=> getPost('meta_description'),
	'social_img'		=> getPost('social_img'),
	'target' 			=> getPost('target', false)
	];

	if( getPost('menu_alias') != '' ) {
		$alias = cleanChars(getPost('menu_alias'), '', '', true);
	}else{
		$alias = makeAlias('menu_title');
	}

	$fields = [
		'title' 	=> getPost('menu_title'),
		'alias' 	=> $alias,
		'published' => getPost('status', false),
		'menugroup' => getPost('menu_group', false),
		'menuparent'=> getPost('menuparent', false),
		'url' 		=> getPost('menu_url'),
		'type' 		=> getPost('menutype', false),
		'menuorder'	=> getPost('menuorder'),
		'attribs'	=> json_encode($collection),
		'access'	=> json_encode(['access' => getPost('access', false), 'cg' => getPost('cg', false)]),
		'created_at' => $created,
		'updated_at' => $updated,
		'author'	=> Session::get('adminid'),
		'update_author' => $updateauthor
	];

	// set menu item as homepage
	if( !is_null(getPost('homepage', false)) )
	{
		if( $edit ) {
			if( menus()->where('id', getRequest('menuid'))->value('homepage') == 1 ) {
				//do nothing when the item is already set as home page
			}else{
				menus()->where('homepage', 1)->update(['homepage' => 0]);
				$fields = array_merge($fields, ['homepage' => getPost('homepage', false)]);
			}
		}else{
			menus()->where('homepage', 1)->update(['homepage' => 0]);
			$fields = array_merge($fields, ['homepage' => getPost('homepage', false)]);
		}
	}

	if( !$edit )
	{
		// save
		if( !is_null(getPost('homepage', false)) ) {
			try{
				menus()->where('homepage', 1)->update(['homepage' => 0]);
			}
			catch (\Exception $e) {
				cmseNotice($e->getMessage());
			}
		}
		
		// insert the db fields
		try {
			$mid = menus()->insertGetId($fields);
		}
		catch (\Exception $e) {
			cmseNotice($e->getMessage());
		}
		
		
		// get the inserted row at column url if type matches 1,2,3
		if( in_array(getPost('menutype', false), [1,2,3,5,6,7]) )
		{
			$murl = menus()->select('id', 'alias', 'url')->where('id', $mid)->whereIn('type', [1,2,3,5,6,7])->get()[0];
			// append row id increment to extracted url and update the row
			menus()->where('id', $mid)->whereIn('type', [1,2,3,5,6,7])->update(['url' => $murl->url.$mid.'-'.$murl->alias]);
			// get the post id to add to postid column if type is single post
			if( getPost('menutype', false) == 2 ) {
				$src_id = getinnerstring(getPost('menu_url', false), 'category=','-');
				menus()->where('id', $mid)->update(['src_id' => $src_id]);
			}else
			if( getPost('menutype', false) == 3 ) {
				$src_id = getinnerstring(getPost('menu_url', false), 'post=','-');
				menus()->where('id', $mid)->update(['src_id' => $src_id]);
			}else
			if( getPost('menutype', false) == 6 ) {
				$src_id = getinnerstring(getPost('menu_url', false), 'gid=','-');
				menus()->where('id', $mid)->update(['src_id' => $src_id]);
			}else
			if( getPost('menutype', false) == 7 ) {
				$src_id = getinnerstring(getPost('menu_url', false), 'pid=','-');
				menus()->where('id', $mid)->update(['src_id' => $src_id]);
			}
		}

		// save template assignment if set
		if( getPost('assign_template', false) != '' )
		{
			$tmpl = [
			'tmpl_id' => getPost('assign_template', false),
			'resource' => $mid,
			'type' => 'menu',
			'created_at' => setDate()
			];
			
			try{
				tplassign()->insertGetId($tmpl);
			}
			catch (\Exception $e) {
				cmseNotice($e->getMessage());
			}
		}

		if( !is_null(getPost('saveitem', false)) && !empty($mid) ) {
			redirect($firstsave.$mid.'&itemsaved=1');
		}else
		if( !is_null(getPost('savenew', false)) ) {
			redirect($savenew);
		}else
		if( !is_null(getPost('saveclose', false)) ) {
			redirect($saveclose);
		}
	}else{
		// delete
		if( $edit && getPost('status', false) == 3 ) {
			menus()->where('id', getRequest('menuid'))->delete();
			redirect($menulist);
		}else
		{
			// edit
			menus()->where('id', getRequest('menuid'))->update($fields);

			// get the post id to add to postid column if type is single post
			if( getPost('menutype', false) == 3 ) {
				$postid = getinnerstring(getPost('menu_url', false), 'post=','-');
				menus()->where('id', getRequest('menuid'))->update(['src_id' => $postid]);
			}


			// update template assignment if set or changed
			if( getPost('assign_template', false) != '' )
			{
				if( isset($tmplset->resource) && $tmplset->resource == getRequest('menuid') )
				{
					if( $tmplset->tmpl_id != getPost('assign_template', false) )
					{
						$tmpl = [
						'tmpl_id' => getPost('assign_template', false),
						'updated_at' => setDate()
						];

						tplassign()->where('id', $tmplset->id)->update($tmpl);
					}
				}else{
					$tmpl = [
					'tmpl_id' => getPost('assign_template', false),
					'resource' => (int)getRequest('menuid', false),
					'type' => 'menu',
					'created_at' => setDate()
					];

					tplassign()->insertGetId($tmpl);
				}
			}else
			// delete the row when set to default template
			if( $tmplset->resource == getRequest('menuid') ) {
				tplassign()->where([['resource', getRequest('menuid')], ['type', 'menu']])->delete();
			}


			if( !is_null(getPost('saveitem', false)) ) {
				redirect($saveedit);
			}else
			if( !is_null(getPost('savenew', false)) ) {
				redirect($savenew);
			}else
			if( !is_null(getPost('saveclose', false)) ) {
				redirect($saveclose);
			}
		}
	}
}


// item status selection array
$menutypes = [
	1 => 'All Categories',
	2 => 'Category',
	3 => 'Single Post',
	4 => 'WHMCS Core',
	5 => 'All Product Groups',
	6 => 'Product Group',
	7 => 'Product',
	8 => 'Custom Link',
	9 => 'Popup Window',
	10 => 'iFrame'
];

// WHMCS Core URLs
$whmcs = [
	'index.php' => 'Home',
	'cart.php' => 'Cart',
	'cart.php?a=view' => 'View Cart',
	'cart.php?a=add&domain=register' => 'Domain Registration',
	'cart.php?a=add&domain=transfer' => 'Transfer Domain',
	'domainchecker.php' => 'Domain Search',
	'contact.php' => 'Contact Us',

	'index.php?rp=/download' => 'Download',
	'index.php?rp=/announcements' => 'Announcements',
	'index.php?rp=/knowledgebase' => 'Knowledgebase',
	'index.php?rp=/announcements/rss' => 'RSS Feed',
	'index.php?rp=/announcements/view/older' => 'Old Announcements',
	'serverstatus.php' => 'Server Status',

	// registered
	'register.php' => 'Register',
	'clientarea.php' => 'Client Area',
	'clientarea.php?action=services' => 'Services',
	'clientarea.php?action=domains' => 'My Domains',
	'clientarea.php?action=invoices' => 'Invoices',
	'clientarea.php?action=quotes' => 'Quotes',
	'clientarea.php?action=masspay&all=true' => 'Mass Payment',
	'clientarea.php?action=addfunds' => 'Add Funds',
	'cart.php?a=add&domain=register' => 'Buy Domains',
	'cart.php?a=add&domain=transfer' => 'Transfer Domains',
	'cart.php?gid=addons' => 'Addons',
	'pwreset.php' => 'Password Recovery',
	'submitticket.php' => 'Submit Ticket',
	'supporttickets.php' => 'My Tickets',
	'affiliates.php' => 'Affiliates',
	'logout.php?returntoadmin=1' => 'Admin Return',
	'logout.php' => 'Logout',
];


?>

	<div class="clearall">
		<div class="boxsize width_70 break">

			<fieldset class="clearall">
				<div class="boxsize width_60 break">
					<label>Menu Title</label>
					<small class="info">The displayed menu label</small>
					<input type="text" name="menu_title" value="<?php echo ($edit ? $menu_value->title:''); ?>" placeholder="Hosting Tips" required />
				</div>
				<div class="boxsize width_40 break padleft-20">
					<label>Menu Alias</label>
					<small class="info">Alter the alias to avoid name conflict if needed</small>
					<input type="text" name="menu_alias" value="<?php echo ($edit ? $menu_value->alias:''); ?>" class="tint" placeholder="alias is created from the title" />
				</div>
			</fieldset>

			<div class="marginbottom-20">
				<div class="inlineblock">
					<label class="clearall">Menu Type</label>
					<select name="menutype" id="menutype" size="1">
						<option value="">--Select--</option>
					<?php foreach($menutypes as $key => $val) {
							$selected = ($edit && $menu_value->type != 0 && $menu_value->type == $key ? 'selected' : '');
							?>
							<option value="<?php echo $key; ?>" <?php echo $selected; ?>><?php echo $val; ?></option>
					<?php }
					?>
					</select>
				</div>

				<div class="inlineblock">
					<!-- Category -->
					<fieldset id="catlist" style="display: none;">
						<select name="categories" id="categories" size="1">
							<option value="">-- Select Category --</option>
							<?php
							foreach($categories as $cat) {
								$caturl = 'index.php?component=posts&view=category&category='.$cat->id.'-'.$cat->alias.'&menuid='.$menu_value->id.'-'.$menu_value->alias;
							?>
							<option value="<?php echo $caturl; ?>"><?php echo $cat->title; ?></option>
							<?php } ?>
						</select>
					</fieldset>

					<!-- Single Posts -->
					<fieldset id="postlist" style="display: none;">
						<select name="singlepost" id="posts" size="1">

							<?php
							$getposts = posts()->where('published', 1)->orderBy('created_at', 'desc')->get();
							foreach($getposts as $post) {
								$catalias = categories()->select('alias')->where([['id', $post->catid],['state', 1]])->get()[0]->alias;
								$posturl = 'index.php?component=posts&view=post&post='.$post->id.'-'.$post->alias.'&menuid='.(isset($menu_value->id) ? $menu_value->id.'-'.$menu_value->alias : '');
							?>
							<option value="<?php echo $posturl; ?>"><?php echo $post->title; ?></option>
							<?php } ?>
						</select>
					</fieldset>

					<!-- WHMCS Core URL -->
					<fieldset id="whmcslist" style="display: none;">
						<select id="whmcs" size="1">
							<option value="">-- Select Item --</option>
							<?php foreach($whmcs as $key => $val) { ?>
							<option value="<?php echo $key; ?>"><?php echo $val; ?></option>
							<?php } ?>
						</select>
					</fieldset>

					<!-- Product Group -->
					<fieldset id="product_group" style="display: none;">
						<select id="prodgroup" size="1">
							<?php
							$prodgroups = groups()->select('id', 'name')->where('hidden', 0)->get();
							foreach($prodgroups as $pg) {
							$pgurl = 'index.php?component=products&view=productgroup&gid='.$pg->id.'-'.cleanChars($pg->name).'&menuid='.(isset($menu_value->id) ? $menu_value->id.'-'.$menu_value->alias : '');
							?>
							<option value="<?php echo $pgurl; ?>"><?php echo $pg->name; ?></option>
							<?php } ?>
						</select>
					</fieldset>

					<!-- Product Detail -->
					<?php
					if( isset(modConfigs()->product_alias_db) && !empty(modConfigs()->product_alias_db) && Capsule::schema()->hasColumn('tblproducts', 'alias') ) { ?>
					<fieldset id="product_detail" style="display: none;">
						<select id="prodetail" size="1">
							<option value="">-- Select Item --</option>
							<?php
							$products = products()->select('id', 'gid', 'name', 'alias')->where([['hidden', 0], ['retired', 0]])->get();
							foreach($products as $product) {
							$groupname = groups()->where('id', $product->gid)->value('name');
							$produrl = 'index.php?component=products&view=productdetail&gid='.$product->gid.'-'.cleanChars($groupname).'&pid='.$product->id.'-'.$product->alias.'&menuid='.(isset($menu_value->id) ? $menu_value->id.'-'.$menu_value->alias : '');
							?>
							<option value="<?php echo $produrl; ?>"><?php echo $product->name; ?></option>
							<?php } ?>
						</select>
					</fieldset>
					<?php } ?>
				</div>

				<div class="inlineblock">
				<label class="clearall">Parent</label>
					<select name="menuparent" id="menuparent" size="1">
					<option value="">--None--</option>
					<?php foreach($menuitems as $menuitem) {
							$selected = ($edit && $menu_value->menuparent != 0 && $menu_value->menuparent == $menuitem->id ? 'selected' : '');
							?>
							<option value="<?php echo $menuitem->id; ?>" <?php echo $selected; ?>><?php echo $menuitem->title; ?></option>
					<?php	}
					?>
					</select>
				</div>

				<div class="inlineblock">
					<label class="clearall">Menu Group</label>
					<select name="menu_group" id="menu_group" size="1">
					<?php foreach($menugroups as $menugroup) {
							$selected = ($edit && $menu_value->menugroup != 0 && $menu_value->menugroup == $menugroup->id ? 'selected' : '');
							?>
							<option value="<?php echo $menugroup->id; ?>" <?php echo $selected; ?>><?php echo $menugroup->groupname; ?></option>
					<?php	}
					?>
					</select>
				</div>
				<div class="clearall"></div>
			</div>

			<fieldset>
			<label>Menu URL</label>
			<?php
			if( $edit ) {
				$menuval = $menu_value->url;
			}else{
				$menuval = '';
			} ?>
			<input
			type="text" name="menu_url" id="menu_url" size="50"
			value="<?php echo $menuval; ?>"
			readonly="readonly"
			/>
			</fieldset>
			
			<fieldset>
				<?php field(
				'select', 
				'target', 
				$attribs->target, 
				['' => 'Parent Window', '_blank' => 'New Window', 'popwin' => 'PopUp External Window', 'modal' => 'Modal Window'],
				'Target Window'
				); ?>
			</fieldset>
			
			<div class="groupslide">
				<h5 class="slidetab">
					<span class="title">Mega Menu Configs</span>
				</h5>
				<div class="slidecontent">
				</div>
			</div>
			
			<div class="groupslide">
				<h5 class="slidetab">
					<span class="title">Data Override</span>
				</h5>
				<div class="slidecontent">
					<small class="info">These elements are overrides for the global configuration and category values</small>
					<fieldset class="inlineblock width_45 aligntop">
						<?php field('text', 'browser_title', $attribs->browser_title, '', 'Browser Title'); ?>
					</fieldset>

					<fieldset class="inlineblock width_45 aligntop">
					<?php field('image', 'social_img', $attribs->social_img, '', 'Social Share Image'); ?>
					</fieldset>

					<fieldset class="inlineblock width_45">
					<?php field('textarea', 'meta_description', $attribs->meta_description, '', 'Meta Description'); ?>
					</fieldset>

					<fieldset class="inlineblock width_45">
					<?php field('textarea', 'meta_keywords', $attribs->meta_keywords, '', 'Meta Keywords'); ?>
					</fieldset>
				</div>
			</div>

			<!-- All Categories View -->
			<input type="hidden" id="allcaturl" value="index.php?component=posts&view=categories&menuid=<?php echo (!is_null(getRequest('menuid')) ? getRequest('menuid').'-'.$menu_value->alias : ''); ?>" />
			<input type="hidden" id="allgroupurl" value="index.php?component=products&view=productgroups&menuid=<?php echo (!is_null(getRequest('menuid')) ? getRequest('menuid').'-'.$menu_value->alias : ''); ?>" />

			<div class="clearall"></div>
		</div>

		<!-- Right Column -->
		<div class="boxsize width_30 padleft-20 break sidefields">

			<fieldset>
				<h5><span>Status</span></h5>
				<div class="inner">
				<?php if( $menu_value->homepage == 1 ) { ?>
				<small class="info">This menu item is set as the default and cannot be unpublished or deleted.</small>
				<?php } ?>
					<select name="status" id="status">
					<?php if( $menu_value->homepage == 1 ) { ?>
					<option value="1" selected>Published</option>
					<?php }else{ ?>
					<?php foreach(PUBLISHSTATE as $key => $val) {
							$selected = ($edit && $menu_value->published != 0 && $menu_value->published == $key ? 'selected' : '');
							?>
							<option value="<?php echo $key; ?>" <?php echo $selected; ?>><?php echo $val; ?></option>
					<?php }
					}
					?>
					</select>
				</div>
			</fieldset>

			<fieldset>
				<h5><span>Viewer Access</span></h5>
				<div class="inner">
					<select name="access" class="form-control">
					<?php
					$access = json_decode($menu_value->access);
					foreach(ACCESS as $key => $val) { ?>
					<option value="<?php echo $key; ?>" <?php echo ($access->access == $key ? 'selected' : ''); ?>><?php echo $val; ?></option>
					<?php } ?>
					</select>

				<div id="clientgroups" style="display: none;">
				<?php
					$cg = clientgroups()->select('id', 'groupname')->get();
					foreach($cg as $g) { ?>
					<label class="btn btn-sm btn-default">
						<span class="check">
						<input type="checkbox" name="cg[<?php echo $g->id; ?>]" value="<?php echo $g->id; ?>" <?php echo (in_array($g->id, (array)$access->cg) ? 'checked' : ''); ?> />
						</span>
						<span><?php echo $g->groupname; ?></span>
					</label>
				<?php } ?>
				</div>
				</div>
			</fieldset>

			<fieldset>
				<h5><span>Assign Template</span></h5>
				<div class="inner">
					<small class="info">Assign a template to the menu. If the menu links to a category, all the posts or products will use the template</small>

					<select name="assign_template" class="form-control">
					<option value="">--Use Default--</option>
					<?php foreach(templates()->get() as $template) {
					$selected = ($template->id == $tmplset->tmpl_id ? ' selected' : '');
					?>
						<option value="<?php echo $template->id; ?>"<?php echo $selected; ?>><?php echo ucfirst($template->name); ?></option>
					<?php } ?>
					</select>
				</div>
			</fieldset>

			<fieldset>
				<h5><span>Menu Class</span></h5>
				<div class="inner">
				<small class="info">A CSS class appended to menu container</small>
				<input type="text" name="menuclass" value="<?php echo $attribs->menuclass; ?>" />
				</div>
			</fieldset>

			<fieldset>
				<h5><span>Icon Class</span></h5>
				<div class="inner">
				<small class="info">Font Awesome or Glyphicon class names</small>
				<input type="text" name="menuicon" value="<?php echo $attribs->menuicon; ?>" placeholder="fas fa-home" />
				</div>
			</fieldset>

			<fieldset class="check-btn">
				<label>
					<span>
						<input type="checkbox" name="homepage" value="1" <?php echo ($menu_value->homepage == 1 ? 'checked disabled' : ''); ?> />
					</span>
					<span>Set As Home Page</span>
				</label>
			</fieldset>

			<fieldset>
				<h5><span>Order</span></h5>
				<div class="inner">
				<input type="number" name="menuorder" min="0" value="<?php echo $menu_value->menuorder; ?>" class="form-control" />
				</div>
			</fieldset>

		</div>

	</div>