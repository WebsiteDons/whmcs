<?php
/*
* Copyright (c) 2019 Emuzement Net Inc. All Rights Reserved
* License: EULA
* Author: Alex/Kumar/Manti/Lisa
*/

if( !defined("WHMCS") ) die("This file cannot be accessed directly");

use \WHMCS\Session;

// set time zone
TIMEZONE;
$now 		= date('Y-m-d H:i:s');

$returnview = $modlink.'&view=menuManager&task=list&type=menus';

		
// save menu group
if( !is_null(getPost('save_menugroup', false)) ) 
{
	try{
	menugroups()->insertGetId([
		'groupname' => getPost('groupname'),
		'state'		=> 1,
		'created_at' => $now,
		'author'	=> Session::get('adminid')
	]);
	}
	catch (\Exception $e) {
		cmseNotice($e->getMessage());
	}
}

// delete group when empty
if( !is_null(getPost('delete_group', false)) ) 
{
	try{
		menugroups()->where('id',getPost('delete_group', false))->delete();
	}
	catch (\Exception $e) {
		cmseNotice($e->getMessage());
	}
		
	redirect($returnview);
}


// delete items by checkbox
if( !is_null(getPost('item_delete', false)) ) 
{
	if( !is_null(getPost('item_delete', false)) ) {
		$dels = explode(',', getPost('items_id', false));
		try{
			menus()->whereIn('id',$dels)->delete();
		}
		catch (\Exception $e) {
			cmseNotice($e->getMessage());
		}
	}
	
	redirect($returnview);
}

// disable menu
if( !is_null(getPost('item_disable', false)) ) 
{
	$dels = explode(',', getPost('items_id', false));
	try{
		menus()->whereIn('id',$dels)->update(['published' => 2]);
	}
	catch (\Exception $e) {
		cmseNotice($e->getMessage());
	}
	redirect($returnview);
}

// enable menu
if( !is_null(getPost('item_enable', false)) ) 
{
	$dels = explode(',', getPost('items_id', false));
	try{
		menus()->whereIn('id',$dels)->update(['published' => 1]);
	}
	catch (\Exception $e) {
		cmseNotice($e->getMessage());
	}
	redirect($returnview);
}

?>


<div class="<?php echo MODNAME; ?> menugroups">

	<div class="masonry marginbottom-20">
	
	<?php 
		foreach(menugroups()->get() as $menugroup) 
		{ 
			// get menu items
			$menuitems = menus()->where('menugroup', $menugroup->id)->orderBy('menuorder', 'asc')->get();
			$gid = [];
			foreach($menuitems as $groupid) {
				$gid[] = $groupid->menugroup;
			}
	?>
		
		<div class="group">
			<h3>
				<span><?php echo $menugroup->groupname; ?></span>
				<?php if( !in_array($menugroup->id, $gid) ) { ?>
				<span class="del">
				<label>Delete <input type="checkbox" name="delete_group" value="<?php echo $menugroup->id; ?>" /></label>
				</span>
				<?php } ?>
			</h3>
			
			<table class="chart">
				<tr>
				<th>Title</th>
				<th>Created</th>
				<th>Updated</th>
				<th>ID</th>
				<th>Order</th>
				<th>State</th>
				<th>Set Home</th>
				</tr>
				
				<?php 
				// set home page
				foreach($menuitems as $menuitem) 
				{
					if( !is_null(getPost($menuitem->id.'_sethome', false)) ) {
						menus()->where('homepage', 1)->update(['homepage' => 0]);
						menus()->where('id', $menuitem->id)->update(['homepage' => 1]);
						redirect($returnview);
					}
					
					if( $menuitem->homepage == 1 ) {
						$homestate = '<i class="fas fa-home" title="item is home page"></i>';
						$sethome='';
					}else{
						$homestate = '<input type="checkbox" name="item_check" value="'.$menuitem->id.'" />
						'.($menuitem->published == 1 ? '<i class="fas fa-check-circle"></i>' : '<i class="fas fa-minus-circle"></i>');
						$sethome = '<button type="submit" name="'.$menuitem->id.'_sethome" class="smallbtn" title="set item as home page"><i class="fas fa-home"></i></button>';
					}
				?>
				<tr<?php echo ($menuitem->published == 2 ? ' class="disabled"' : ' class="enabled"'); ?>>
					<td>
					<a href="<?php echo $modlink; ?>&view=menuManager&task=edit&type=menu&menuid=<?php echo $menuitem->id; ?>">
					<?php echo $menuitem->title; ?></a>
					<br /><small>alias: <?php echo $menuitem->alias; ?></small>
					</td>
					<td>
						<?php echo dateFormat($menuitem->created_at, 'short'); ?>
						<small class="info">
						<a href="configadmins.php?action=manage&id=<?php echo $menuitem->author; ?>">
						<?php echo adminName($menuitem->author); ?></a>
						</small>
					</td>
					<td>
						<?php if( $menuitem->updated_at != '0000-00-00 00:00:00' ) { ?>
						<?php echo dateFormat($menuitem->updated_at, 'short'); ?>
						<small class="info">
						<a href="configadmins.php?action=manage&id=<?php echo $menuitem->update_author; ?>">
						<?php echo adminName($menuitem->update_author); ?></a>
						</small>
						<?php } ?>
					</td>
					<td><?php echo $menuitem->id; ?></td>
					<td><?php echo $menuitem->menuorder; ?></td>
					<td style="text-align: center;"><?php echo $homestate; ?></td>
					<td style="text-align: center;"><?php echo $sethome; ?></td>
				</tr>
				<?php 
				} ?>
				
			</table>
			
		</div>
	<?php } ?>
	</div>

</div>