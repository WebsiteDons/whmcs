<?php
/*
* Copyright (c) 2019 Emuzement Net Inc. All Rights Reserved
* License: EULA
* Author: Alex/Kumar/Manti/Lisa
*/

if( !defined("WHMCS") ) die("This file cannot be accessed directly");

$img= $imgname='';
$prodvals = cmseproducts()->select('prod_image', 'attribs')->where('prod_id', getRequest('id'))->get()[0];

if( !empty($prodvals->prod_image) ) {
	$img = '<img src="'.IMAGES.$prodvals->prod_image.'" />';
	$imgname = $prodvals->prod_image;
}
$attribs = json_decode($prodvals->attribs);
$metadesc = (!empty($attribs->metadesc) ? $attribs->metadesc : '');
$metakeys = (!empty($attribs->metakeys) ? $attribs->metakeys : '');

$wideimg= $wideimage= $wideimg_caption='';
if( isset($attribs->wide_image) && !empty($attribs->wide_image) ) {
	$wideimg = $attribs->wide_image;
	$wideimage = (!empty($attribs->wide_image) ? '<img style="width: 250px;" src="'.IMAGES.$wideimg.'" />':'');
}
if( isset($attribs->wide_imagecaption) && !empty($attribs->wide_imagecaption) ) {
	$wideimg_caption = $attribs->wide_imagecaption;
}

$prodimg = '
<script>
jQuery(function($) {
	//$("#prod_image").insertAfter("form[name=packagefrm] td.fieldarea div.row");
	$("#prodimggroup").insertAfter("form[name=packagefrm] td.fieldarea div.col-sm-5");
});
</script>
<div id="prodimggroup" class="sidefields">

	<h5><span>Meta Description</span></h5>
	<textarea name="metadesc" class="form-control">'.$metadesc.'</textarea>

	<h5><span>Meta Keywords</span></h5>
	<textarea name="metakeys" class="form-control">'.$metakeys.'</textarea>

	<h5><span>Image</span></h5>
	<div id="imgview">'.$img.'</div>
	<div id="prod_image">
		'.imageManager('prod_image', $imgname).'
		<h6>Wide Image</h6>
		'.imageManager('wide_image', $wideimg, 'wideimgname', 'wideimg').
		$wideimage.'
		<label>Caption</label>
		<textarea name="wide_imagecaption">'.$wideimg_caption.'</textarea>
	</div>
</div>
';