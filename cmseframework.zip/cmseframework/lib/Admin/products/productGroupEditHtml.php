<?php
/*
* Copyright (c) 2019 Emuzement Net Inc. All Rights Reserved
* License: EULA
* Author: Alex/Kumar/Manti/Lisa
*/

if( !defined("WHMCS") ) die("This file cannot be accessed directly");

$matches = layoutPreset();
$templates = templates()->where('parent_tpl', '<>', '')->pluck('name', 'id');
//$templates = array_merge(['' => '-- Use Default --'], $templates);
?>

<script>
jQuery(function($) {
	$("#groupconfig").insertAfter("#frmAddProductGroup table.form");
	$("#headlineinfo").insertBefore("input#headline");
});
</script>

<div id="headlineinfo" class="info">
<?php echo CMSE_CF_PRODUCT_GROUP_DESC_INTROTEXT; ?>
</div>

<div id="groupconfig">
	<div class="groupslide">
	<h5 class="slidetab"><span class="title"><?php echo CMSE_TITLE_DISPLAY_OPTIONS; ?></span></h5>
	<div class="slidecontent">

	<small class="info"><?php echo CMSE_PRODUCT_GROUP_EDIT; ?></small>
	<form class="cmseform" method="post" action="configproducts.php?action=editgroup&ids=<?php echo getRequest('ids'); ?>&saveconfigs=1">
		<fieldset>

			<?php
				field('select', 'assign_template', 'default', $templates, CMSE_LBL_ASSIGNTPL, ['class' => 'inlineblock aligntop']);
				field('textarea', 'metadesc', $metadesc, '', 'Meta Description', ['class' => 'inlineblock width_25 aligntop']);
				field('textarea', 'metakeys', $metakeys, '', 'Meta Keywords', ['class' => 'inlineblock width_25 aligntop']);
				?>
		</fieldset>

		<div class="clearall marginbottom-20">
			<div class="boxsize width_50 break">
				<h4><?php echo CMSE_LBL_GROUPVIEW_LAYOUT; ?></h4>

				<fieldset class="tablecells">
					<div>
						<label><?php echo CMSE_LBL_PRESET_FORMATS; ?></label>
						<select name="grouppreset">
							<option value=""><?php echo CMSE_DEFAULT; ?></option>
							<?php
							foreach($matches as $match) {
								//include strings beginning with any
								if( !preg_match(chr(1).'^group'.chr(1), $match[1]) )
									continue;

								$selected = ($match[1] == $configval->grouppreset ? ' selected' : '');
							?>
							<option value="<?php echo $match[1]; ?>"<?php echo $selected; ?>><?php echo $match[1]; ?></option>
							<?php } ?>
						</select>
					</div>

					<div>
						<label><?php echo CMSE_LBL_COLUMNS; ?></label>
						<input type="number" name="itemsperrow" min="0" value="<?php echo (!empty($configval->itemsperrow) ? $configval->itemsperrow : ''); ?>" />
					</div>

					<div>
						<label><?php echo CMSE_LBL_IMGHEIGHT; ?></label>
						<input type="number" name="imgmask" min="0" value="<?php echo (!empty($configval->imgmask) ? $configval->imgmask : ''); ?>" />
					</div>

					<div>
						<label><?php echo CMSE_LBL_TEXTLIMIT; ?></label>
						<input type="number" name="textlimit" min="0" value="<?php echo (!empty($configval->textlimit) ? $configval->textlimit : ''); ?>" />
					</div>

				</fieldset>

				<h6><?php echo CMSE_LBL_GROUP_PAGE_LAYOUT; ?></h6>
				<textarea class="autosize monospace form-control" name="group_detailslayout"><?php echo (!empty($configval->group_detailslayout) ? $configval->group_detailslayout : ''); ?></textarea>
				<hr />

				<h6><?php echo CMSE_LBL_GROUP_ITEMS_LAYOUT; ?></h6>
				<textarea class="autosize monospace form-control" name="groupview" placeholder="[title][image][text][price][addcart]"><?php echo (!empty($configval->groupview) ? $configval->groupview : ''); ?></textarea>
			</div>

			<div class="boxsize width_50 padleft-20 break">
				<h4>Product Group Page Image</h4>
				<div class="flex">
				<div><?php field('image', 'prodgroupimg', $configval->prodgroupimg); ?></div>
				<div><img style="max-width: 130px;" src="<?php echo IMAGES.$configval->prodgroupimg; ?>" /></div>
				</div>

				<h4><?php echo CMSE_LBL_PRODUCT_DETAIL_LAYOUT; ?></h4>

				<fieldset class="tablecells">
					<div>
						<label><?php echo CMSE_LBL_PRESET_FORMATS; ?></label>
						<select name="productpreset">
							<option value=""><?php echo CMSE_DEFAULT; ?></option>
							<?php
							foreach($matches as $match) {
								//include strings beginning with any
								if( !preg_match(chr(1).'^product'.chr(1), $match[1]) )
									continue;

								$selected = ($match[1] == $configval->productpreset ? ' selected' : '');
							?>
							<option value="<?php echo $match[1]; ?>"<?php echo $selected; ?>><?php echo $match[1]; ?></option>
							<?php } ?>
						</select>
					</div>
				</fieldset>
				<textarea class="autosize monospace form-control" name="detailview" placeholder="[title][image][text][price][addcart]"><?php echo (!empty($configval->detailview) ? $configval->detailview : ''); ?></textarea>
			</div>
		</div>


		<fieldset class="clearall text-center">
		<?php if( requestKey('ids') ) { ?>
		<button type="submit" name="addconfigs" class="btn btn-success btn-sm"><?php echo CMSE_SAVE_CONFIG; ?></button>
		<?php }else{ ?>
		<input type="submit" class="btn btn-success btn-sm" value="<?php echo CMSE_SAVE_CONFIG; ?>" disabled="disabled" />
		<p class="alert alert-info">The display override button will enabled after the group is first saved</p>
		<?php } ?>
		</fieldset>

	</form>
</div>
</div>
</div>