<?php
/*
* Copyright (c) 2019 Emuzement Net Inc. All Rights Reserved
* License: EULA
* Author: Alex/Kumar/Manti/Lisa
*/

if( !defined("WHMCS") ) die("This file cannot be accessed directly");

if( getRequest('action') == 'editgroup' )
	$edit = true;

if( $edit )
{
	// get template assigned
	$tmplset = tplassign()
		->where([['type', 'productgroup'],['resource', getRequest('ids')]])
		->select('id', 'tmpl_id', 'resource', 'type')
		->get()[0];

	$template = $tmplset->tmpl_id;
}

if( requestKey('saveconfigs') && getRequest('saveconfigs') == 1 )
{
	$configs = [
	'textlimit'		=> getPost('textlimit', false),
	'group_detailslayout' => getPost('group_detailslayout'),
	'groupview'		=> getPost('groupview', false),
	'detailview'	=> getPost('detailview', false),
	'itemsperrow'	=> getPost('itemsperrow', false),
	'imgmask'		=> getPost('imgmask', false),
	'grouppreset'	=> getPost('grouppreset', false),
	'productpreset' => getPost('productpreset', false),
	'metadesc'		=> strip_tags(getPost('metadesc')),
	'metakeys'		=> strip_tags(getPost('metakeys')),
	'prodgroupimg'	=> getPost('prodgroupimg', false)
	];
	
	try{
		cmseproducts()->where('group_id', getRequest('ids'))->update(['group_configs' => json_encode($configs)]);
	} catch (\Exception $e) {
		cmseNotice($e->getMessage());
	}

	// save template assignment if set
	if( getPost('assign_template', false) != '' )
	{
		$tmpl = [
		'tmpl_id' => getPost('assign_template', false),
		'resource' => getRequest('ids'),
		'type' => 'productgroup',
		'created_at' => setDate()
		];
		try{
			tplassign()->insertGetId($tmpl);
		} catch (\Exception $e) {
			cmseNotice($e->getMessage());
		}
	}else
	// delete the row when set to default template
	if( $tmplset->resource == getRequest('ids') ) {
		try{
			tplassign()->where([['resource', getRequest('ids')], ['type', 'productgroup']])->delete();
		} catch (\Exception $e) {
			cmseNotice($e->getMessage());
		}
	}

	redirect('configproducts.php?action=editgroup&ids='.getRequest('ids'));
}

$configvals = cmseproducts()->where('group_id', getRequest('ids'))->value('group_configs');
$configval = json_decode($configvals);
$metakeys = $configval->metakeys;
$metadesc = $configval->metadesc;

ob_start();
include LIB_PATH.'/Admin/products/productGroupEditHtml.php';
$groupconfig = ob_get_clean();