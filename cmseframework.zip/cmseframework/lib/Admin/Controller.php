<?php
/*
* Copyright (c) 2019 Emuzement Net Inc. All Rights Reserved
* License: EULA
* Author: Alex/Kumar/Manti/Lisa
*/

namespace WHMCS\Module\Addon\Cmseframework\Admin;

if( !defined("WHMCS") ) die("This file cannot be accessed directly");

use \WHMCS\Session;


class Controller
{
    public function index($vars)
    {
		$modlink = $vars['modulelink'];
		$view = (requestKey('view') ? getRequest('view') : '');
		$task = (requestKey('task') ? getRequest('task') : '');
		$type = (requestKey('type') ? getRequest('type') : '');
		
		$path = LIB_PATH.'/Admin';
		
		echo '<form action="" method="post" enctype="multipart/form-data" class="cmseform">';
		include LIB_PATH.'/Admin/toolbar.php';
		
		if( !requestKey('view') ) {
			include LIB_PATH.'/Admin/cmseadmin.php';
		}
		
		// posts
		if( $view == 'postManager' ) 
		{
			$path = $path.'/postManager';
			
			if( $task == 'list' && $type == 'posts' ) 
				include $path.'/posts.php';
			if( $task == 'edit' && $type == 'post' )
				include $path.'/postEdit.php';
			if( $task == 'list' && $type == 'categories' )
				include $path.'/categories.php';
			if( $task == 'edit' && $type == 'category' )
				include $path.'/categoryEdit.php';
		}
		// menus
		if( $view == 'menuManager' ) 
		{
			$path = $path.'/menuManager';
			
			if( $task == 'list' && $type == 'menus' ) 
				include $path.'/menus.php';
			if( $task == 'edit' && $type == 'menu' )
				include $path.'/menuEdit.php';
		}
		// widgets
		if( $view == 'widgetManager' ) 
		{
			$path = $path.'/widgetManager';
			
			if( $task == 'list' && $type == 'widgets' ) 
				include $path.'/widgets.php';
			if( $task == 'edit' && $type == 'widget' )
				include $path.'/widgetEdit.php';
		}
		// banners
		if( $view == 'bannerManager' ) 
		{
			$path = $path.'/bannerManager';
			
			if( $task == 'list' && $type == 'banners' ) 
				include $path.'/banners.php';
			if( $task == 'edit' && $type == 'banner' ) 
				include $path.'/bannerEdit.php';
			if( $task == 'list' && $type == 'categories' ) 
				include $path.'/categories.php';
			if( $task == 'edit' && $type == 'category' ) 
				include $path.'/categoryEdit.php';
		}
		
		// full admin access
		if( fullAdmin(Session::get('adminid')) ) 
		{
			// global configuration
			if( $view == 'configs' )
				include $path.'/globalConfig.php';
			// installer
			if( $view == 'installer' )
				include $path.'/installer.php';
			// template manager
			if( $view == 'templateManager' ) 
			{
				$path = $path.'/templateManager';
				if( $task == 'list' ) 
					include $path.'/templates.php';
				
				if( $task == 'templateEdit' ) 
					include $path.'/templateEdit.php';
				
				if( $task == 'templateConfig' ) 
					include $path.'/templateConfig.php';
				
				if( $task == 'templateCopy' ) 
					include $path.'/templateCopy.php';
				if( $task == 'templateAdminEdit' ) 
					include $path.'/templateAdminEdit.php';
				
			}
			
			// language edit
			if( $view == 'languageManager' ) 
				include $path.'/languageManager/languageEdit.php';
		}
		
		echo '</form>';
        cmseVersion($vars);
    }

}
