<?php
/*
* Copyright (c) 2019 Emuzement Net Inc. All Rights Reserved
* License: EULA
* Author: Alex/Kumar/Manti/Lisa
*/

$noimage = $liburl.'assets/images/noimage.png';
$pornhubimg = $liburl.'assets/images/pornhub.png';

?>

<div id="videoplayer" class="vidblock">

<?php

	// check for characters that identify entry as playlist and output the playlist template
	if( $itemcount >= 1 ) 
	{
		// get first item of the playlist to serve as the default iframe item
		$first='';
		if ( strpos($firstitem, 'view_video.php?viewkey=')) {
			$first = str_replace('view_video.php?viewkey=', 'embed/', $firstitem);
		}else
		if ( (strpos($firstitem, 'tube8.com')) && (!strpos($firstitem, 'embed')) ) {
			$first = str_replace('tube8.com', 'tube8.com/embed', $firstitem);
		}else
		if ( (strpos($firstitem, 'redtube.com')) && (!strpos($firstitem, 'embed')) ) {
			$first = str_replace('www.redtube.com/', 'embed.redtube.com/?id=', $firstitem);
		}else
		if ( strpos($firstitem, 'www.xvideos.com') ) {
			$first = str_replace('www.xvideos.com/video', 'flashservice.xvideos.com/embedframe/', $firstitem);
		}else
		if ( strpos($firstitem, 'xnxx.com') ) {
			$first = str_replace('www.xnxx.com/video', 'flashservice.xvideos.com/embedframe/', $firstitem);
		}else
		if ( strpos($firstitem, 'xhamster.com') ) {
			$first = 'http://xhamster.com/xembed.php?video='.getInnerstring($firstitem, 'movies/', '/');
		}else
		if( strpos($firstitem, 'dailymotion.com') ) {
			$first = str_replace('dailymotion.com', 'dailymotion.com/embed', $firstitem);
			$first = $first.'?sharing-enable=0&ui-logo=0&ui-start_screen_info=0&endscreen-enable=0&autoplay='.$autoplay;
		}else
		if ( strpos($firstitem, 'facebook.com') ) {
			$first = str_replace($firstitem, 'https://www.facebook.com/plugins/video.php?href='.$firstitem.'&autoplay=false&mute=false', $firstitem);
		}else
		if( strpos($firstitem, 'youtu') ) {
			$first = 'https://www.youtube.com/embed/'.getYoutubeID($firstitem).'?wmode=opaque&modestbranding=1&showinfo=0&rel=0&autohide=1&autoplay='.$autoplay;
		}else
		if( strpos($firstitem, 'vimeo.com') ) {
			$first = str_replace('vimeo.com', 'player.vimeo.com/video', $firstitem);
			$first = $first.'?autoplay='.$autoplay;
		}else{
		// use the exact supplied iframe embed src URL
		$first = $firstitem;
		}
		// add overlay to block players that open popup when click to stop on the player screen
		if( !preg_match('/\b(pornhub|xvideos.com|tube8.com|redtube.com|xhamster|embed.php)\b/', $first) ) {
			echo '<style>span.vidoverlay {display: none !important;}</style>';
		}

?>

		<div class="vidwrap playlistvid">
		<?php // echo $videoad; ?>
		<!-- span class="vidoverlay"><img src="<?php echo $liburl; ?>images/blank.png" /></span -->
		<iframe name="vidframe" id="vidframe" src="<?php echo $first; ?>" frameborder="0" scrolling="no" allowfullscreen seamless></iframe>
		</div>
		<div id="plist">
		<ul>
			<?php 
			
			foreach($vid as $vidpart) 
			{
				$xvid = $vidpart->url;
				$ytimage = $noimage;
				$ytitle = 'Video';
				if( !empty($vidpart->title) ) 
					$ytitle = $vidpart->title;
				
				//---[ Facebook ]
				if ( strpos($xvid, 'facebook.com') ) 
				{
					if( stristr($xvid, 'www') ) {
						$data = get_remote_data(str_replace('www', 'm', $xvid));
					}else{
						$data = get_remote_data($xvid);
					}
					
					$xvid = str_replace($xvid, 'https://www.facebook.com/plugins/video.php?href='.$xvid.'&autoplay=true&mute=false', $xvid);

					$data = strip_tags($data, '<p><img>');
					$ytitle = substr(getInnerstring($data, '<p>', '</p>'), 0, 50);

					$ytimage = explode('<img', $data);
					$ytimage = getInnerstring($ytimage[2], 'src="', '" class="s"');

				}
				//---[ Dailymotion ]
				if ( strpos($xvid, 'dailymotion.com') ) 
				{
					//get dailymotion image and title with oEmbed
					$dmm = simplexml_load_file('http://www.dailymotion.com/services/oembed?url='.urlencode($vidpart->url).'&format=xml');
					$xvid = str_replace('dailymotion.com', 'dailymotion.com/embed', $xvid);
					$xvid = $xvid.'?sharing-enable=0&ui-logo=0&ui-start_screen_info=0&endscreen-enable=0&autoplay=1';
					if( isset($dmm->title) ) 
						$ytitle = $dmm->title;

					if( isset($dmm->thumbnail_url) ) 
						$ytimage = $dmm->thumbnail_url;
				}
				//---[ Youtube ]
				if ( strpos($xvid, 'youtu') ) 
				{
					$vidID = getYoutubeID($vidpart->url);
					$xvid = 'https://www.youtube.com/embed/'.$vidID.'?wmode=opaque&modestbranding=1&showinfo=0&rel=0&autohide=1&autoplay=1';
					$ytimage = 'https://img.youtube.com/vi/'.$vidID.'/mqdefault.jpg';
					$ytitle = getYoutubeTitle($vidID);
				}
				//---[ Google Drive ]
				if ( strpos($xvid, 'drive.google') ) 
				{
					if( strpos($xvid, 'open?id') ) {
						$xvid = 'https://drive.google.com/file/d/'.getInnerstring($xvid.'/', 'open?id=', '/').'/preview';
					}else{
						$xvid = str_replace('view?usp=sharing', 'preview', $xvid);
					}
				}
				//---[ Vimeo ]
				if ( strpos($xvid, 'vimeo.com') ) 
				{
					$xvid = str_replace('vimeo.com', 'player.vimeo.com/video', $xvid);
					$ytimage = str_replace('https://player.vimeo.com/video/', '', $xvid);
					$ytimage = getVimeoThumb($ytimage);
					$xvid = $xvid.'?autoplay=1';
				}
				//---[ pornhub ]
				if ( strpos($xvid, 'view_video.php?viewkey=')) 
				{
					$xvid = str_replace('view_video.php?viewkey=', 'embed/', $xvid);
					//get thumb and title
					$url = 'http://www.pornhub.com/webmasters/video_by_id?id='.str_replace('view_video.php?viewkey=','',basename($vidpart->url));
					$url = json_decode(get_remote_data($url));
			
					if( !empty($url->video->thumb) ) {
						$ytitle = $url->video->title;
						$ytimage = $url->video->thumb;
					}else{
						$ytitle = JText::_('NO_PORNHUB_TITLE');
						$ytimage = $pornhubimg;
					}

				}
				if ( (strpos($xvid, 'tube8.com')) && (!strpos($xvid, 'embed')) ) {
					$xvid = str_replace('tube8.com', 'tube8.com/embed', $xvid);
				}
				if ( (strpos($xvid, 'redtube.com')) && (!strpos($xvid, 'embed')) ) {
					$xvid = str_replace('www.redtube.com/', 'embed.redtube.com/?id=', $xvid);
				}
				if ( strpos($xvid, 'www.xvideos.com') ) {
					$xvid = str_replace('www.xvideos.com/video', 'flashservice.xvideos.com/embedframe/', $xvid);
				}
				if ( strpos($xvid, 'xnxx.com') ) {
					$xvid = str_replace('www.xnxx.com/video', 'flashservice.xvideos.com/embedframe/', $xvid);
				}
				if ( strpos($xvid, 'xhamster.com') ) {
					$xvid = 'http://xhamster.com/xembed.php?video='.getInnerstring($xvid, 'movies/', '/');
				}
				if ( strpos($xvid, 'spankbang.com') ) 
				{
					$xvid = 'https://spankbang.com/'.getInnerstring($xvid, '.com/', '/video').'/embed/';
					$scrape = strip_tags(file_get_contents($xvid));
					$ytimage = getInnerstring($scrape, "var cover_image = '", "';");
					$ytitle = str_replace('+', ' ', getInnerstring($scrape, "video/", "'"));
				}

				?>
				<li>
					<a href="javascript:replaceIframeURL('vidframe', '<?php echo $xvid; ?>');">
						<span class="plimg"><img src="<?php if(!empty($vidpart->image)) echo $vidpart->image; else echo $ytimage; ?>" /></span>
						<span class="pltext"><?php if(!empty($vidpart->title)) echo $vidpart->title; else echo $ytitle; ?></span>
					</a>
				</li>
	<?php } // end loop ?>
		</ul>
	</div>


<?php } else
	// load single video template if not playlist
	 {

	$xvid = $firstitem;
	if ( strpos($xvid, 'dailymotion.com') ) {
		$xvid = str_replace('dailymotion.com', 'dailymotion.com/embed', $xvid);
		$xvid = $xvid.'?sharing-enable=0&ui-logo=0&ui-start_screen_info=0&endscreen-enable=0&autoplay='.$autoplay;
		}
	//---[ Facebook ]
	if ( strpos($xvid, 'facebook.com') ) {
		$xvid = str_replace($xvid, 'https://www.facebook.com/plugins/video.php?href='.$xvid.'&mute=0&autoplay='.$autoplay, $xvid);
		if( is_object(apiData($firstitem)) ) {
			$format = end(apiData($firstitem)->format);
			/*if( isset($format->picture) ) {
				if( (int)$format->width <= (int)$format->height ) {
					$document->addStyleDeclaration('div.vidwrap {padding-bottom: 68.25%; max-width: 600px; margin: auto;}');
				}
				//else
				//if( (int)$format->width/50 !== 16 ) {
				//	$document->addStyleDeclaration('div.vidwrap {max-width: 100%; margin: auto;}');
				//}
			}*/
			if( isset(apiData($firstitem)->title) ) {
				$ytitle = ucwords(apiData($firstitem)->title);
			}elseif( isset(apiData($firstitem)->description) ) {
				$ytitle = substr(apiData($firstitem)->description, 0, 100).'...';
			}
		}else{
			//$document->addStyleDeclaration('div.vidwrap {padding-bottom: 78.25%; max-width: 380px; margin: auto;}');
		}
	}
	//---[ Youtube ]
	if ( strpos($xvid, 'youtu') ) {
		$youid = getYoutubeID($xvid);
		$qtype = '?';
		if( strpos($xvid, 'list=') ) $qtype = '&';
		if( strpos($xvid, '&list=') ) {

			$youid = str_replace('&list', '?list', $youid);
		}
		$xvid = 'https://www.youtube.com/embed/'.$youid.$qtype.'wmode=opaque&modestbranding=1&showinfo=0&rel=0&autohide=1&autoplay='.$autoplay;
		}
	//---[ Google Drive ]
	if ( strpos($xvid, 'drive.google') ) {
		if( strpos($xvid, 'open?id') ) {
			$xvid = 'https://drive.google.com/file/d/'.getInnerstring($xvid.'/', 'open?id=', '/').'/preview';
		}else{
			$xvid = str_replace('view?usp=sharing', 'preview', $xvid);
		}
	}
	//---[ Vevo ]
	if ( strpos($xvid, 'vevo') ) {
		$xvid = 'http://cache.vevo.com/assets/html/embed.html?video='.getVevoID($videovalue).'&autoplay='.$autoplay;
		}
	//---[ Vimeo ]
	if ( (strpos($xvid, 'vimeo.com')) && (!strpos($xvid, 'player.vimeo.com')) ) {
		$xvid = str_replace('vimeo.com', 'player.vimeo.com/video', $xvid);
		$xvid = $xvid.'?autoplay='.$autoplay;
		}
		// pornhub
	if ( strpos($xvid, 'view_video.php?viewkey=')) {
		$xvid = str_replace('view_video.php?viewkey=', 'embed/', $xvid);		
		}
	if ( (strpos($xvid, 'tube8.com')) && (!strpos($xvid, 'embed')) ) {
		$xvid = str_replace('tube8.com', 'tube8.com/embed', $xvid);
		}
	if ( (strpos($xvid, 'redtube.com')) && (!strpos($xvid, 'embed')) ) {
		$xvid = str_replace('www.redtube.com/', 'embed.redtube.com/?id=', $xvid);
		}
	if ( strpos($xvid, 'www.xvideos.com') ) {
		$xvid = str_replace('www.xvideos.com/video', 'flashservice.xvideos.com/embedframe/', $xvid);
		}
	if ( strpos($xvid, 'xnxx.com') ) {
		$xvid = str_replace('www.xnxx.com/video', 'flashservice.xvideos.com/embedframe/', $xvid);
		}
	if ( strpos($xvid, 'xhamster.com') ) {
		$xvid = 'http://xhamster.com/xembed.php?video='.getInnerstring($xvid, 'movies/', '/');
		}
	if( strpos($xvid, 'issuu') ) {
		$xvid = str_replace('https://issuu.com/caribbeanamericanpassport/docs/', 'https://e.issuu.com/anonymous-embed.html?u=caribbeanamericanpassport&d=', $xvid);
	}
		
	if( !preg_match('/\b(pornhub|xvideos.com|tube8.com|redtube.com|xhamster|embed.php)\b/', $xvid) ) {
		echo '<style>span.vidoverlay, span.playicon {display: none !important;}</style>';
	}
	?>

	<div class="vidwrap singlevid">
		<div class="vidinner">
			<?php 
			$vidsrc = ['pornhub', 'xhamster', 'xvideos', 'xnxx', 'redtube', 'tube8'];
			if( inString($xvid, $vidsrc) ) { ?>
			<div class="vidoverlay"></div>
			<?php } ?>
			
			<?php if( strstr($xvid, '.mp4') ) { ?>
				<style>
				.vidwrap {padding: 0 !important; height: auto !important;} 
				video {width: 100%; max-height: 500px;}
				</style>
				<video src="<?php echo $xvid; ?>" controls></video>
			<?php }else if( strstr($xvid, '.mp3') ) { ?>
				<style>
				div.vidblock {margin: 0;}
				.vidwrap {padding: 0; height: auto; overflow: visible; border: 0; padding: 0;} 
				audio {width: 100%; display: block; clear: both; float: none;}
				</style>
				<audio src="<?php echo $xvid; ?>" controls></audio>
			<?php }else{ ?>
				<iframe src="<?php echo $xvid; ?>" frameborder="0" scrolling="no" seamless></iframe>
			<?php } ?>
		</div>
	</div>
	<span class="playicon"><i class="fa fa-arrow-up"></i>Click Play</span>


<?php }// end condition for playlist

?>

</div>
