<?php 
/*
* Copyright (c) 2019 Emuzement Net Inc. All Rights Reserved
* License: EULA
* Author: Alex/Kumar/Manti/Lisa
*/

if( !defined("WHMCS") ) die("This file cannot be accessed directly");

$itemattribs->slidesort = 1;
$itemattribs->transition = 0;
$itemattribs->slideshow = 0;
$itemattribs->slidewidth = 30;
$itemattribs->thumbcount = 5;
$itemattribs->slideautoplay = 1;

$slideatt = $itemattribs->slideattrib;

scriptFile(LIB_URL.'/cmse/slideshow/jssor.slider-21.1.5.min.js');
inlineCss('.jssorwrap {height:'.$slideatt->slideheight.'px;}');


if( isset($itemattribs->slidesort) && $itemattribs->slidesort )
	shuffle($slides);
$defaultimg = ASSET_URL.'/images/noimage.png'; 
	
$transitions= $count= $thumbopt= $hbar= $sidenav= $jssorthumbnav='';
if( $itemattribs->transition ) {
	include_once __DIR__ . '/transitions.php';
}
//---bottom navigation
if( $itemattribs->slideshow == 2 ) {
	$thumbopt = '$Align: 360';
	$hbar = 'hbar';
	$jssorthumbnav = '
		<div data-u="thumbnavigator" class="slidenav-hbar" data-autocenter="1">
			<div data-u="slides">
				<div data-u="prototype" class="navitem">
					<div data-u="thumbnailtemplate" class="frm"></div>
				</div>
			</div>
		</div>
	';
}else
//---side navigation
if( $itemattribs->slideshow == 3 ) 
{
	$sidenavwidth = (100 - $itemattribs->slidewidth);
	$eachheight = ($slideatt->slideheight / $itemattribs->thumbcount - 6);
	$thmimgheight = ($eachheight -10);
	inlineCss('
		.item-'.$item->id.' .jssorwrap.sidenav .jssorslides {width: '.$itemattribs->slidewidth.'%;}
		.item-'.$item->id.' .slidenav-sidebar {width: '.$sidenavwidth.'%;}
		.item-'.$item->id.' .slidenav-sidebar .navitem {height: '.$eachheight.'px;}
		.item-'.$item->id.' .slidenav-sidebar .img img {max-height: '.$thmimgheight.'px;}
		
	');
	$thumbopt = '$Orientation: 2,$Align: 0';
	$sidenav = 'sidenav';
	$jssorthumbnav = '
		<div data-u="thumbnavigator" class="slidenav-sidebar" data-autocenter="2">
			<div data-u="slides">
				<div data-u="prototype" class="navitem">
					<div data-u="thumbnailtemplate" class="frm"></div>
				</div>
			</div>
		</div>
	';
}

inlineJs('
jssor_'.$item->id.'_slider_init = function() {

	var random = Math.floor(Math.random() * '.$itemattribs->thumbcount.');
	var jssor_'.$item->id.'_options = {
		$AutoPlay: '.$itemattribs->slideautoplay.',
		$StartIndex: 0,
		$Idle: '.$slideatt->slidedelay.',
		$SlideDuration: 800,
		$SlideEasing: $Jease$.$OutQuint,
		$SlideShowOptions: {
			$Class: $JssorSlideshowRunner$,
			$Transitions: ['.$transitions.'],
			$TransitionsOrder: 1
			},
		$CaptionSliderOptions: {
			$Class: $JssorCaptionSlideo$
		},
		$ArrowNavigatorOptions: {
			$Class: $JssorArrowNavigator$
		},
		$BulletNavigatorOptions: {
			$Class: $JssorBulletNavigator$
		},
		$ThumbnailNavigatorOptions: {
			$Class: $JssorThumbnailNavigator$,
			$Cols: '.$itemattribs->thumbcount.',
			$SpacingX: 4,
			$SpacingY: 4,
			'.$thumbopt.'
		  }
	};

	var jssor_'.$item->id.'_slider = new $JssorSlider$("jssor_'.$item->id.'", jssor_'.$item->id.'_options);

	//responsive code begin
		function ScaleSlider() {
			var refSize = jssor_'.$item->id.'_slider.$Elmt.parentNode.clientWidth;
			if (refSize) {
				refSize = Math.min(refSize, 2000);
				jssor_'.$item->id.'_slider.$ScaleWidth(refSize);
			}
			else {
				window.setTimeout(ScaleSlider, 30);
			}
		}
		ScaleSlider();
		$Jssor$.$AddEvent(window, "load", ScaleSlider);
		$Jssor$.$AddEvent(window, "resize", ScaleSlider);
		$Jssor$.$AddEvent(window, "orientationchange", ScaleSlider);
	//responsive code end
	};
');

$jssorwrap = '<div id="jssor_'.$item->id.'" class="jssorwrap '.$hbar.$sidenav.'">';
$jssorclose = '</div>';
$jssorattrib = 'data-u="slides"';
$jssorclass = ' jssorslides';
$jssornav = '';
$jssorthumbs = '<div data-u="thumb"><span class="img"><img src="'; $jssorthumbclose = '" /></span>';
$jssorthumbend = '</div>';

$jssorinit = '<script>jssor_'.$item->id.'_slider_init();</script>';
?>

<div class="item-<?php echo $item->id; ?> article-slide">

<?php echo $jssorwrap; ?>

<div <?php echo $jssorattrib; ?> class="slidelist<?php echo $jssorclass; ?>">
<?php

	foreach( $itemattribs->slide as $slide ) 
	{
		$data = cmseElements(html_entity_decode($slide->html));
		$imagelink= $linkclose='';
		if( isset($slide->imagelink) && !empty($slide->imagelink) ) {
			$imagelink = '<a href="'.$slide->imagelink.'">';
			$linkclose = '</a>';
		}
		
		if( empty($data) && empty($slide->image) ) {}else{
		echo '<div>';
		
		if( !empty($data) && !empty($slide->image) ) {
			echo '<div class="boxsize width_70">'.$imagelink.'<img src="'.$slide->image.'" />'.$linkclose.'</div>';
			echo '<div class="boxsize width_30 padleft-20 padright-20">'.$data.'</div>';
		}else
		if( isset($slide->image) && !empty($slide->image) ) {
			echo $imagelink.'<img src="'.$slide->image.'" />'.$linkclose;
		}else{
			echo $data;
		}
		
		//---slideshow navigation thumbnails
		if( $itemattribs->slideshow == 2 || $itemattribs->slideshow == 3 ) 
		{
			$thumb = $defaultimg;
			if( strstr($data, '[article') ) {
				preg_match('#<img.+src=[\'"](?P<src>.+?)[\'"].*>#i', $data, $img);
				if( isset($img['src']) )
					$thumb = $img['src'];
			}else
			if( !empty($slide->image) ) {
				$thumb = $slide->image;
			}
			echo $jssorthumbs . $thumb . $jssorthumbclose;
			
			//---side nav title element
			if( $itemattribs->slideshow == 3 ) {
				echo '<div class="text"><h5>'.$slide->slidetitle.'</h5></div>';
			}
			echo $jssorthumbend;
		}
		echo '</div>';
		}
	}

?>
</div>

<?php 
echo $jssorthumbnav;
echo $jssorclose; 
echo $jssorinit;
?>


</div><!-- end slideshow parent -->	
