<?php 
/*
* Copyright (c) 2019 Emuzement Net Inc. All Rights Reserved
* License: EULA
* Author: Alex/Kumar/Manti/Lisa
*/

if( !defined("WHMCS") ) die("This file cannot be accessed directly");


$defaultimg = ASSET_URL.'/images/noimage.png'; 
	
$transitions= $count= $thumbopt= $hbar= $sidenav= $jssorthumbnav='';
if( $transition ) {
	include_once __DIR__ . '/transitions.php';
}

//---bottom navigation
if( $nav == 2 ) {
	$thumbopt = '$Align: 360';
	$hbar = 'hbar';
	$jssorthumbnav = '
		<div data-u="thumbnavigator" class="slidenav-hbar" data-autocenter="1">
			<div data-u="slides">
				<div data-u="prototype" class="navitem">
					<div data-u="thumbnailtemplate" class="frm"></div>
				</div>
			</div>
		</div>
	';
}else
//---side navigation
if( $nav == 1 ) 
{
	$sidenavwidth = (100 - $navwidth);
	$eachheight = ($height / $navcount - 6);
	$thmimgheight = ($eachheight -10);
	inlineCss('
		.item-'.$id.' .jssorwrap.sidenav .jssorslides {width: '.$width.'%;}
		.item-'.$id.' .slidenav-sidebar {width: '.$sidenavwidth.'%;}
		.item-'.$id.' .slidenav-sidebar .navitem {height: '.$eachheight.'px;}
		.item-'.$id.' .slidenav-sidebar .img img {max-height: '.$thmimgheight.'px;}
	');
	$thumbopt = '$Orientation: 2,$Align: 0';
	$sidenav = 'sidenav';
	$jssorthumbnav = '
		<div data-u="thumbnavigator" class="slidenav-sidebar" data-autocenter="2">
			<div data-u="slides">
				<div data-u="prototype" class="navitem">
					<div data-u="thumbnailtemplate" class="frm"></div>
				</div>
			</div>
		</div>
	';
}

//inlineCss('#jssor_'.$id.' {height: '.$height.'px;}');

inlineJs('
jssor_'.$id.'_slider_init = function() 
{
	var jssor_'.$id.'_SlideoTransitions = [
		[{b:-1,d:1,o:-0.7}],
		[{b:900,d:2000,x:-379,e:{x:7}}],
		[{b:900,d:2000,x:-379,e:{x:7}}],
		[{b:-1,d:1,o:-1,sX:2,sY:2},{b:0,d:900,x:-171,y:-341,o:1,sX:-2,sY:-2,e:{x:3,y:3,sX:3,sY:3}},{b:900,d:1600,x:-283,o:-1,e:{x:16}}]
	];

	var jssor_'.$id.'_options = {
		$AutoPlay: '.$autostart.',
		$SlideDuration: '.$slidespeed.',
		$Idle: '.$delay.',
		$SlideEasing: $Jease$.$OutQuint,
		$CaptionSliderOptions: {
			$Class: $JssorCaptionSlideo$,
			$Transitions: jssor_'.$id.'_SlideoTransitions
		},
		$ArrowNavigatorOptions: {
			$Class: $JssorArrowNavigator$
		},
		$BulletNavigatorOptions: {
			$Class: $JssorBulletNavigator$
		}
	};

	var jssor_'.$id.'_slider = new $JssorSlider$("jssor_'.$id.'", jssor_'.$id.'_options);

	/*#region responsive code begin*/

	var MAX_WIDTH = 3000;

	function ScaleSlider() {
		var containerElement = jssor_'.$id.'_slider.$Elmt.parentNode;
		var containerWidth = containerElement.clientWidth;

		if (containerWidth) {
			var expectedWidth = Math.min(MAX_WIDTH || containerWidth, containerWidth);
			jssor_'.$id.'_slider.$ScaleWidth(expectedWidth);
		}
		else {
			window.setTimeout(ScaleSlider, 30);
		}
	}

	ScaleSlider();

	$Jssor$.$AddEvent(window, "load", ScaleSlider);
	$Jssor$.$AddEvent(window, "resize", ScaleSlider);
	$Jssor$.$AddEvent(window, "orientationchange", ScaleSlider);
	/*#endregion responsive code end*/
};
');

$jssorwrap = '<div id="jssor_'.$id.'" class="jssorwrap '.$hbar.$sidenav.'" style="height: '.$height.'px;">';
$jssorclose = '</div>';
$jssorattrib = 'data-u="slides"';
$jssorclass = ' jssorslides';
$jssornav = '';
$jssorthumbs = '<div data-u="thumb"><span class="img"><img src="'; $jssorthumbclose = '" /></span>';
$jssorthumbend = '</div>';

$jssorinit = '<script>jssor_'.$id.'_slider_init();</script>';
?>

<div class="item-<?php echo $id; ?> article-slide">

<?php echo $jssorwrap; ?>

<div <?php echo $jssorattrib; ?> class="slidelist<?php echo $jssorclass; ?>">
<?php

	foreach( $slides as $slide ) 
	{
		$data = cmseElements(html_entity_decode($slide));
		$imagelink= $linkclose='';
		if( isset($slide->imagelink) && !empty($slide->imagelink) ) {
			$imagelink = '<a href="'.$slide->imagelink.'">';
			$linkclose = '</a>';
		}
		
		if( empty($data) && empty($slide->image) ) {}else{
		echo '<div>';
		
		if( !empty($data) && !empty($slide->image) ) {
			echo '<div class="boxsize width_70">'.$imagelink.'<img src="'.$slide->image.'" />'.$linkclose.'</div>';
			echo '<div class="boxsize width_30 padleft-20 padright-20">'.$data.'</div>';
		}else
		if( isset($slide->image) && !empty($slide->image) ) {
			echo $imagelink.'<img src="'.$slide->image.'" />'.$linkclose;
		}else{
			echo $data;
		}
		
		//---slideshow navigation thumbnails
		if( $nav == 1 || $nav == 2 ) 
		{
			$thumb = $defaultimg;
			if( strstr($data, '[article') ) {
				preg_match('#<img.+src=[\'"](?P<src>.+?)[\'"].*>#i', $data, $img);
				if( isset($img['src']) )
					$thumb = $img['src'];
			}else
			if( !empty($slide->image) ) {
				$thumb = $slide->image;
			}
			echo $jssorthumbs . $thumb . $jssorthumbclose;
			
			//---side nav title element
			if( $itemattribs->slideshow == 3 ) {
				echo '<div class="text"><h5>'.$slide->slidetitle.'</h5></div>';
			}
			echo $jssorthumbend;
		}
		echo '</div>';
		}
	}

?>
</div>

<?php 
echo $jssorthumbnav;
echo $jssorclose; 
echo $jssorinit;
?>


</div><!-- end slideshow parent -->	
