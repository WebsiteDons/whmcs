
<?php
$time_zone = "1";
$rooturl = "http://websitedons.net/demo/whmcs/";
$imgdir = "images";
$current = "/home/websnet/public_html/demo/whmcs/images/";
$tplname = "";
$modname = "cmseframework";
