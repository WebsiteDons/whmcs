<?php 
/*
* Copyright (c) 2019 Emuzement Net Inc. All Rights Reserved
* License: EULA
* Author: Alex/Kumar/Manti/Lisa
*/

if( !defined("WHMCS") ) die("This file cannot be accessed directly");

scriptFile(LIB_URL.'/cmse/audioplayer/jquery.jplayer.min.js');

if( $item_count == 1 && (strstr($first_item, 'soundcloud') || strstr($first_item, 'piff.me')) ) 
{
	// Get Soundcloud
	if( strpos($first_item, 'soundcloud') ) 
	{
		$frmheight = '166';
		// if the URL is a playlist the height must be increased
		if( strpos($first_item, 'sets') ) {$frmheight = '566';}

		$url = 'https://soundcloud.com/oembed?url='.urlencode($first_item).'&format=json';
		$url = $url.'&color=ff5500&auto_play=1&hide_related=true&show_comments=false&show_user=false&show_reposts=false&show_artwork=true&maxheight='.$frmheight;

		$result = file_get_contents($url);
		$result = json_decode($result);
		if( isset($result->html) ) {
		echo str_replace('visual=true&', '', $result->html);
		}else{ echo '<p class="alert1">the stream source is unavailable</p>';}
	}
	else
	// get Datpiff must be generated from the share short url
	if( strpos($first_item, 'piff.me') ) {
		$fileid = str_replace('http://piff.me/','',$first_item);
		echo '<iframe src="http://www.datpiff.com/embed/m'.$fileid.'/" width="100%" height="270" scrolling="no" frameborder="0"></iframe>';
	}
}
else
{
	
	//--------[ GET SINGLE LIVE INTERNET RADIO STREAM ]-------------------//

	$auto_start = ''; $autostart = 0;
	if( $autoplayaudio == '1' ) {
		$auto_start = '.jPlayer("play")';
		$autostart = 1;
	} 

	//check if the stream source is rtmp or mp3
	if(mb_substr($first_item, 0, 4)=='rtmp') {
		$streamtype = 'rtmp'; 
	}else
	if(strstr($first_item, 'm4a') ) {
		$streamtype = 'm4a'; 
	}
	else {
		$streamtype = 'mp3';
	}
	
	// set toggle function for playlist when player is positioned at the bottom
	if( $playerposition == 'fixed' ) 
	{
		inlineCss('body {margin-bottom: 90px !important;}');
		inlineJs('
		// slide panel
		jQuery(function($) {
			$("#jp_container'.$playerid.' .jp-playlist .slidepanel").hide();
			$(".slideswitch").click(function() {
				$("#jp_container'.$playerid.' .jp-playlist .slidepanel").slideToggle("slow");
			});
			$("#jp_container'.$playerid.' .jp-playlist .slidepanel").click(function() {
				$("#jp_container'.$playerid.' .jp-playlist .slidepanel").slideToggle("slow"); 
			});
			$(document).on("blur", function() {
				$("#jp_container'.$playerid.' .jp-playlist .slidepanel").hide("slow");
			});
		});
		');
	}
	




// playlist
if( $item_count > 1 ) {

	$playlistJS = '//<![CDATA[
		jQuery(document).ready(function($){
			new jPlayerPlaylist({
				jPlayer: "#jquery_jplayer'.$playerid.'",
				cssSelectorAncestor: "#jp_container'.$playerid.'"
			}, [';

	foreach ($audioitems as $playitem) {
		$filetitle='';
		if(isset($playitem->title)) $filetitle = $playitem->title;
		$playlistJS .= '{mp3:"'.$playitem->url.'", title:"'.$filetitle.'", artist:"", itemurl:""},';
	}

	$playlistJS .=	'], {
				playlistOptions: {
				enableRemoveControls: false,
				enableShuffle: false,
				autoPlay: '.$autostart.'
				},
				swfPath: "'.LIB_URL.'/cmse/audioplayer",
				solution: "html, flash",
				supplied: "m4a, rtmpa, mp3",
				volume: 100
			});

		});
	//]]>';


	scriptFile(LIB_URL.'/cmse/audioplayer/jplayer.playlist.min.js');
	inlineJs($playlistJS);

}else{
	// get a single stream if not a playlist
	inlineJs('
		//<![CDATA[
		jQuery(document).ready(function($){

			var stream = {
				'.$streamtype.': "'.$first_item.'"
			},
			ready = false;

			$("#jquery_jplayer'.$playerid.'").jPlayer({
				ready: function (event) {
					ready = true;
					$(this).jPlayer("setMedia", stream)'.$auto_start.';
				},
				pause: function() {
					$(this).jPlayer("clearMedia");
				},
				error: function(event) {
					if(ready && event.jPlayer.error.type === $.jPlayer.error.URL_NOT_SET) {
						// Setup the media stream again and play it.
						$(this).jPlayer("setMedia", stream).jPlayer("play");
					}
				},
				swfPath: "'.LIB_URL.'/cmse/audioplayer",
				supplied: "m4a, rtmpa, mp3",
				solution: "html, flash",
				preload: "none",
				wmode: "window",
				volume: 100,
				cssSelectorAncestor: "#jp_container'.$playerid.'"
			});

		});
		//]]>
	');
}//end playlist condition

$playerclass = '';
if( $playerposition == 'fixed' )
	$playerclass = ' class="footplayer"';
?>
	
<div<?php echo $playerclass; ?>>
	<div id="jquery_jplayer<?php echo $playerid; ?>" class="jp-jplayer"></div>
	<div id="jp_container<?php echo $playerid; ?>" class="jp-audio-stream">

			<div class="jp-gui jp-interface">
				<div class="jp-controls">
					<div class="td">
						<a href="javascript:;" class="jp-play" tabindex="1"><i class="fa fa-play-circle"></i></a>
						<a href="javascript:;" class="jp-pause" tabindex="1"><i class="fa fa-pause"></i></a>
					</div>

					<?php if( $item_count > 1 && $playerposition != 'fixed' ) { ?>
					<div class="td jp-progress">
						<div class="progress-bg">
							<span>
							<div class="jp-seek-bar"><div class="jp-play-bar"></div></div>
							</span>
						</div>
						<!-- div class="jp-current-time"></div>
                        <div class="jp-duration"></div -->
					</div>

					<div class="td vol">
						<div class="jp-volume-bar"><div title="set volume" class="jp-volume-bar-value"></div></div>
					</div>
					<?php } ?>

					<div class="td mut">
						<div class="mute">
						<a href="javascript:;" class="jp-mute" tabindex="1" title="mute"><i class="fa fa-volume-up"></i></a>
						<a href="javascript:;" class="jp-unmute" tabindex="1" title="unmute"><i class="fa fa-volume-off"></i></a>
						</div>
					</div>
					
					<?php if( $playerposition == 'fixed' ) { ?>
					<div class="td player-title">
						<h5><span></span></h5>
					</div>

					<a class="slideswitch" href="javascript:;"><i class="fa fa-list" aria-hidden="true"></i> Playlist</a>
					<?php } ?>
				</div>
			</div>

				<?php if( $item_count > 1 ) { ?>
				<div class="jp-playlist">
				<div class="slidepanel">
					<ul id="holder">
						<li></li>
					</ul>
				</div>
				</div>
				<?php } ?>
				
	</div>
</div>


<?php }