<?php
/*
* Copyright (c) 2019 CMSEnergizer.com. All Rights Reserved
* License: GNU General Public License version 2 or later; see http://www.gnu.org/licenses/
* Author: Alex
*/

if( !defined("WHMCS") ) die("This file cannot be accessed directly");


$data = tplVars('productinfo');
$pricing = tplVars('pricing');
$billcycle = tplVars('billingcycle');
$server = tplVars('server');
$configoptions = tplVars('configurableoptions');

$product_text = html_entity_decode($data['description']);

// CMSE product table data
$prodcmse = cmseproducts()->where('prod_id', $data['pid'])->get()[0];


if( $configoptions ) {
	$configs = 'updateConfigurableOptions('.tplVars('i').'), this.value);'; 
}else{
	$configs = 'recalctotals();';
}

//debug($data['pid']);

$image ='';
if( !empty($prodcmse->prod_image) )
	$image = '<img src="'.IMAGES.$prodcmse->prod_image.'" />';

$title = '<h3 class="product-title">'.$data['name'].'</h3>';

$description = '
<div class="product-info">
'.cmseElements($product_text).'
</div>
';

$alert = '
<div class="alert alert-danger hidden" role="alert" id="containerProductValidationErrors">
	<p>'.text('orderForm.correctErrors').':</p>
	<ul id="containerProductValidationErrorsList"></ul>
</div>
';


//debug($pricing);

// recurring pricing
$priceRecur='';
if( $pricing['type'] === 'recurring' ) 
{
	$priceRecur = '
	<div class="field-container">
		<div class="form-group">
			<h5>'.text('cartchoosecycle').'</h5>
			<select name="billingcycle" id="inputBillingcycle" class="form-control select-inline" onchange="'.$configs.'">';
			foreach($pricing['cycles'] as $period => $price) {
				$selected = ($period == $billcycle ? 'selected' : '');
				$priceRecur .= '<option value="'.$period.'" '.$selected.'>'.$price.'</option>';
			}
			$priceRecur .= '</select>
		</div>
	</div>
	';
}


// server type
if( $data['type'] === 'server' ) 
{
	$serverhtml = '
	<div class="sub-heading">
		<span>'.text('cartconfigserver').'</span>
	</div>

	<div class="field-container">

		<div class="row">
			<div class="col-sm-6">
				<div class="form-group">
					<label for="inputHostname">'.text('serverhostname').'</label>
					<input type="text" name="hostname" class="form-control" id="inputHostname" value="'.$server['hostname'].'" placeholder="servername.yourdomain.com" />
				</div>
			</div>
			<div class="col-sm-6">
				<div class="form-group">
					<label for="inputRootpw">'.text('serverrootpw').'</label>
					<input type="password" name="rootpw" class="form-control" id="inputRootpw" value="'.$server['rootpw'].'" />
				</div>
			</div>
		</div>

		<div class="row">
			<div class="col-sm-6">
				<div class="form-group">
					<label for="inputNs1prefix">'.text('serverns1prefix').'</label>
					<input type="text" name="ns1prefix" class="form-control" id="inputNs1prefix" value="'.$server['ns1prefix'].'" placeholder="ns1" />
				</div>
			</div>
			<div class="col-sm-6">
				<div class="form-group">
					<label for="inputNs2prefix">'.text('serverns2prefix').'</label>
					<input type="text" name="ns2prefix" class="form-control" id="inputNs2prefix" value="'.$server['ns2prefix'].'" placeholder="ns2" />
				</div>
			</div>
		</div>

	</div>
	';
}


// config options
if( $configoptions )
{
	$confightml = '
	<div class="sub-heading">
		<h5><span>'.text('orderconfigpackage').'</span></h5>
	</div>

	<div class="product-configurable-options" id="productConfigurableOptions">
		<div class="row">';
		foreach($configoptions as $num => $configoption)
		{
			$opt = $configoption['optiontype'];
			$optname = $configoption['optionname'];
			
			if( $opt == 1 )
			{
				$confightml .= '
				<div class="col-sm-6">
					<div class="form-group">
						<label for="inputConfigOption'.$configoption['id'].'">'.$optname.'</label>
						<select name="configoption['.$configoption['id'].']" id="inputConfigOption'.$configoption['id'].'" class="form-control">';
						foreach($configoption['options'] as $option) {
							$selected = ($configoption['selectedvalue'] == $option['id'] ?  'selected="selected"' : '');
							$confightml .= '<option value="'.$option['id'].'" '.$selected.'>'.$option['name'].'</option>';
						}
						$confightml .= '</select>
					</div>
				</div>';
			}
			
			else
				
			if( $opt == 2 )
			{
				$confightml .= '
				<div class="col-sm-6">
					<div class="form-group">
						<label for="inputConfigOption'.$configoption['id'].'">'.$optname.'</label>';
						foreach($configoption['options'] as $option) {
							$checked = ($configoption['selectedvalue'] == $option['id'] ? 'checked="checked"' : '');
						$confightml .= '
						<label>
						<input type="radio" name="configoption['.$configoption['id'].']" value="'.$option['id'].'" '.$checked.' />
						'.($option['name'] ? $option['name'] : text('enable')).'
						</label>';
						}
					$confightml .= '</div>
				</div>';
			}
			else
				
			if( $opt == 3 )
			{
				$checked = ($configoption['selectedqty'] ? 'checked' : '');
				$confightml .= '
				<div class="col-sm-6">
					<div class="form-group">
						<label for="inputConfigOption'.$configoption['id'].'">'.$optname.'</label>
						
						<label>
						<input type="checkbox" name="configoption['.$configoption['id'].']" id="inputConfigOption'.$configoption['id'].'" value="1" '.$checked.' />
						'.($configoption['options'][0]['name'] ? $configoption['options'][0]['name'] : text('enable')).'
						</label>
					</div>
				</div>
				';
			}
			else
				
			if( $opt == 4 )
			{
				$confightml .= '
				<div class="col-sm-12">
					<div class="form-group">
						<label for="inputConfigOption'.$configoption['id'].'">'.$optname.'</label>';
						if( $configoption['qtymaximum'] ) 
						{
							if( !$rangesliderincluded ) {
								$confightml .= '
								<script type="text/javascript" src="'.tplVars('BASE_PATH_JS').'/ion.rangeSlider.min.js"></script>
								<link href="'.tplVars('BASE_PATH_CSS').'/ion.rangeSlider.css" rel="stylesheet" />
								<link href="'.tplVars('$BASE_PATH_CSS').'/ion.rangeSlider.skinModern.css" rel="stylesheet" />
								'.getSmarty()->assign('rangesliderincluded', true);
							}
							$confightml .= '<input type="text" name="configoption['.$configoption['id'].']" value="'.($configoption['selectedqty'] ? $configoption['selectedqty'] : $configoption['qtyminimum']).'" id="inputConfigOption'.$configoption['id'].'" class="form-control" />';
						
							$confightml .= '
							<script>
								var sliderTimeoutId = null;
								var sliderRangeDifference = '.$configoption['qtymaximum'].' - '.$configoption['qtyminimum'].';
								// The largest size that looks nice on most screens.
								var sliderStepThreshold = 25;
								// Check if there are too many to display individually.
								var setLargerMarkers = sliderRangeDifference > sliderStepThreshold;

								jQuery("#inputConfigOption'.$configoption['id'].'").ionRangeSlider({
									min: '.$configoption['qtyminimum'].',
									max: '.$configoption['qtymaximum'].',
									grid: true,
									grid_snap: setLargerMarkers ? false : true,
									onChange: function() {
										if (sliderTimeoutId) {
											clearTimeout(sliderTimeoutId);
										}

										sliderTimeoutId = setTimeout(function() {
											sliderTimeoutId = null;
											recalctotals();
										}, 250);
									}
								});
							</script>
							';
						}
						else{
							$confightml .= '
							<div>
								<input type="number" name="configoption['.$configoption['id'].']" value="'.($configoption['selectedqty'] ? $configoption['selectedqty'] : $configoption['qtyminimum']).'" id="inputConfigOption'.$configoption['id'].'" min="'.$configoption['qtyminimum'].'" onchange="recalctotals()" onkeyup="recalctotals()" class="form-control form-control-qty" />
								<span class="form-control-static form-control-static-inline">
								x '.$configoption['options'][0]['name'].'
								</span>
							</div>
							';
						}
			
					$confightml .= '</div>
				</div>';
			}
			
			if( $num % 2 != 0 ) {
			$confightml .= '</div>
			<div class="row">';
			}
		} // end foreach
		$confightml .= '</div>
	</div>
	';
}


// custom fields
if( tplVars('customfields') )
{
	$cfield = '
	<div class="sub-heading customfields">
	<span>'.text('orderadditionalrequiredinfo').'</span>
	</div>

	<div class="field-container">';
		foreach(tplVars('customfields') as $customfield) {
		$cfield .= '
		<div class="form-group">
			<label for="customfield'.$customfield['id'].'">'.$customfield['name'].'</label>
			'.$customfield['input'].
			($customfield['description'] ? '<span class="field-help-text">
			'.$customfield['description'].'
			</span>':'').'
		</div>
		';
		}
	$cfield .= '</div>';
}


// addons
if( tplVars('addons') || count(tplVars('addonsPromoOutput')) > 0 )
{
	$addons = '
	<div class="sub-heading">
		<span>'.text('cartavailableaddons').'</span>
	</div>';

	foreach(tplVars('addonsPromoOutput') as $output) {
		$addons .= '<div>'.$output.'</div>';
	}
	$addons .= '
	<div class="row addon-products">';
		foreach(tplVars('addons') as $addon) 
		{
			$addon .= '
			<div class="col-sm-'.(count($addons) > 1 ? 6:12).'">
				<div class="panel panel-default panel-addon'.($addon['status'] ? ' panel-addon-selected' :'').'">
					<div class="panel-body">
						<label>
						<input type="checkbox" name="addons['.$addon['id'].']"'.($addon['status'] ? ' checked':'').' />
						'.$addon['name'].'
						</label><br />
						'.$addon['description'].'
					</div>
					<div class="panel-price">
						'.$addon['pricing'].'
					</div>
					<div class="panel-add">
					<i class="fas fa-plus"></i>'.text('addtocart').'
					</div>
				</div>
			</div>';
		}
	$addons .= '</div>';

}


$end = '
<div class="alert alert-warning info-text-sm">
<i class="fas fa-question-circle"></i>
'.text('orderForm.haveQuestionsContact').' <a href="contact.php" target="_blank" class="alert-link">'.text('orderForm.haveQuestionsClickHere').'</a>
</div>
';


// sidebar order summary
$ordersummary = '
<div class="order-summary">
	<div class="loader" id="orderSummaryLoader">
		<i class="fas fa-fw fa-sync fa-spin"></i>
	</div>
	<h2>'.text('ordersummary').'</h2>
	<div class="summary-container" id="producttotal"></div>
</div>
<div class="text-center">
	<button type="submit" id="btnCompleteProductConfig" class="btn btn-primary btn-lg">
	'.text('continue').'
	<i class="fas fa-arrow-circle-right"></i>
	</button>
</div>
';


// Layout Source
$cartlayout = cmseElements(html_entity_decode(modConfigs()->cart_layout));



/* Output
-----------------*/

$sc = [
'[text]',
'[title]',
'[image]',
'[billcycle]',
'[config]',
'[fields]',
'[addon]',
'[contact]',
'[alert]',
'[ordersummary]',
'[summarywrap]',
'[/summarywrap]'
];

$rpl = [
$description,
$title,
$image,
$priceRecur,
$confightml,
$cfield,
$addons,
$end,
$alert,
$ordersummary,
'<div class="col-md-4" id="scrollingPanelContainer">
<div id="orderSummary">',
'</div></div>'
];

$productData = str_replace($sc, $rpl, $cartlayout);