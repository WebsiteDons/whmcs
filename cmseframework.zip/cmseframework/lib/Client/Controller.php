<?php
/*
* Copyright (c) 2019 Emuzement Net Inc. All Rights Reserved
* License: EULA
* Author: Alex/Kumar/Manti/Lisa
*/


namespace WHMCS\Module\Addon\Cmseframework\Client;

if( !defined("WHMCS") ) die("This file cannot be accessed directly");


// load functions
$modname = basename(dirname(dirname(__DIR__)));
if( !function_exists('posts') )
	include_once dirname(__DIR__, 5).'/modules/addons/'.$modname.'/functions.php';

class Controller
{
	public function index($vars)
	{
		$modlink	= $vars['modulelink'];
		$LANG		= $vars['_lang'];
		TIMEZONE;

		// get social share buttons
		ob_start();
		include LIB_PATH.'/cmse/socialshare/socialshare.php';
		$socialshare = ob_get_clean();


		/* All Categories List View
		----------------------------------------*/
		if( getRequest('view') == 'categories' )
		{
			// show all categories
			$categories = true;

			$cats = categories()->orderBy('id', 'desc')->get();

			$catwidth= $catclass= $cateqheight= $cateqimg='';
			if( modConfigs()->catcolumns > 1 ) {
				$catwidth = ' style="width: '.round(100/modConfigs()->catcolumns).'%;"';
				$catclass = ' boxsize break grid';
				$cateqheight = ' equalheight';

				if( modConfigs()->catimgmask =='' )
					$cateqimg = ' data-mh="cateqimg"';

			}

			$catimgmask='';
			if( modConfigs()->catimgmask !='' ) {
				$catimgmask = ' style="height: '.modConfigs()->catimgmask.'px;"';
			}

			$catlist=[];
			foreach($cats as $cat)
			{
				$catimage = IMAGES.json_decode($cat->configs)->catimage;
				if( json_decode($cat->configs)->catimage == '' )
					$catimage = IMAGES.'default.jpg';

				$allcatlayout = cmseElements(modConfigs()->allcat_layout);
				$menuitem = menus()->select('id', 'url')->where('type', 2)->get()[0];
				$catlink = $modlink.'&category='.$cat->id.'-'.$cat->alias.'&menuid='.$menuitem->id;

				$allcattitle = '
					<h3 class="title">
						<span><a href="'.$catlink.'">'.$cat->title.'</a></span>
					</h3>
				';

				$allcatimage = '
				<div class="allcat-image"'.$cateqimg.'>
					<span class="catimgmask"'.$catimgmask.'>
					<a href="'.$catlink.'">
					<img src="'.$catimage.'" /></a>
					</span>
				</div>
				';

				$txt = html_entity_decode($cat->description);
				if( modConfigs()->cattextlimit != '' )
					$txt = truncText(html_entity_decode($cat->description), (int)modConfigs()->cattextlimit);
				$allcattext = '<div class="text">'.$txt.'</div>';

				$allcatcogs = ['[title]', '[image]', '[text]'];
				$allcatcogsrpl = [$allcattitle, $allcatimage, $allcattext];
				$allcatlayout = str_replace($allcatcogs, $allcatcogsrpl, $allcatlayout);

				if( !is_null(json_decode($cat->configs)->showinlist) ){}else{
					$catlist[] = '
						<div class="cat-item'.$catclass.'"'.$catwidth.'>
							<div class="inner'.$cateqheight.'">
							'.$allcatlayout.'
							</div>
						</div>
					';
				}
			}
		}

		else


		/* Single Category View
		--------------------------------------*/
		if( requestKey('category') )
		{
			// get specific category
			$category = true;
			preg_match('#\d+#s', getRequest('category'), $cid);

			$cat = categories()->where('id', (int)$cid[0])->get()[0];

			$catconf = json_decode($cat->configs);
			$catlayout = cmseElements($catconf->cat_layout);

			$cattitle = '<h2 class="title"><span>'.$cat->title.'</span></h2>';
			$catimage = '<div class="catimage"><img src="'.IMAGES.$catconf->catimage.'" /></div>';
			$cattext = '<div class="description">'.html_entity_decode($cat->description).'</div>';

			// output
			$catcogs = ['[image]', '[title]', '[text]'];
			$catcogsrpl = [$catimage, $cattitle, $cattext];
			$catlayout = str_replace($catcogs, $catcogsrpl, $catlayout);


			// post items in category view
			$itemclass = $itemwidth= $equalheight= $eqtitle= $eqimg='';
			if( $catconf->itemscolumns > 1 ) {
				$itemclass = ' boxsize break grid';
				$equalheight = ' equalheight';
				$itemwidth = ' style="width: '.round(100/(int)$catconf->itemscolumns).'%;"';
				$eqtitle = ' data-mh="eqtitle"';
				if( $catconf->imgmask =='' )
					$eqimg = ' data-mh="eqimg"';

			}

			$imgmask='';
			if( $catconf->imgmask !='' ) {
				$imgmask = ' style="height: '.$catconf->imgmask.'px;"';
			}

			$allposts = posts()->where('catid', (int)$cid[0])->orderBy('id', 'desc')->get();
			$posts = $allposts;

			// set pagination
			$pagination ='';
			if( $catconf->itemcount != '')
			{
				$limit = (int)$catconf->itemcount;

				$p = (int)getRequest('listpage');
				$offset = (($p - 1) * $limit);

				$pagination = pagingLinks(count($allposts), $limit);
				$posts = posts()->where('catid', (int)$cid[0])->orderBy('id', 'desc')->offset($offset)->limit($limit)->get();
			}


			$cat_item = [];
			foreach($posts as $post)
			{
				$itemslayout = cmseElements($catconf->cat_items_layout);
				$itemlink = $modlink.'&page='.$post->id.'-'.$post->alias.'&menuid='.getRequest('menuid');

				$title = '
					<h3 class="title"'.$eqtitle.'>
						<span><a href="'.$itemlink.'">'.$post->title.'</a></span>
					</h3>
					';

				$image = '
					<div class="post-image"'.$eqimg.'>
						<span class="imgmask"'.$imgmask.'>
						<a href="'.$itemlink.'">
						<img src="'.IMAGES.$post->post_image.'" alt="'.$post->title.'" />
						</a>
						</span>
					</div>
				';

				$itemtext = html_entity_decode($post->post_content);
				if( !is_null($catconf->textlimit) )
					$itemtext = truncText(html_entity_decode($post->post_content), (int)$catconf->textlimit);

				$text = '
				<div class="post-text">'.$itemtext.'</div>
				';

				$date = '';
				$hits= $comments= $votes= $author= $media='';

				// output
				$postcogs = [
				'[title]',
				'[image]',
				'[text]',
				'[date]',
				'[hits]',
				'[comments]',
				'[votes]',
				'[author]',
				'[media]',
				];
				$postcogsrpl = [
				$title,
				$image,
				$text,
				$date,
				$hits,
				$comments,
				$votes,
				$author,
				$media,
				];

				$itemslayout = str_replace($postcogs, $postcogsrpl, $itemslayout);

				$cat_item[] = '
				<div class="post-item'.$itemclass.'"'.$itemwidth.'>
					<div class="inner'.$equalheight.'">
						'.$itemslayout.'
					</div>
				</div>
				';
			}
		}


		/* Item View
		---------------------------------*/
		if( requestKey('page') )
		{
			$pageview = true;
			$alias = preg_replace('#(\d+[-])#', '', $_REQUEST['page'], 1); // strip id from URL ..not used yet
			preg_match('#\d+#s', getRequest('page'), $id); // get item id from URL

			// get post data
			$item = posts()->where('id', (int)$id[0])->get()[0];

			// get category data
			$catdata = categories()->where('id', $item->catid)->get()[0];
			$catconfig = json_decode($catdata->configs);
			$itemattribs = json_decode($item->attribs);


			/*get layout shortcodes
			------------------------------*/

			// single post layout
			if( isset($itemattribs->singlepost_layout) && $itemattribs->singlepost_layout != '' ) {
				$itemlayout = cmseElements($itemattribs->singlepost_layout);
			}else
			// category layout
			if( isset($catconfig->item_layout) && $catconfig->item_layout != '' ) {
				$itemlayout = cmseElements($catconfig->item_layout);
			}else
			// use global config layout if set
			if( isset(modConfigs()->layout) && modConfigs()->layout != '' ) {
				$itemlayout = cmseElements(modConfigs()->layout);
			}

			$text = cmseElements(html_entity_decode($item->post_content));
			$title = $item->title;

			$image='';
			if( !empty($item->post_image) && !isset($itemattribs->imgoff->off) ) {
				$image .= '<div><img src="'.IMAGES.$item->post_image.'" alt="'.$title.'" /></div>';

				if( isset($imgcaption) )
					$image .= '<p>caption</p>';
			}

			$category = '
				<h5 class="meta category-title">
					<span><a href="'.$modlink.'&category='.$catdata->id.'-'.$catdata->alias.'">'.$catdata->title.'</a></span>
				</h5>
			';

			// Video Player
			$videoplayer='';
			if( isset($itemattribs->video) && $itemattribs->video != '' ) {
				$videoplayer = cmseVideoPlayer($itemattribs->video);
			}

			//date output. accepts plain text eg [date Published On:] or just [date]
			if( preg_match('#\[date(.*?)\]#si', $itemlayout, $datecog) ) {
				$postdate = '<span class="meta post-date">'.$datecog[1].' '.dateFormat($item->created_at).'</span>';

				$itemlayout = str_replace($datecog[0], $postdate, $itemlayout);
			}


			//--------------------[ Comment Options ]
			// facebook comment

			$facebookcomment = '
			<div class="fbcommentwrap">
				<a id="commentbox"></a>
				<div class="fb-comments"
					data-href="'.currenturl().'"
					data-width="100%"
					data-numposts="50"
					data-colorscheme="light"
					data-order-by="social">
				</div>
				</div>';

			// facebook comment count and link to comments field on the page
			//$fbcommentcount = '<span class="itemmeta commentcount"><div class="tbl"><a href="#commentbox"><div class="fb-comments-count" data-href="'.$currenturl.'">0</div><div class="text">'.JText::_('CMSE_COMMENT_COUNT').'</div></a></div></span>';

			// Disqus comment
			$disqus = '<div id="disqus_thread"></div>
			<script>
				var disqus_config = function () {
					this.page.url = "'.currenturl().'";
					this.page.identifier = "'.getRequest('page').'";
				};

				(function() {
					var d = document, s = d.createElement("script");

					s.src = "https://user.disqus.com/embed.js";

					s.setAttribute("data-timestamp", +new Date());
					(d.head || d.body).appendChild(s);
				})();
			</script>';


			// output replacements
			$placeholders = [
			'[title]',
			'[image]',
			'[text]',
			'[socialshare]',
			'[category]',
			'[videoplayer]',
			'[facebookcomment]',
			'[disqus]'
			];
			$replacements = [
			'<h2><span>'.$title.'</span></h2>',
			'<div class="post-image">'.$image.'</div>',
			'<div class="post-text">'.$text.'</div>',
			$socialshare,
			$category,
			$videoplayer,
			$facebookcomment,
			$disqus
			];

			$itemlayout = str_replace($placeholders, $replacements, $itemlayout);

		}


		// set cmseframework template
		if( modConfigs()->whmcstemplate == 1 && file_exists(SITETPL_PATH.'/template.xml') && file_exists(TMPLS_DIR.'/'.getSetting('Template')) ) {
			$template = getSetting('Template');
		}else{
			$template = modConfigs()->content_template;
		}




		/* Variable Output To Template As Smarty Variables
		---------------------------------------------------------*/
		$output = [
			'templatefile' => $template.'/index',
			'vars' => [
				'pageview'		=> $pageview,
				'categories'	=> $categories,
				'category'		=> $category,
				'productdetails'=> $productdetails,
				// layouts
				'catlayout'		=> $catlayout,
				'catitem'		=> implode('', $cat_item),
				'pagination'	=> $pagination,
				'catlist'		=> implode('', $catlist),
				'itemlayout'	=> $itemlayout,
				// widgets
				//'position'		=> $positions,
				// template path
				'tmpl_root'		=> dirname(__DIR__, 2).'/templates/'.$vars['template'],
				'TMPL_URL'		=> MODURL.'/templates/'.modConfigs()->content_template,
				'widgetroot'	=> dirname(__DIR__, 2).'/widgets'

			]
		];

		return $output;
	}

}
