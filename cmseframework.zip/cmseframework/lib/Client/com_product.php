<?php
/*
* Copyright (c) 2019 CMSEnergizer.com. All Rights Reserved
* License: GNU General Public License version 2 or later; see http://www.gnu.org/licenses/
* Author: Alex
*/

if( !defined("WHMCS") ) die("This file cannot be accessed directly");

// text values
$ordericon = defined('ORDER_ICON') ? '<i class="fas '.ORDER_ICON.'"></i> ' : '';


/* All Product Groups View
------------------------------------------------*/
if( $view == 'productgroups' )
{
	$productgroups = groups()->where('hidden', 0)->orderBy('order', 'asc')->get();

	$groups = [];
	foreach($productgroups as $productgroup)
	{
		$rawurl		= 'index.php?component=products&view=productgroup&gid='.$productgroup->id.'-'.cleanChars($productgroup->name);
		$link		= '<a href="'.ROOT_URL.router($rawurl).'">';
		$linkend	= '</a>';
		$groupname	= '<h3 class="title"><span>'.$link.$productgroup->name.$linkend.'</span></h3>';
		$headline	= '<p class="headline">'.$productgroup->headline.'</p>';
		$tagline	= '<div>'.truncText(html_entity_decode($productgroup->tagline), 120).'</div>';

		$groups[] = '
		<div class="item">
			<div class="inner">
				<div class="equalheight marginbottom-20">
				'.$groupname.$headline.$tagline.'
				</div>
				<a href="'.ROOT_URL.router($rawurl).'" class="btn btn-success">'.VIEW_GROUP.'</a>
			</div>
		</div>
		';
	}

	$product_groups = '<h1 class="pagetitle category-title"><span>'.menus()->where('id', (int)$menuid)->value('title').'</span></h2>';
	if( empty($productgroups) ) {
		$product_groups .= '<p class="alert alert-info">'.NO_PRODUCTS.'</p>';
	}else{
		$product_groups .= implode('', $groups);
	}
}




/* Product Group View
------------------------------------------------*/
if( $view == 'productgroup' || tplVars('templatefile') == 'products' )
{
	$groupid		= (tplVars('templatefile') == 'products' ? getRequest('gid') : (int)$groupid);
	$groupvalues	= groups()->where([['id', $groupid], ['hidden', 0]])->get()[0];
	$groupcmse		= cmseproducts()->where([['type', 'group'], ['group_id', $groupid]])->get()[0];

	$groupname		= $groupvalues->name;
	$configs		= json_decode($groupcmse->group_configs);

	if( !empty($configs->groupview) ) {
		$groupdetails_layout = html_entity_decode($configs->group_detailslayout);
		$itemsperrow = $configs->itemsperrow;
		$img_mask = $configs->imgmask;
		$textlimit = $configs->textlimit;
	}else
	if( !empty(modConfigs()->group_layout) ) {
		$groupdetails_layout = html_entity_decode(modConfigs()->group_detailslayout);
		$itemsperrow = modConfigs()->prodcolumns;
		$img_mask = modConfigs()->prodimgmask;
		$textlimit = modConfigs()->prodtextlimit;
	}else{
		$groupdetails_layout = '[title][headline][text][products]';
		$itemsperrow = 4;
		$img_mask = 160;
		$textlimit = 150;
	}


	// Product items
	$products = products()->where([['gid', $groupid], ['hidden', 0], ['retired', 0]])->orderBy('order')->get();

	$itemclass = $itemwidth= $equalheight= $eqtitle= $eqimg='';
	if( $itemsperrow > 1 )
	{
		$itemclass = ' boxsize break grid';
		$equalheight = ' equalheight';
		$itemwidth = ' style="width: '.round(100/(int)$itemsperrow).'%;"';
		$eqtitle = ' data-mh="eqtitle"';
		if( $img_mask =='' )
			$eqimg = ' data-mh="eqimg"';
	}

	$imgmask='';
	if( $img_mask !='' ) {
		$imgmask = ' style="height: '.$img_mask.'px;"';
	}

	$items = [];
	foreach($products as $item)
	{
		if( $configs->groupview != '' ) {
			$itemlayout = cmseElements(html_entity_decode($configs->groupview));
		}else
		// global configuration
		if( isset(modConfigs()->group_layout) && modConfigs()->group_layout != '' ) {
			$itemlayout = cmseElements(html_entity_decode(modConfigs()->group_layout));
		}else{
		// default
			$itemlayout = '[title][text][price][addcart]';
		}

		$prodcmse = cmseproducts()->where([['type', 'product'], ['prod_id', $item->id]])->get()[0];

		// set product detail link
		$rawurl = 'index.php?component=products&view=productdetail&gid='.$item->gid.'-'.cleanChars($groupname).'&pid='.$item->id.'-'.$prodcmse->prod_alias;

		$link = '<a href="'.router($rawurl).'" title="View Details">';
		$linkend = '</a>';

		$title = '<h2 class="post-title"><span>'.$link.$item->name.$linkend.'</span></h2>';

		$item_text = html_entity_decode($item->description);
		$text = (!empty($textlimit) ? truncText($item_text, $textlimit) : $item_text);
		$text = '<div class="post-text">'.$text.'</div>';

		// get image if exist
		$image = '';
		if( !empty($prodcmse->prod_image) ) {
		$image = '
			<div class="post-image"'.$eqimg.'>
				<span class="imgmask"'.$imgmask.'>
				'.$link.'
				<img src="'.IMAGES.$prodcmse->prod_image.'" alt="'.$item->name.'" title="'.$item->name.'" />
				'.$linkend.'
				</span>
			</div>
		';
		}


		// prices
		$currprefix = tplVars('currency')['prefix'];
		$currsuffix = tplVars('currency')['suffix'];
		$prices = '<div class="item-price">'.itemPrice($item->id, $item->paytype).'</div>';
		$priceall = '<div class="item-price">'.itemPrice($item->id, $item->paytype, true).'</div>';
		$pricetotal = '<div class="item-price">'.itemPrice($item->id, $item->paytype, true, true).'</div>';

		$addcart = '
		<a class="btn btn-sm btn-success" href="'.cmseUri().'cart.php?a=add&pid='.$item->id.'" title="'.ORDER_NOW.' '.$item->name.'">
		'.$ordericon.ORDER_NOW.'
		</a>
		<a class="btn btn-sm btn-info" href="'.router($rawurl).'" title="'.VIEW_DETAILS.'">'.VIEW_DETAILS.'</a>
		';

		$objholder = [
		'[title]',
		'[text]',
		'[image]',
		'[price]',
		'[priceall]',
		'[pricetotal]',
		'[addcart]'
		];

		$object = [
		$title,
		cmseElements($text),
		$image,
		$prices,
		$priceall,
		$pricetotal,
		$addcart
		];

		$itemlayout = str_replace($objholder, $object, $itemlayout);

		$items[] = '
		<div class="post-item'.$itemclass.'"'.$itemwidth.'>
			<div class="inner'.$equalheight.'">
			'.$itemlayout.'
			</div>
		</div>
		';
	}



	// group page detail
	$grouptitle = (!empty($groupname) ? '<h1 class="pagetitle category-title"><span>'.$groupname.'</span></h1>' : '');
	$groupheadline = (!is_null($groupvalues->headline) ? '<h2 class="sub-pagetitle"><span>'.$groupvalues->headline.'</span></h2>' : '');
	$grouptext = (!is_null($groupvalues->tagline) ? cmseElements(html_entity_decode($groupvalues->tagline)) : '');

	$grpsc = ['[title]', '[text]', '[headline]', '[products]'];
	$grprpl = [$grouptitle, $grouptext, $groupheadline, implode('',$items)];
	$groupdetails = '<div class="group-details">'.str_replace($grpsc, $grprpl, cmseElements($groupdetails_layout)).'</div>';

	$productgroup = $groupdetails;
}




/* Product Detail View
------------------------------------------------*/
if( $view == 'productdetail' )
{
	// get data from product table
	$item = products()
		->where('id', $prodid)
		->select('id','gid','name','description','paytype','is_featured','created_at')
		->get()[0];

	// get group custom configs
	$prodcmse = cmseproducts()->where('prod_id', $prodid)->get()[0];
	$attribs = json_decode($prodcmse->attribs);
	$configval = json_decode($prodcmse->group_configs);


	// get layout data
	if( !empty($configval->detailview) ) {
		$itemlayout = cmseElements(html_entity_decode($configval->detailview));
	}else
	if( isset(modConfigs()->product_layout) && modConfigs()->product_layout != '' ) {
		$itemlayout = cmseElements(html_entity_decode(modConfigs()->product_layout));
	}else{
		$itemlayout = '[title][price][addcart][image][text]';
	}

	$itemtitle = '<h1 class="pagetitle post-title"><span>'.$item->name.'</span></h1>';
	$item_text = html_entity_decode($item->description);

	$itemimage = '<div class="post-image"><img src="'.IMAGES.$prodcmse->prod_image.'" /></div>';


	$price = '
	<div class="item-price">
	'.itemPrice($item->id, $item->paytype).'
	</div>
	';

	$pricetotal = '
	<div class="item-price">
	'.itemPrice($item->id, $item->paytype, '', true).'
	</div>
	';

	$priceall = '
	<div class="item-price">
	'.itemPrice($item->id, $item->paytype, true).'
	</div>
	';

	$pricealltotal = '
	<div class="item-price">
	'.itemPrice($item->id, $item->paytype, true, true).'
	</div>
	';

	$addcart = '
	<a class="btn btn-sm btn-success" href="'.cmseUri().'cart.php?a=add&pid='.$item->id.'">
	'.$ordericon.ORDER_NOW.'
	</a>';

	$rawurl = 'index.php?component=products&view=productgroup&gid='.$item->gid.'-'.$prodcmse->group_alias;
	$group = '<a href="'.ROOt_URL.router($rawurl).'">'.groups()->where('id', $item->gid)->value('name').'</a>';

	// shortcode placement override when placed in the content text body
	// "or" = override when the shortcode is written in the article body
	if( strstr($item_text, '[priceall]') ) {
		$orpriceall = $priceall;
	}else{
		$price_all = $priceall;
	}

	if( strstr($item_text, '[pricealltotal]') ) {
		$orpricealltotal = $pricealltotal;
	}else{
		$price_alltotal = $pricealltotal;
	}

	if( strstr($item_text, '[price]') ) {
		$orprice = $price;
	}else{
		$price = $price;
	}
	if( strstr($item_text, '[pricetotal]') ) {
		$orpricetotal = $pricetotal;
	}else{
		$pricetotal = $pricetotal;
	}

	if( strstr($item_text, '[addcart]') ) {
		$oraddcart = $addcart;
	}else{
		$add_cart = $addcart;
	}

	if( strstr($item_text, '[group]') ) {
		$orcategory = $group;
	}else{
		$category = $group;
	}


	//--------------------[ Comment Options ]
	// facebook comment

	$facebookcomment = '
	<div class="fbcommentwrap">
		<a id="commentbox"></a>
		<div class="fb-comments"
			data-href="'.currenturl().'"
			data-width="100%"
			data-numposts="50"
			data-colorscheme="light"
			data-order-by="social">
		</div>
	</div>';

	// facebook comment count and link to comments field on the page
	//$fbcommentcount = '<span class="itemmeta commentcount"><div class="tbl"><a href="#commentbox"><div class="fb-comments-count" data-href="'.$currenturl.'">0</div><div class="text">'.JText::_('CMSE_COMMENT_COUNT').'</div></a></div></span>';

	// Disqus comment
	$disqus = '<div id="disqus_thread"></div>
	<script>
		var disqus_config = function () {
			this.page.url = "'.currenturl().'";
			this.page.identifier = "'.getRequest('page').'";
		};

		(function() {
			var d = document, s = d.createElement("script");

			s.src = "https://user.disqus.com/embed.js";

			s.setAttribute("data-timestamp", +new Date());
			(d.head || d.body).appendChild(s);
		})();
	</script>';


	// get social share buttons
	ob_start();
	include LIB_PATH.'/cmse/socialshare/socialshare.php';
	$socialshare = ob_get_clean();

	// article content override place holders
	$orplaceholder = [
	'[priceall]',
	'[pricealltotal]',
	'[price]',
	'[pricetotal]',
	'[addcart]',
	'[group]'
	];
	$orreplace = [
	$orpriceall,
	$orpricealltotal,
	$orprice,
	$orpricetotal,
	$oraddcart,
	$orcategory
	];

	$item_text = str_replace($orplaceholder, $orreplace, $item_text);

	// Layout shortcode output
	$placeholder = [
		'[title]',
		'[image]',
		'[text]',
		'[priceall]',
		'[pricealltotal]',
		'[price]',
		'[pricetotal]',
		'[addcart]',
		'[group]',
		'[socialshare]',
		'[facebookcomment]'
	];
	$replace = [
		$itemtitle,
		$itemimage,
		'<div class="post-text">'.cmseElements($item_text).'</div>',
		$price_all,
		$price_alltotal,
		$price,
		$pricetotal,
		$add_cart,
		$category,
		$socialshare,
		$facebookcomment
	];

	$productdetail = str_replace($placeholder, $replace, $itemlayout);

}
