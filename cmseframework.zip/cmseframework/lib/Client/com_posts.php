<?php
/*
* Copyright (c) 2019 Emuzement Net Inc. All Rights Reserved
* License: EULA
* Author: Alex/Kumar/Manti/Lisa
*/

if( !defined("WHMCS") ) die("This file cannot be accessed directly");

$modlink = 'index.php?component=posts';
$n = "\n";

/* All Categories List View
----------------------------------------*/

if( $view == 'categories' )
{
	$cats = categories()->where([['type', 'post'],['state', 1]])->orderBy('id', 'desc')->get();

	$catwidth= $catclass= $cat_bodyclass= $cateqheight= $cateqimg='';
	if( modConfigs()->catcolumns > 1 ) {
		$catwidth = ' style="width: '.round(100/modConfigs()->catcolumns).'%;"';
		$cat_bodyclass = ' gridview';
		$catclass = ' boxsize break grid';
		$cateqheight = ' equalheight';

		if( modConfigs()->catimgmask =='' )
			$cateqimg = ' data-mh="cateqimg"';
	}

	$catimgmask='';
	if( modConfigs()->catimgmask !='' ) {
		$catimgmask = ' style="height: '.modConfigs()->catimgmask.'px;"';
	}

	$catlist=[];
	foreach($cats as $cat)
	{
		$catimage = IMAGES.json_decode($cat->configs)->catimage;
		if( json_decode($cat->configs)->catimage == '' )
			$catimage = IMAGES.'default.jpg';

		$allcatlayout = cmseElements(modConfigs()->allcat_layout);
		$menuitem = menus()->select('id', 'alias', 'url')->where('type', 2)->get()[0];
		$rawurl = $modlink.'&view=category&category='.$cat->id.'-'.$cat->alias.'&menuid='.$menuitem->id.'-'.$menuitem->alias;
		$catlink = ROOT_URL.router($rawurl);

		$allcattitle = '
			<h3 class="title">
				<span><a href="'.$catlink.'">'.$cat->title.'</a></span>
			</h3>
		';

		$allcatimage = '
		<div class="allcat-image"'.$cateqimg.'>
			<span class="catimgmask"'.$catimgmask.'>
			<a href="'.$catlink.'">
			<img src="'.$catimage.'" /></a>
			</span>
		</div>
		';

		$txt = html_entity_decode($cat->description);
		if( modConfigs()->cattextlimit != '' )
			$txt = truncText(html_entity_decode($cat->description), (int)modConfigs()->cattextlimit);
		$allcattext = '<div class="text">'.$txt.'</div>';

		$allcatcogs = ['[title]', '[image]', '[text]'];
		$allcatcogsrpl = [$allcattitle, $allcatimage, $allcattext];
		$allcatlayout = str_replace($allcatcogs, $allcatcogsrpl, $allcatlayout);

		if( !is_null(json_decode($cat->configs)->showinlist) ){}else{
			$catlist[] = '
				<div class="cat-item'.$catclass.'"'.$catwidth.'>
					<div class="inner'.$cateqheight.'">
					'.$allcatlayout.'
					</div>
				</div>
			';
		}
	}

	$postcategories = implode('', $catlist);
}




/* Single Category View
--------------------------------------*/
if( $view == 'category' )
{
	$cat = categories()->where('id', (int)$category)->get()[0];
	$catconf = json_decode($cat->configs);

	if( !empty($catconf->cat_layout) ) {
		$catlayout = cmseElements(html_entity_decode($catconf->cat_layout));
		$colcount = $catconf->itemscolumns;
		$img_mask = $catconf->imgmask;
		$textlimit = $catconf->textlimit;
		$itemsperpage = $catconf->itemcount;
	}else
	if( !empty(modConfigs()->catlayout) ) {
		$catlayout = cmseElements(html_entity_decode(modConfigs()->catlayout));
		$colcount = modConfigs()->postcolumns;
		$img_mask = modConfigs()->postimgmask;
		$textlimit = modConfigs()->posttextlimit;
		$itemsperpage = modConfigs()->itemsperpage;
	}else{
		$catlayout = '[image][title]';
		$colcount = 4;
		$img_mask = 160;
		$textlimit = 150;
		$itemsperpage = 12;
	}




	// post items in category view
	$itemclass = $itemwidth= $equalheight= $eqtitle= $eqimg= $cat_bodyclass='';
	if( $colcount > 1 )
	{
		$cat_bodyclass = ' gridview';
		$itemclass = ' boxsize break grid';
		$equalheight = ' equalheight';
		$itemwidth = ' style="width: '.round(100/(int)$colcount).'%;"';
		$eqtitle = ' data-mh="eqtitle"';
		if( $img_mask =='' )
			$eqimg = ' data-mh="eqimg"';
	}

	$imgmask='';
	if( $img_mask !='' ) {
		$imgmask = ' style="height: '.$img_mask.'px;"';
	}

	$posts = posts()->where('catid', (int)$category)->orderBy('id', 'desc')->get();

	// set pagination
	$pagination ='';
	if( $itemsperpage != '')
	{
		$limit = (int)$itemsperpage;

		$p = getRequest('listpage');
		$offset = (($p - 1) * $limit);

		$pagination = pagingLinks(count($posts), $limit, getRequest('listpage'));
		$posts = posts()->where('catid', (int)$category)->orderBy('id', 'desc')->offset($offset)->limit($limit)->get();
	}


	$cat_item = [];
	foreach($posts as $post)
	{
		if( !empty($catconf->cat_items_layout) ) {
			$itemslayout = cmseElements(html_entity_decode($catconf->cat_items_layout));
		}else
		if( modConfigs()->catpostlayout != '' ) {
			$itemslayout = cmseElements(html_entity_decode(modConfigs()->catpostlayout));
		}else{
			// pseudo default
			$itemslayout = '[image][title]';
		}

		$rawurl = $modlink.'&view=post&category='.$post->catid.'-'.$cat->alias.'&post='.$post->id.'-'.$post->alias.'&menuid='.$menuid;

		$itemlink = router($rawurl);

		$title = '
			<h3 class="title"'.$eqtitle.'>
				<span><a href="'.$itemlink.'">'.$post->title.'</a></span>
			</h3>
			';

		$image = '
			<div class="post-image"'.$eqimg.'>
				<span class="imgmask"'.$imgmask.'>
				<a href="'.$itemlink.'">
				<img src="'.IMAGES.$post->post_image.'" alt="'.$post->title.'" />
				</a>
				</span>
			</div>
		';

		$itemtext = html_entity_decode($post->post_content);
		if( !empty($textlimit) )
			$itemtext = truncText(html_entity_decode($post->post_content), (int)$textlimit);

		$text = '
		<div class="post-text">'.$itemtext.'</div>
		';

		$date = '';
		$hits= $comments= $votes= $author= $media='';

		// output
		$postcogs = [
		'[title]',
		'[image]',
		'[text]',
		'[date]',
		'[hits]',
		'[comments]',
		'[votes]',
		'[author]',
		'[media]',
		];
		$postcogsrpl = [
		$title,
		$image,
		$text,
		$date,
		$hits,
		$comments,
		$votes,
		$author,
		$media,
		];

		$itemslayout = str_replace($postcogs, $postcogsrpl, $itemslayout);

		$cat_item[] = '
		<div class="post-item'.$itemclass.'"'.$itemwidth.'>
			<div class="inner'.$equalheight.'">
				'.$itemslayout.'
			</div>
		</div>
		';
	}



	// set output variables
	$cattitle = '<h1 class="pagetitle category-title"><span>'.$cat->title.'</span></h1>';
	$catimage = '<div class="catimage"><img src="'.IMAGES.$catconf->catimage.'" /></div>';
	$cattext = '<div class="description">'.cmseElements(html_entity_decode($cat->description)).'</div>';
	$catitem = implode('', $cat_item);

	// output
	$catcogs = ['[image]', '[title]', '[text]', '[posts]'];
	$catcogsrpl = [$catimage, $cattitle, $cattext, $catitem];
	$catlayout = str_replace($catcogs, $catcogsrpl, $catlayout);

	// Output
	$category_view = $catlayout . $pagination;
}




/* Item View
---------------------------------*/
if( $view == 'post' )
{
	// get post data
	$item = posts()->where('id', (int)$post)->get()[0];

	// get category data
	$catdata		= categories()->where('id', $item->catid)->get()[0];
	$catconfig		= json_decode($catdata->configs);
	$itemattribs	= json_decode($item->attribs);

	// set inline css
	if( !empty($itemattribs->customcss) ) {
		inlineCss('/*post ID'.$item->id.' custom css*/'.$n.$itemattribs->customcss.$n.'/*\end post css*/'.$n);
	}


	/*get layout shortcodes
	------------------------------*/

	// single post layout
	if( isset($itemattribs->singlepost_layout) && $itemattribs->singlepost_layout != '' ) {
		$itemlayout = cmseElements(html_entity_decode($itemattribs->singlepost_layout));
	}else
	// category layout
	if( isset($catconfig->item_layout) && $catconfig->item_layout != '' ) {
		$itemlayout = cmseElements(html_entity_decode($catconfig->item_layout));
	}else
	// use global config layout if set
	if( isset(modConfigs()->layout) && modConfigs()->layout != '' ) {
		$itemlayout = cmseElements(html_entity_decode(modConfigs()->layout));
	}

	$text = cmseElements(html_entity_decode($item->post_content));
	$title = '<h1 class="pagetitle post-title"><span>'.$item->title.'</span></h1>';

	$image= $enlarge= $end='';
	if( !empty($item->post_image) && !$itemattribs->img->off )
	{
		$image = '<div class="post-image">';
		if( $itemattribs->img->enlarge ) {
			$enlarge = '<a href="'.IMAGES.$item->post_image.'" title="View Large Image" data-fancybox>';
			$end = '</a>';
		}
		$image .= '<div>'.$enlarge.'<img src="'.IMAGES.$item->post_image.'" alt="'.$item->title.'" />'.$end.'</div>';

		if( isset($imgcaption) )
			$image .= '<p>caption</p>';
		$image .= '</div>';
	}


	$category = '
		<h5 class="meta category-title">
			<span><a href="'.ROOT_URL.router($modlink.'&view=category&category='.$catdata->id.'-'.$catdata->alias.'&menuid='.$menuid).'">'.$catdata->title.'</a></span>
		</h5>
	';

	// Video Player
	//$videoplayer='';
	if( isset($itemattribs->video) && $itemattribs->video != '' ) {
		$videoplayer = cmseVideoPlayer($itemattribs->video);
	}

	// Audio Player
	$audioplayer='';
	if( isset($itemattribs->audio) && $itemattribs->audio != '' ) {
		$audioplayer = cmseAudioPlayer($itemattribs->audio, 'audiophile', '', 'fixed');
	}

	//date output. accepts plain text eg [date Published On:] or just [date]
	if( preg_match('#\[date(.*?)\]#si', $itemlayout, $datecog) ) {
		$postdate = '<span class="meta post-date">'.$datecog[1].' '.dateFormat($item->created_at).'</span>';

		$itemlayout = str_replace($datecog[0], $postdate, $itemlayout);
	}

	// S L I D E  S H O W
	// function cmseSlideShow($slides, $id, $autostart=1, $height=500, $width=100, $delay=3000, $nav=0, $navwidth=30, $navcount=5, $slidespeed=800)


	$slide_show= $slideshow='';

	if( !empty($itemattribs->slide) )
	{
		$slideatt = $itemattribs->slideattrib;
		foreach($itemattribs->slide as $ss) {
			$slides[] = $ss->html;
		}

		$slideout = '
		<div class="post-inset slide-inset">
		'.cmseSlideShow($slides, $item->id, 1, $slideatt->slideheight).'
		</div>';

		if( strstr($item->post_content, '[slideshow]') ) {
			$slide_show = $slideout;
		}else{
			$slideshow = $slideout;
		}
	}


	//--------------------[ Comment Options ]
	// facebook comment

	$facebookcomment = '
	<div class="fbcommentwrap">
		<a id="commentbox"></a>
		<div class="fb-comments"
			data-href="'.currenturl().'"
			data-width="100%"
			data-numposts="50"
			data-colorscheme="light"
			data-order-by="social">
		</div>
		</div>';

	// facebook comment count and link to comments field on the page
	//$fbcommentcount = '<span class="itemmeta commentcount"><div class="tbl"><a href="#commentbox"><div class="fb-comments-count" data-href="'.currenturl().'">0</div><div class="text">Comment Count</div></a></div></span>';

	// Disqus comment
	$disqus = '<div id="disqus_thread"></div>
	<script>
		var disqus_config = function () {
			this.page.url = "'.currenturl().'";
			this.page.identifier = "'.$post.'";
		};

		(function() {
			var d = document, s = d.createElement("script");

			s.src = "https://user.disqus.com/embed.js";

			s.setAttribute("data-timestamp", +new Date());
			(d.head || d.body).appendChild(s);
		})();
	</script>';


	// Article Editor Overrides
	$orvideoplayer= $video_player='';
	if( strstr($item->post_content, '[videoplayer]') ) {
		$orvideoplayer = '<div class="video-inset">'.$videoplayer.'</div>';
	}else{
		$video_player = $videoplayer;
	}


	/* Output Replacements
	--------------------------------*/
	// article overrides

	$orplaceholders = [
	'[videoplayer]',
	'[slideshow]'
	];
	$orreplace = [
	$orvideoplayer,
	$slide_show
	];

	$text = str_replace($orplaceholders, $orreplace, $text);


	$placeholders = [
	'[title]',
	'[image]',
	'[text]',
	'[socialshare]',
	'[category]',
	'[videoplayer]',
	'[audioplayer]',
	'[slideshow]',
	'[facebookcomment]',
	'[disqus]'
	];
	$replacements = [
	$title,
	$image,
	'<div class="post-text">'.$text.'</div>',
	socialShare(),
	$category,
	$video_player,
	$audioplayer,
	$slideshow,
	$facebookcomment,
	$disqus
	];

	$itemlayout = str_replace($placeholders, $replacements, $itemlayout);


}