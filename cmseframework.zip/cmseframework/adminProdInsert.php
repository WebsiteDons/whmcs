<?php
/*
* Copyright (c) 2019 Emuzement Net Inc. All Rights Reserved
* License: EULA
* Author: Alex/Kumar/Manti/Lisa
*/

if( !defined("WHMCS") ) die("This file cannot be accessed directly");

use \WHMCS\Application;
use \WHMCS\Database\Capsule;
use \WHMCS\Carbon;
use \WHMCS\Config\Setting;
use \WHMCS\Session;
use \WHMCS\User\Client;
use \WHMCS\ClientArea;


$prodids = cmseproducts()->where('type', 'product')->pluck('prod_id');
$gid = products()->where('id', getRequest('id'))->value('gid');
$groupname = groups()->where('id', $gid)->value('name');

if( in_array(getRequest('id'), $prodids) ) 
{
	try {
	cmseproducts()->where('prod_id', getRequest('id'))->update([
	'prod_image'	=> getPost('prod_image'),
	'prod_alias'	=> makeAlias('name'),
	'prod_gid'		=> $gid,
	'attribs'		=> json_encode(
		[
		'metadesc' => strip_tags(getPost('metadesc')),
		'metakeys' => strip_tags(getPost('metakeys')),
		'wide_image' => getPost('wide_image', false),
		'wide_imagecaption' => getPost('wide_imagecaption', false)
		]
		),
	'group_alias'	=> cleanChars($groupname),
	'group_id'		=> $gid,
	]);
	
	} catch(\Exception $e) {
		cmseNotice($e->getMessage());
	}
}else
{

	$fields = [
	'type'			=> 'product',
	'prod_image'	=> getPost('prod_image'),
	'prod_alias'	=> makeAlias('name'),
	'prod_id'		=> getRequest('id'),
	'prod_gid'		=> $gid,
	'attribs'		=> json_encode(['metadesc' => strip_tags(getPost('metadesc')), 'metakeys' => strip_tags(getPost('metakeys'))]),
	'group_alias'	=> cleanChars($groupname),
	'group_id'		=> $gid,
	];
	
	try {
		cmseproducts()->insertGetId($fields);
	} catch(\Exception $e) {
		cmseNotice($e->getMessage());
	}
}