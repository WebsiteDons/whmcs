<?php
/*
* Copyright (c) 2019 CMSEnergizer.com. All Rights Reserved
* License: GNU General Public License version 2 or later; see http://www.gnu.org/licenses/
* Author: Alex
*/
$_ADDONLANG['variable_name'] = "Translated language string.";
$_ADDONLANG['title']="The Title";