<?php
/*
* Copyright (c) 2019 CMSEnergizer.com. All Rights Reserved
* License: GNU General Public License version 2 or later; see http://www.gnu.org/licenses/
* Author: Alex
*/

if( !defined("WHMCS") ) die("This file cannot be accessed directly");

include CMSETPL.'/_templateConfigs.php';