<?php
/*
* Copyright (c) 2019 CMSEnergizer.com. All Rights Reserved
* License: GNU General Public License version 2 or later; see http://www.gnu.org/licenses/
* Author: Alex
*/

if( !defined("WHMCS") ) die("This file cannot be accessed directly");

// get template configurations
//$params = tplConfig();

$n = "\n";

if( $params->setfont != '' )
	$setfont = html_entity_decode($params->setfont);

// inline styling
// page background
$pgbg='';
if( !empty($params->pgbgcolor) || !empty($params->pgbgimg) )
{
	$pgbg = 'body.theme-sixflix {background: '.$params->pgbgcolor.';}';
	if( !empty($params->pgbgcolor2) )
		$pgbg = 'body.theme-sixflix {background: linear-gradient(to bottom, '.$params->pgbgcolor.' 0%, '.$params->pgbgcolor2.' 100%) no-repeat;}';
	if( !empty($params->pgbgimg) ) {
		$repeat = (!empty($params->pgbgimgrepeat) ? $params->pgbgimgrepeat.' ' : '');
		$bgsize = (!empty($params->pgbgimgsize) ? ' background-size: '.$params->pgbgimgsize.';' : '');

		$pgbg = 'body.theme-sixflix {background: url('.IMAGES.$params->pgbgimg.') '.$repeat.$params->pgbgcolor.';'.$bgsize.'}';
	}
}

// head section
$headbg = (!empty($params->headbg1) ? '#header.header {background: '.$params->headbg1.' !important;}' : '');
if( !empty($params->headbg2) && !empty($params->headbg1) )
	$headbg = '#header.header {background: linear-gradient(to bottom, '.$params->headbg1.' 0%, '.$params->headbg2.' 100%) !important;}';
$headfont = (!empty($params->headfontcolor) ? '#header.header {color: '.$params->headfontcolor.' !important;}' : '');
$headlink = (!empty($params->headlink) ? '#header.header a {color: '.$params->headlink.' !important;}' : '');

// Top Nav
$navbarbg = (!empty($params->navbg1) ? '#main-menu .navbar-main {background: '.$params->navbg1.' !important;}' : '');
if( !empty($params->navbg2) && !empty($params->navbg1) )
	$navbarbg = '#main-menu .navbar-main {background: linear-gradient(to bottom, '.$params->navbg1.' 0%, '.$params->navbg2.' 100%) !important;}';

$navlinkhov = (!empty($params->navlinkbghov1) ? '#main-menu .navbar-main li.parent.active a, #main-menu .navbar-main li.parent a:hover {background: '.$params->navlinkbghov1.' !important;}' : '');
if( !empty($params->navlinkbghov2) && !empty($params->navlinkbghov1) )
	$navlinkhov = '#main-menu .navbar-main li.parent.active a, #main-menu .navbar-main li.parent a:hover {background: linear-gradient(to bottom, '.$params->navlinkbghov1.' 0%, '.$params->navlinkbghov2.' 100%) !important;}';
$navlinkborder = (!empty($params->navlinkborder) ? '#main-menu .navbar-main li.parent a {border-color: '.$params->navlinkborder.' !important;}' : '');
$navlinktext = (!empty($params->navtext) ? '#main-menu .navbar-main li.parent a {color: '.$params->navtext.' !important;}' : '');
$subnavbg = (!empty($params->navsubbg) ? '#main-menu .navbar-main li.dropdown ul.dropdown-menu {background: '.$params->navsubbg.' !important;}' : '');
$subnavtext = (!empty($params->navsubtext) ? '#main-menu .navbar-main li.dropdown ul.dropdown-menu li a {color: '.$params->navsubtext.' !important;}' : '');

// Top Content Section
$topsectbg = (!empty($params->topsectbg1) ? 'section.top-row {background: '.$params->topsectbg1.' !important;}' : '');
if( !empty($params->topsectbg2) && !empty($params->topsectbg1) )
	$topsectbg = 'section.top-row {background: linear-gradient(to bottom, '.$params->topsectbg1.' 0%, '.$params->topsectbg2.' 100%) !important;}';
$topsecttext = (!empty($params->topsecttext) ? 'section.top-row, section.top-row a {color: '.$params->topsecttext.' !important;}' : '');

// Main Content Section
$mainsectbg = (!empty($params->mainsectbg) ? 'section#main-body {background: '.$params->mainsectbg.' !important;}' : '');
$mainsecttext = (!empty($params->mainsecttext) ? 'section#main-body, section#main-body a {color: '.$params->mainsecttext.' !important;}' : '');

// Bottom Content Section
$bottomsectbg = (!empty($params->bottomsectbg1) ? 'section.bottom-row {background: '.$params->bottomsectbg1.' !important;}' : '');
if( !empty($params->bottomsectbg2) && !empty($params->bottomsectbg1) )
	$bottomsectbg = 'section.bottom-row {background: linear-gradient(to bottom, '.$params->bottomsectbg1.' 0%, '.$params->bottomsectbg2.' 100%) !important;}';
$bottomsecttext = (!empty($params->bottomsecttext) ? 'section.bottom-row, section.bottom-row a {color: '.$params->bottomsecttext.' !important;}' : '');

// Foot Section
$footbg = (!empty($params->footbg1) ? 'section#footer {background: '.$params->footbg1.' !important;}' : '');
if( !empty($params->footbg2) && !empty($params->footbg1) )
	$footbg = 'section#footer {background: linear-gradient(to bottom, '.$params->footbg1.' 0%, '.$params->footbg2.' 100%) !important;}';
$foottext = (!empty($params->foottext) ? 'section#footer, section#footer a {color: '.$params->foottext.' !important;}' : '');



// output inline CSS
inlineCss(
'/*-- SixFlix Template Config --*/'.$n.
$setfont.'
#main-body .container,
.fullwidth.w1 .w3,
.fullwidth.w1 .w2 div,
.w3 .inner-wrap,
.widetitle div {max-width: '.$params->layoutwidth.'px; margin: auto;}
@media screen and (max-width: '.($params->layoutwidth+1).'px) {
	#main-body .container,
	.fullwidth.w1 .w3,
	.fullwidth.w1 .w2 div,
	.w3 .inner-wrap,
	.widetitle div {
		padding-left: 20px; padding-right: 20px;
	}
}

'.$pgbg.
$headbg.
$headfont.
$headlink.
$navbarbg.
$navlinkhov.
$navlinkborder.
$navlinktext.
$subnavbg.
$subnavtext.
$topsectbg.
$topsecttext.
$mainsectbg.
$mainsecttext.
$bottomsectbg.
$bottomsecttext.
$footbg.
$foottext
.$n);


if( $params->themes != '' ) {
	if( in_array($params->themes, getFiles(SITETPLS_DIR.'/sixflix/css/themes/', 'css')) ) {
		styleSheet(TEMPLATES.'/sixflix/css/themes/'.$params->themes, ['ft'=>'ft']);
	}else{
		styleSheet(CMSETPL_URL.'/css/themes/'.$params->themes, ['ft'=>'ft']);
	}
}

if( $params->fontfamily != '' )
	styleSheet('https://fonts.googleapis.com/css?family='.$params->fontfamily);


/* Columns
------------------------------*/

// Set column widths
$maincol= $lcolwidth= $rcolwidth= $sidercol= $sidelcol='';
$sideright = in_array('sideright', $positions);
$sideleft = in_array('sideleft', $positions);

// Set column widths
$lcol = $params->leftcolwidth;
$rcol = $params->rightcolwidth;

// column padding and location
$order = explode('|', $params->columnorder);
$lcolpad = explode(',', $params->leftcolpad);
$rcolpad = explode(',', $params->rightcolpad);

// process columns
// if both side bar columns are active
if( $sideleft && $sideright ) {
	$sidelcol = ' sideleft-active';
	$sidercol = ' sideright-active';
	$maincol = '.maincolumn {width: '.(100 - ($lcol+$rcol)).'%; order: '.$order[0].';}';
	$lcolwidth = '.sideleft {width: '.$lcol.'%; padding-left: '.$lcolpad[0].'px; padding-right: '.$lcolpad[1].'px; order: '.$order[1].';}';
	$rcolwidth = '.sideright {width: '.$rcol.'%; padding-left: '.$rcolpad[0].'px; padding-right: '.$rcolpad[1].'px; order: '.$order[2].';}';
}
// if only side left is active
elseif( $sideleft && !$sideright ) {
	$sidelcol = ' sideleft-active';
	$maincol = '.maincolumn {width: '.(100 - $lcol).'%; order: '.$order[0].';}';
	$lcolwidth = '.sideleft {width: '.$lcol.'%; padding-left: '.$lcolpad[0].'px; padding-right: '.$lcolpad[1].'px; order: '.$order[1].';}';
}
// if only side right is active
elseif( !$sideleft && $sideright ) {
	$sidercol = ' sideright-active';
	$maincol = '.maincolumn {width: '.(100 - $rcol).'%; order: '.$order[0].';}';
	$rcolwidth = '.sideright {width: '.$rcol.'%; padding-left: '.$rcolpad[0].'px; padding-right: '.$rcolpad[1].'px; order: '.$order[2].';}';
}else{
	$maincol = '.maincolumn {width: 100%;}';
}

// output inline css to define column display
inlineCss(
$maincol.$n.$lcolwidth.$n.$rcolwidth
.'/*--/SixFlix Config--*/'
);


/* Original complex conditions moved from .tpl files */

// head.tpl
$head_scripts = '
<link href="'.CMSETPL_URL.'/css/template.css" rel="stylesheet">
<link href="'.ROOT_URL.'assets/css/fontawesome-all.min.css" rel="stylesheet">

<!--[if lt IE 9]>
<script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
<script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
<![endif]-->

<script type="text/javascript">
var csrfToken = "'.tplVars('token').'",
markdownGuide = "'.text('markdown.title').'",
locale = "'.(!empty(tplVars('mdeLocale')) ? tplVars('mdeLocale') : 'en').'",
saved = "'.text('markdown.saved').'",
saving = "'.text('markdown.saving').'",
whmcsBaseUrl = "'.ROOT_URL.'",
requiredText = "'.text('orderForm.required').'",
recaptchaSiteKey = "'.(tplVars('captcha') ? getSetting('ReCAPTCHAPublicKey') : '').'";
</script>
<script src="'.CMSETPL_URL.'/js/scripts.min.js"></script>
';

if( tplVars('templatefile') == 'viewticket' && !tplVars('loggedin') )
  $head_scripts .= '<meta name="robots" content="noindex" />';

//debug(getSmarty());
// alert class conditions
$alertclass = 'info';
if( requestKey('incorrect') ) {
	$alertclass = 'danger center';
}

// get values to define current page values
list($component, $view, $category, $post, $menuid, $listpage, $prodid, $groupid, $parent) = getNonSEF();

// get wide image for post or product
$wideimage= $widetitle= $layertitle= $coretitle='';

if( $component != '' )
{
	if( $component == 'posts' ) {
		$post = posts()->where('id', (int)$post)->select('title', 'attribs')->get()[0];
		$wideimg = json_decode($post->attribs);
		$cat = categories()->where([['id', (int)$category], ['type', 'post']])->select('title', 'configs')->get()[0];
		$catconfig = json_decode($cat->configs);
	}else
	if( $component == 'products' ) {
		$wideimg = json_decode(cmseproducts()->where('prod_alias', getCurrentFilename())->value('attribs'));
	}

	// wide title
	if( isset($catconfig->widetitle) )
	{
		if( $view == 'post' ) {
			$itemtitle = $post->title;
		}else
		if( $view == 'category' ) {
			$itemtitle = $cat->title;
		}

		if( $catconfig->widetitle == 1 || ($catconfig->widetitle == 2 && empty($wideimg->wide_image)) ) {
			$widetitle = '<h1 class="widetitle"><div><span>'.$itemtitle.'</span></div></h1>';
		}else
		if( $catconfig->widetitle == 2 && !empty($wideimg->wide_image) ) {
			$widetitle = '';
			$layertitle = '<h1 class="layertitle"><div><span>'.$itemtitle.'</span></div></h1>';
		}
	}

	// wide image
	if( $view == 'post' || $view == 'productdetail' ) {
		if( isset($wideimg->wide_image) && !empty($wideimg->wide_image) )
		{
			$caption = (isset($wideimg->wide_imagecaption) && !empty($wideimg->wide_imagecaption) ? '<h2 class="imgcaption"><span>'.$wideimg->wide_imagecaption.'</span></h2>' : '');
			$wideimage = '
				<div class="wideimage">
					'.$caption.$layertitle.'
					<div><img src="'.IMAGES.$wideimg->wide_image.'" /></div>
				</div>';
		}
	}else
	if( $view == 'category' ) {
		if( isset($catconfig->wideimage) ) {
			$wideimage = '
			<div class="wideimage">
				<div><img src="'.IMAGES.$catconfig->catimage.'" /></div>
			</div>
			';
		}
	}
}else
if( tplVars('templatefile') != 'homepage' ) {
	if( $params->widetitle ) {
		$widetitle = '<h1 class="widetitle"><div><span>'.tplVars('displayTitle').'</span></div></h1>';
	}else{
		$coretitle = '<h1><div><span>'.tplVars('displayTitle').'</span></div></h1>';
	}
}

// set smarty variables to add classes to the body tag
getSmarty()->assign([
	'sidecol' => $sidercol.$sidelcol,
	'head_scripts' => $head_scripts,
	'alertclass' => $alertclass,
	'wideimage' => $wideimage,
	'widetitle' => $widetitle,
	'core_pagetitle' => $coretitle
]);

//debug(tplVars('displayTitle'));