tinymce.PluginManager.add('cmseshortcode', function(editor, url) {

	editor.addButton('cmseshortcode', {
		text: 'Shortcode',
		icon: false,
		onclick: function() {
			// Open window
			editor.windowManager.open({
				title: 'Add Shortcodes',
				url: 'http://websitedons.net/demo/whmcs/modules/addons/cmseframework/lib/Admin/editor/shortcode.php',
				width: 800,
				height: 600,
				
				/*body: [
					{type: 'panel', name: 'title', label: 'Title', text: 'use these to insert stuff'},
					{type: 'textbox',  name: 'vars', label: 'Add Vars', value: '[videoplayer]'},
					{type: 'textbox', multiline: true,  name: 'texarea', label: 'Add Vars'},
					{
						type: 'listbox', 
						name: 'mediaobjects', 
						label: 'Add Media Oject',
						values : [
                        { text: 'Video Player', value: '[videoplayer]' },
                        { text: 'Audio Player', value: '[audioplayer]' },
                        { text: 'Photo Gallery', value: '[photogallery]' }
						],
						value : '' // default
					},
					
				],
				
				onsubmit: function(e) {
				// Insert content when the window form is submitted
				editor.insertContent(e.data.mediaobjects);
				}*/
				
				
			});
		}
	});


});
