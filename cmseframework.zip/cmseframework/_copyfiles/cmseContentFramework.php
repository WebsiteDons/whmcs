<?php
/*
* Copyright (c) 2019 Emuzement Net Inc. All Rights Reserved
* License: EULA
* Author: Alex/Kumar/Manti/Lisa
*/

define('CLIENTAREA', true);

require_once(__DIR__ . '/init.php');

$response = new WHMCS\ClientArea();
$response->setTemplate('component');

list($component, $view, $category, $post, $menuid, $listpage, $prodid, $groupid, $parent) = getNonSEF();


if( !$parent ) {
	$response->setPageTitle('404 - Page Not Found');
	$response->setTemplate('error/page-not-found');
	$response = $response->withStatus(404);
}

(new Laminas\HttpHandlerRunner\Emitter\SapiEmitter())->emit($response);
exit();

