<?php
/*
* Copyright (c) 2019 Emuzement Net Inc. All Rights Reserved
* License: EULA
* Author: Alex/Kumar/Manti/Lisa
*/

if( !defined("WHMCS") ) die("This file cannot be accessed directly");

use \WHMCS\Application;
use \WHMCS\Database\Capsule;
use \WHMCS\Carbon;
use \WHMCS\Config\Setting;
use \WHMCS\Session;
use \WHMCS\User\Client;
use \WHMCS\ClientArea;

$smarty = new \WHMCS\Smarty(true);

$n = "\n";
$modlink = 'addonmodules.php?module='.MODNAME;

// Admin restriction
$adminrestrict = explode(',', modConfigs()->admin_restrict);
if( in_array(Session::get('adminid'), modConfigs()->admin_restrict) )
	$adminallowed = true;

if( !$adminallowed && in_array(getRequest('view'), modConfigs()->permissions) )
	redirect($modlink);

// define cmse custom css
$theme = file_get_contents(LIB_PATH.'/Admin/templateManager/admincss/data.txt');
$themefile='';
if( $theme != '' )
	$themefile = '<link href="'.LIB_URL.'/Admin/templateManager/admincss/'.$theme.'" rel="stylesheet" type="text/css" />';

$logoimg = file_get_contents(LIB_PATH.'/Admin/templateManager/admincss/logo.txt');
$adminlogo='';
if( $logoimg != '' )
	$adminlogo = '$("div.logo a img").attr("src", "'.IMAGES.$logoimg.'");';

// load css files
$cssfile = '
<link href="'.LIB_URL.'/vendor/chosen/chosen.min.css" rel="stylesheet" type="text/css" />
<link href="'.LIB_URL.'/vendor/minicolors/jquery.minicolors.css" rel="stylesheet" type="text/css" />
<link href="'.ASSET_URL.'/cmseglobal.css" rel="stylesheet" type="text/css" />
<link href="'.ASSET_URL.'/cmseadmin.css" rel="stylesheet" type="text/css" />
'.$themefile
;

// assign custom css variable to custom login .tpl
$smarty->assign('cmse_custom_admin', $custom_css);

// load codemirror editor files
$codemirror='';

if( fullAdmin($vars['adminid']) ) 
{
	if( 
	getRequest('view') == 'templateManager' && 
	(getRequest('task') == 'templateEdit' || getRequest('task') == 'templateConfig' ||  getRequest('task') == 'templateAdminEdit') 
	)
	{
		$codemirror = '
		<link rel="stylesheet" href="'.LIB_URL.'/vendor/codemirror/lib/codemirror.css" />
		<link rel="stylesheet" href="'.LIB_URL.'/vendor/codemirror/theme/3024-night.css" />
		<link rel="stylesheet" href="'.LIB_URL.'/vendor/codemirror/addon/display/fullscreen.css" />
		<link rel="stylesheet" href="'.LIB_URL.'/vendor/codemirror/addon/dialog/dialog.css" />
		<link rel="stylesheet" href="'.LIB_URL.'/vendor/codemirror/addon/search/matchesonscrollbar.css" />
		<link href="'.ASSET_URL.'/jqueryFileTree.css" rel="stylesheet" type="text/css" media="screen" />

		<script src="'.LIB_URL.'/vendor/codemirror/lib/codemirror.js"></script>
		<script src="'.LIB_URL.'/vendor/codemirror/mode/javascript/javascript.js"></script>
		<script src="'.LIB_URL.'/vendor/codemirror/mode/xml/xml.js"></script>
		<script src="'.LIB_URL.'/vendor/codemirror/mode/css/css.js"></script>
		<script src="'.LIB_URL.'/vendor/codemirror/mode/php/php.js"></script>
		<script src="'.LIB_URL.'/vendor/codemirror/addon/selection/active-line.js"></script>
		<script src="'.LIB_URL.'/vendor/codemirror/addon/edit/matchbrackets.js"></script>
		<script src="'.LIB_URL.'/vendor/codemirror/addon/display/fullscreen.js"></script>
		<script src="'.LIB_URL.'/vendor/codemirror/addon/dialog/dialog.js"></script>
		<script src="'.LIB_URL.'/vendor/codemirror/addon/search/searchcursor.js"></script>
		<script src="'.LIB_URL.'/vendor/codemirror/addon/search/search.js"></script>
		<script src="'.LIB_URL.'/vendor/codemirror/addon/scroll/annotatescrollbar.js"></script>
		<script src="'.LIB_URL.'/vendor/codemirror/addon/search/matchesonscrollbar.js"></script>
		<script src="'.LIB_URL.'/vendor/codemirror/addon/search/jump-to-line.js"></script>

		<script src="'.ASSET_URL.'/jquery.easing.js" type="text/javascript"></script>
		<script src="'.ASSET_URL.'/jqueryFileTree.js" type="text/javascript"></script>
		';

	}
}






/* Product Configuration Form
------------------------------------------*/
// add product image field and database column
// convert product description tenxtarea to wysiwyg
$prodimg= $groupconfig='';
$tinymceselector = 'var txtfield = "textarea#wysiwyg,.wysiwyg";';

if( getCurrentFilename() == 'configproducts.php' )
{
	// set TinyMCE as product description editor
	if( isset(modConfigs()->prod_wysiwyg) && !empty(modConfigs()->prod_wysiwyg) ) {
		$tinymceselector = 'var txtfield = "textarea#wysiwyg,.wysiwyg,textarea[name=description],#tagline,#headline";';
	}


	// initially add existing products and groups to the mod_cmse_products table after installation
	if( isset(modConfigs()->product_detail) && !empty(modConfigs()->product_detail) )
	{
		// make aliases of any existing product group names
		$groups = groups()->select('id', 'name')->get();
		foreach($groups as $group)
		{
			if( !in_array($group->id, cmseproducts()->pluck('group_id')) )
			{
				$fields = [
				'type' => 'group',
				'group_id' => $group->id,
				'group_alias' => cleanChars($group->name),
				];
				cmseproducts()->insertGetId($fields);
			}
		}

		// make aliases of any existing product names
		$products = products()->select('id', 'name', 'gid')->get();
		foreach($products as $product)
		{
			if( !in_array($product->id, cmseproducts()->pluck('prod_id')) )
			{
				$fields = [
				'type' => 'product',
				'prod_id' => $product->id,
				'prod_alias' => cleanChars($product->name),
				'prod_gid' => $product->gid,
				'group_alias' => cleanChars(groups()->where('id', $product->gid)->value('name')),
				'group_id' => $product->gid
				];
				cmseproducts()->insertGetId($fields);
			}
		}

		// compare mod_cmse_products to tblproducts and delete rows which have been deleted in tblproducts
		$prodids = cmseproducts()->where('type', 'product')->pluck('prod_id');

		foreach($prodids as $prodid) {
			if( !in_array($prodid, products()->pluck('id')) )
				cmseproducts()->where('prod_id', $prodid)->delete();
		}

		// product group view append display option fields
		if( getRequest('action') == 'editgroup' || getRequest('action') == 'creategroup' )
		{
			include LIB_PATH.'/Admin/products/productGroup.php';
		}

		// append the image field and image manager button to the description textarea
		if( getRequest('action') == 'edit' )
		{
			include LIB_PATH.'/Admin/products/productEdit.php';
		}
	}
}

$notice ='';
if( requestKey('itemsaved') ) {
	$notice = '$.growl.notice({ title: "Success", message: "Item successfully saved" });';
}



// add new window open to login as client link
$targetattrib='';
if( modConfigs()->targetattrib )
	$targetattrib = '$("a#summary-login-as-client").attr("target", "_blank");';

$jsfile = '<!-- TinyMCE -->
<script type="text/javascript">
var liburl = "'.LIB_URL.'";
'.$tinymceselector.'
</script>
<script src="'.LIB_URL.'/vendor/chosen/chosen.jquery.min.js"></script>

<script type="text/javascript" src="'.ROOT_URL.'assets/js/tinymce/tinymce.min.js"></script>
<script type="text/javascript" src="'.ASSET_URL.'/ddaccordion.js"></script>
<script src="'.LIB_URL.'/vendor/minicolors/jquery.minicolors.min.js"></script>
<script type="text/javascript" src="'.ASSET_URL.'/repeatable-fields.js"></script>
<script src="'.ASSET_URL.'/cmseadmin.js"></script>

<script>
cmseslides("slidetab","slidecontent");
cmseslides("slidetab2", "slidecontent2", "", persist=true);

jQuery(function($) {
	autosize($("textarea.autosize"));
	'.$notice.
	$adminlogo.
	$targetattrib.'
	$(".cmseform").parent().addClass("h1title");
	$(".savebtn-bar").sticky({ topSpacing: 0, zIndex: 9999, className: "sticktop" });
});
</script>
';

// load tinymce as php
ob_start();
include LIB_PATH.'/Admin/editor/tinymce.js.php';
$tinymce = ob_get_clean();