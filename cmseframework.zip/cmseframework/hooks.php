<?php
/*
* Copyright (c) 2019 Emuzement Net Inc. All Rights Reserved
* License: EULA
* Author: Alex/Kumar/Manti/Lisa
*/

if( !defined("WHMCS") ) die("This file cannot be accessed directly");

// load functions globally
include_once __DIR__.'/functions.php';


add_hook('ClientAreaHeadOutput', 1, function($vars)
{
	require MODPATH.'/headOutput.php';

	return '
	<!-- cmse posts -->
	'.$ogmeta .$n . $headcss . $headjs . $inlineCss . $il . $inlineJs . $n.'
	<!-- end cmse post -->
	'.$n;

});


/* Client Area Foot Output
--------------------------------------------*/

add_hook('ClientAreaFooterOutput', 1, function($vars)
{
	$n = "\n";

	customScript(html_entity_decode(modConfigs()->head_scripts));

	// dynamically add custom scripts to head
	$footjs='';
	if( !empty(tplVars('customfootscript')) && is_array(tplVars('customfootscript')) ) {
		foreach(tplVars('customfootscript') as $customfootscript) {
			$footjs .= $n.$customsfootcript;
		}
	}

	return footjs() . $footjs;
});





/** A D M I N  A R E A 51
----------------------------------------------------------------------*/
add_hook('AdminAreaHeadOutput', 1, function($vars)
{
	require MODPATH.'/adminHead.php';

    return '
	<!-- cmse mod posts -->
	'.$n. $cssfile . $jsfile. $n. $codemirror. $prodimg. $groupconfig . $tinymce.'
	<!-- end cmse post module -->
	';

});


// on product save hook. save image to product
add_hook('AdminProductConfigFieldsSave', 1, function($vars)
{
	require MODPATH.'/adminProdInsert.php';

});


